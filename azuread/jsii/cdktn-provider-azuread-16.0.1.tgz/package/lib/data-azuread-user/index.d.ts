/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadUserConfig extends cdktn.TerraformMetaArguments {
    /**
    * The employee identifier assigned to the user by the organisation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#employee_id DataAzureadUser#employee_id}
    */
    readonly employeeId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#id DataAzureadUser#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The SMTP address for the user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#mail DataAzureadUser#mail}
    */
    readonly mail?: string;
    /**
    * The email alias of the user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#mail_nickname DataAzureadUser#mail_nickname}
    */
    readonly mailNickname?: string;
    /**
    * The object ID of the user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#object_id DataAzureadUser#object_id}
    */
    readonly objectId?: string;
    /**
    * The user principal name (UPN) of the user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#user_principal_name DataAzureadUser#user_principal_name}
    */
    readonly userPrincipalName?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#timeouts DataAzureadUser#timeouts}
    */
    readonly timeouts?: DataAzureadUserTimeouts;
}
export interface DataAzureadUserTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#read DataAzureadUser#read}
    */
    readonly read?: string;
}
export declare function dataAzureadUserTimeoutsToTerraform(struct?: DataAzureadUserTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadUserTimeoutsToHclTerraform(struct?: DataAzureadUserTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadUserTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadUserTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadUserTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user azuread_user}
*/
export declare class DataAzureadUser extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_user";
    /**
    * Generates CDKTN code for importing a DataAzureadUser resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadUser to import
    * @param importFromId The id of the existing DataAzureadUser that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadUser to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/user azuread_user} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadUserConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadUserConfig);
    get accountEnabled(): cdktn.IResolvable;
    get ageGroup(): string;
    get businessPhones(): string[];
    get city(): string;
    get companyName(): string;
    get consentProvidedForMinor(): string;
    get costCenter(): string;
    get country(): string;
    get creationType(): string;
    get department(): string;
    get displayName(): string;
    get division(): string;
    get employeeHireDate(): string;
    private _employeeId?;
    get employeeId(): string;
    set employeeId(value: string);
    resetEmployeeId(): void;
    get employeeIdInput(): string | undefined;
    get employeeType(): string;
    get externalUserState(): string;
    get faxNumber(): string;
    get givenName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get imAddresses(): string[];
    get jobTitle(): string;
    private _mail?;
    get mail(): string;
    set mail(value: string);
    resetMail(): void;
    get mailInput(): string | undefined;
    private _mailNickname?;
    get mailNickname(): string;
    set mailNickname(value: string);
    resetMailNickname(): void;
    get mailNicknameInput(): string | undefined;
    get managerId(): string;
    get mobilePhone(): string;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    get officeLocation(): string;
    get onpremisesDistinguishedName(): string;
    get onpremisesDomainName(): string;
    get onpremisesImmutableId(): string;
    get onpremisesSamAccountName(): string;
    get onpremisesSecurityIdentifier(): string;
    get onpremisesSyncEnabled(): cdktn.IResolvable;
    get onpremisesUserPrincipalName(): string;
    get otherMails(): string[];
    get postalCode(): string;
    get preferredLanguage(): string;
    get proxyAddresses(): string[];
    get showInAddressList(): cdktn.IResolvable;
    get state(): string;
    get streetAddress(): string;
    get surname(): string;
    get usageLocation(): string;
    private _userPrincipalName?;
    get userPrincipalName(): string;
    set userPrincipalName(value: string);
    resetUserPrincipalName(): void;
    get userPrincipalNameInput(): string | undefined;
    get userType(): string;
    private _timeouts;
    get timeouts(): DataAzureadUserTimeoutsOutputReference;
    putTimeouts(value: DataAzureadUserTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadUserTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
