/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessPackageConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Catalog this access package will be created in
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#catalog_id AccessPackage#catalog_id}
    */
    readonly catalogId: string;
    /**
    * The description of the access package
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#description AccessPackage#description}
    */
    readonly description: string;
    /**
    * The display name of the access package
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#display_name AccessPackage#display_name}
    */
    readonly displayName: string;
    /**
    * Whether the access package is hidden from the requestor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#hidden AccessPackage#hidden}
    */
    readonly hidden?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#id AccessPackage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#timeouts AccessPackage#timeouts}
    */
    readonly timeouts?: AccessPackageTimeouts;
}
export interface AccessPackageTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#create AccessPackage#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#delete AccessPackage#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#read AccessPackage#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#update AccessPackage#update}
    */
    readonly update?: string;
}
export declare function accessPackageTimeoutsToTerraform(struct?: AccessPackageTimeouts | cdktn.IResolvable): any;
export declare function accessPackageTimeoutsToHclTerraform(struct?: AccessPackageTimeouts | cdktn.IResolvable): any;
export declare class AccessPackageTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package azuread_access_package}
*/
export declare class AccessPackage extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_access_package";
    /**
    * Generates CDKTN code for importing a AccessPackage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPackage to import
    * @param importFromId The id of the existing AccessPackage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPackage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package azuread_access_package} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPackageConfig
    */
    constructor(scope: Construct, id: string, config: AccessPackageConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    get catalogIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _hidden?;
    get hidden(): boolean | cdktn.IResolvable;
    set hidden(value: boolean | cdktn.IResolvable);
    resetHidden(): void;
    get hiddenInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AccessPackageTimeoutsOutputReference;
    putTimeouts(value: AccessPackageTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessPackageTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
