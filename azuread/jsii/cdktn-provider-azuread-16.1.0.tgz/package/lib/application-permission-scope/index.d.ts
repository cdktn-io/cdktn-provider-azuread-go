/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationPermissionScopeConfig extends cdktn.TerraformMetaArguments {
    /**
    * Delegated permission description that appears in all tenant-wide admin consent experiences, intended to be read by an administrator granting the permission on behalf of all users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#admin_consent_description ApplicationPermissionScope#admin_consent_description}
    */
    readonly adminConsentDescription: string;
    /**
    * Display name for the delegated permission, intended to be read by an administrator granting the permission on behalf of all users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#admin_consent_display_name ApplicationPermissionScope#admin_consent_display_name}
    */
    readonly adminConsentDisplayName: string;
    /**
    * The resource ID of the application to which this permission scope should be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#application_id ApplicationPermissionScope#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#id ApplicationPermissionScope#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier of the permission scope
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#scope_id ApplicationPermissionScope#scope_id}
    */
    readonly scopeId: string;
    /**
    * Whether this delegated permission should be considered safe for non-admin users to consent to on behalf of themselves, or whether an administrator should be required for consent to the permissions
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#type ApplicationPermissionScope#type}
    */
    readonly type?: string;
    /**
    * Delegated permission description that appears in the end user consent experience, intended to be read by a user consenting on their own behalf
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#user_consent_description ApplicationPermissionScope#user_consent_description}
    */
    readonly userConsentDescription?: string;
    /**
    * Display name for the delegated permission that appears in the end user consent experience
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#user_consent_display_name ApplicationPermissionScope#user_consent_display_name}
    */
    readonly userConsentDisplayName?: string;
    /**
    * The value that is used for the `scp` claim in OAuth access tokens
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#value ApplicationPermissionScope#value}
    */
    readonly value: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#timeouts ApplicationPermissionScope#timeouts}
    */
    readonly timeouts?: ApplicationPermissionScopeTimeouts;
}
export interface ApplicationPermissionScopeTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#create ApplicationPermissionScope#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#delete ApplicationPermissionScope#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#read ApplicationPermissionScope#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#update ApplicationPermissionScope#update}
    */
    readonly update?: string;
}
export declare function applicationPermissionScopeTimeoutsToTerraform(struct?: ApplicationPermissionScopeTimeouts | cdktn.IResolvable): any;
export declare function applicationPermissionScopeTimeoutsToHclTerraform(struct?: ApplicationPermissionScopeTimeouts | cdktn.IResolvable): any;
export declare class ApplicationPermissionScopeTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationPermissionScopeTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationPermissionScopeTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope azuread_application_permission_scope}
*/
export declare class ApplicationPermissionScope extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_permission_scope";
    /**
    * Generates CDKTN code for importing a ApplicationPermissionScope resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationPermissionScope to import
    * @param importFromId The id of the existing ApplicationPermissionScope that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationPermissionScope to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_permission_scope azuread_application_permission_scope} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationPermissionScopeConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationPermissionScopeConfig);
    private _adminConsentDescription?;
    get adminConsentDescription(): string;
    set adminConsentDescription(value: string);
    get adminConsentDescriptionInput(): string | undefined;
    private _adminConsentDisplayName?;
    get adminConsentDisplayName(): string;
    set adminConsentDisplayName(value: string);
    get adminConsentDisplayNameInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _scopeId?;
    get scopeId(): string;
    set scopeId(value: string);
    get scopeIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _userConsentDescription?;
    get userConsentDescription(): string;
    set userConsentDescription(value: string);
    resetUserConsentDescription(): void;
    get userConsentDescriptionInput(): string | undefined;
    private _userConsentDisplayName?;
    get userConsentDisplayName(): string;
    set userConsentDisplayName(value: string);
    resetUserConsentDisplayName(): void;
    get userConsentDisplayNameInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationPermissionScopeTimeoutsOutputReference;
    putTimeouts(value: ApplicationPermissionScopeTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationPermissionScopeTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
