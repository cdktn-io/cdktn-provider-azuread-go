/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadApplicationTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The display name for the application template
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template#display_name DataAzureadApplicationTemplate#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template#id DataAzureadApplicationTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The application template's ID
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template#template_id DataAzureadApplicationTemplate#template_id}
    */
    readonly templateId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template#timeouts DataAzureadApplicationTemplate#timeouts}
    */
    readonly timeouts?: DataAzureadApplicationTemplateTimeouts;
}
export interface DataAzureadApplicationTemplateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template#read DataAzureadApplicationTemplate#read}
    */
    readonly read?: string;
}
export declare function dataAzureadApplicationTemplateTimeoutsToTerraform(struct?: DataAzureadApplicationTemplateTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadApplicationTemplateTimeoutsToHclTerraform(struct?: DataAzureadApplicationTemplateTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadApplicationTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadApplicationTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadApplicationTemplateTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template azuread_application_template}
*/
export declare class DataAzureadApplicationTemplate extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_application_template";
    /**
    * Generates CDKTN code for importing a DataAzureadApplicationTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadApplicationTemplate to import
    * @param importFromId The id of the existing DataAzureadApplicationTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadApplicationTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/application_template azuread_application_template} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadApplicationTemplateConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadApplicationTemplateConfig);
    get categories(): string[];
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get homepageUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get logoUrl(): string;
    get publisher(): string;
    get supportedProvisioningTypes(): string[];
    get supportedSingleSignOnModes(): string[];
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    resetTemplateId(): void;
    get templateIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzureadApplicationTemplateTimeoutsOutputReference;
    putTimeouts(value: DataAzureadApplicationTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadApplicationTemplateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
