/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface InvitationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#id Invitation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The URL that the user should be redirected to once the invitation is redeemed
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#redirect_url Invitation#redirect_url}
    */
    readonly redirectUrl: string;
    /**
    * The display name of the user being invited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#user_display_name Invitation#user_display_name}
    */
    readonly userDisplayName?: string;
    /**
    * The email address of the user being invited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#user_email_address Invitation#user_email_address}
    */
    readonly userEmailAddress: string;
    /**
    * The user type of the user being invited
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#user_type Invitation#user_type}
    */
    readonly userType?: string;
    /**
    * message block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#message Invitation#message}
    */
    readonly message?: InvitationMessage;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#timeouts Invitation#timeouts}
    */
    readonly timeouts?: InvitationTimeouts;
}
export interface InvitationMessage {
    /**
    * Email addresses of additional recipients the invitation message should be sent to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#additional_recipients Invitation#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Customized message body you want to send if you don't want to send the default message
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#body Invitation#body}
    */
    readonly body?: string;
    /**
    * The language you want to send the default message in
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#language Invitation#language}
    */
    readonly language?: string;
}
export declare function invitationMessageToTerraform(struct?: InvitationMessageOutputReference | InvitationMessage): any;
export declare function invitationMessageToHclTerraform(struct?: InvitationMessageOutputReference | InvitationMessage): any;
export declare class InvitationMessageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InvitationMessage | undefined;
    set internalValue(value: InvitationMessage | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _body?;
    get body(): string;
    set body(value: string);
    resetBody(): void;
    get bodyInput(): string | undefined;
    private _language?;
    get language(): string;
    set language(value: string);
    resetLanguage(): void;
    get languageInput(): string | undefined;
}
export interface InvitationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#create Invitation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#delete Invitation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#read Invitation#read}
    */
    readonly read?: string;
}
export declare function invitationTimeoutsToTerraform(struct?: InvitationTimeouts | cdktn.IResolvable): any;
export declare function invitationTimeoutsToHclTerraform(struct?: InvitationTimeouts | cdktn.IResolvable): any;
export declare class InvitationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): InvitationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: InvitationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation azuread_invitation}
*/
export declare class Invitation extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_invitation";
    /**
    * Generates CDKTN code for importing a Invitation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the Invitation to import
    * @param importFromId The id of the existing Invitation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the Invitation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/invitation azuread_invitation} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options InvitationConfig
    */
    constructor(scope: Construct, id: string, config: InvitationConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get redeemUrl(): string;
    private _redirectUrl?;
    get redirectUrl(): string;
    set redirectUrl(value: string);
    get redirectUrlInput(): string | undefined;
    private _userDisplayName?;
    get userDisplayName(): string;
    set userDisplayName(value: string);
    resetUserDisplayName(): void;
    get userDisplayNameInput(): string | undefined;
    private _userEmailAddress?;
    get userEmailAddress(): string;
    set userEmailAddress(value: string);
    get userEmailAddressInput(): string | undefined;
    get userId(): string;
    private _userType?;
    get userType(): string;
    set userType(value: string);
    resetUserType(): void;
    get userTypeInput(): string | undefined;
    private _message;
    get message(): InvitationMessageOutputReference;
    putMessage(value: InvitationMessage): void;
    resetMessage(): void;
    get messageInput(): InvitationMessage | undefined;
    private _timeouts;
    get timeouts(): InvitationTimeoutsOutputReference;
    putTimeouts(value: InvitationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | InvitationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
