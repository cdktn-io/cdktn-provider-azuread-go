/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadServicePrincipalConfig extends cdktn.TerraformMetaArguments {
    /**
    * The client ID of the application associated with this service principal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal#client_id DataAzureadServicePrincipal#client_id}
    */
    readonly clientId?: string;
    /**
    * The display name of the application associated with this service principal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal#display_name DataAzureadServicePrincipal#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal#id DataAzureadServicePrincipal#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the service principal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal#object_id DataAzureadServicePrincipal#object_id}
    */
    readonly objectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal#timeouts DataAzureadServicePrincipal#timeouts}
    */
    readonly timeouts?: DataAzureadServicePrincipalTimeouts;
}
export interface DataAzureadServicePrincipalAppRoles {
}
export declare function dataAzureadServicePrincipalAppRolesToTerraform(struct?: DataAzureadServicePrincipalAppRoles): any;
export declare function dataAzureadServicePrincipalAppRolesToHclTerraform(struct?: DataAzureadServicePrincipalAppRoles): any;
export declare class DataAzureadServicePrincipalAppRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadServicePrincipalAppRoles | undefined;
    set internalValue(value: DataAzureadServicePrincipalAppRoles | undefined);
    get allowedMemberTypes(): string[];
    get description(): string;
    get displayName(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get value(): string;
}
export declare class DataAzureadServicePrincipalAppRolesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadServicePrincipalAppRolesOutputReference;
}
export interface DataAzureadServicePrincipalFeatureTags {
}
export declare function dataAzureadServicePrincipalFeatureTagsToTerraform(struct?: DataAzureadServicePrincipalFeatureTags): any;
export declare function dataAzureadServicePrincipalFeatureTagsToHclTerraform(struct?: DataAzureadServicePrincipalFeatureTags): any;
export declare class DataAzureadServicePrincipalFeatureTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadServicePrincipalFeatureTags | undefined;
    set internalValue(value: DataAzureadServicePrincipalFeatureTags | undefined);
    get customSingleSignOn(): cdktn.IResolvable;
    get enterprise(): cdktn.IResolvable;
    get gallery(): cdktn.IResolvable;
    get hide(): cdktn.IResolvable;
}
export declare class DataAzureadServicePrincipalFeatureTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadServicePrincipalFeatureTagsOutputReference;
}
export interface DataAzureadServicePrincipalFeatures {
}
export declare function dataAzureadServicePrincipalFeaturesToTerraform(struct?: DataAzureadServicePrincipalFeatures): any;
export declare function dataAzureadServicePrincipalFeaturesToHclTerraform(struct?: DataAzureadServicePrincipalFeatures): any;
export declare class DataAzureadServicePrincipalFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadServicePrincipalFeatures | undefined;
    set internalValue(value: DataAzureadServicePrincipalFeatures | undefined);
    get customSingleSignOnApp(): cdktn.IResolvable;
    get enterpriseApplication(): cdktn.IResolvable;
    get galleryApplication(): cdktn.IResolvable;
    get visibleToUsers(): cdktn.IResolvable;
}
export declare class DataAzureadServicePrincipalFeaturesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadServicePrincipalFeaturesOutputReference;
}
export interface DataAzureadServicePrincipalOauth2PermissionScopes {
}
export declare function dataAzureadServicePrincipalOauth2PermissionScopesToTerraform(struct?: DataAzureadServicePrincipalOauth2PermissionScopes): any;
export declare function dataAzureadServicePrincipalOauth2PermissionScopesToHclTerraform(struct?: DataAzureadServicePrincipalOauth2PermissionScopes): any;
export declare class DataAzureadServicePrincipalOauth2PermissionScopesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadServicePrincipalOauth2PermissionScopes | undefined;
    set internalValue(value: DataAzureadServicePrincipalOauth2PermissionScopes | undefined);
    get adminConsentDescription(): string;
    get adminConsentDisplayName(): string;
    get enabled(): cdktn.IResolvable;
    get id(): string;
    get type(): string;
    get userConsentDescription(): string;
    get userConsentDisplayName(): string;
    get value(): string;
}
export declare class DataAzureadServicePrincipalOauth2PermissionScopesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadServicePrincipalOauth2PermissionScopesOutputReference;
}
export interface DataAzureadServicePrincipalSamlSingleSignOn {
}
export declare function dataAzureadServicePrincipalSamlSingleSignOnToTerraform(struct?: DataAzureadServicePrincipalSamlSingleSignOn): any;
export declare function dataAzureadServicePrincipalSamlSingleSignOnToHclTerraform(struct?: DataAzureadServicePrincipalSamlSingleSignOn): any;
export declare class DataAzureadServicePrincipalSamlSingleSignOnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadServicePrincipalSamlSingleSignOn | undefined;
    set internalValue(value: DataAzureadServicePrincipalSamlSingleSignOn | undefined);
    get relayState(): string;
}
export declare class DataAzureadServicePrincipalSamlSingleSignOnList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadServicePrincipalSamlSingleSignOnOutputReference;
}
export interface DataAzureadServicePrincipalTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal#read DataAzureadServicePrincipal#read}
    */
    readonly read?: string;
}
export declare function dataAzureadServicePrincipalTimeoutsToTerraform(struct?: DataAzureadServicePrincipalTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadServicePrincipalTimeoutsToHclTerraform(struct?: DataAzureadServicePrincipalTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadServicePrincipalTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadServicePrincipalTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadServicePrincipalTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal azuread_service_principal}
*/
export declare class DataAzureadServicePrincipal extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_service_principal";
    /**
    * Generates CDKTN code for importing a DataAzureadServicePrincipal resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadServicePrincipal to import
    * @param importFromId The id of the existing DataAzureadServicePrincipal that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadServicePrincipal to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/service_principal azuread_service_principal} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadServicePrincipalConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadServicePrincipalConfig);
    get accountEnabled(): cdktn.IResolvable;
    get alternativeNames(): string[];
    get appRoleAssignmentRequired(): cdktn.IResolvable;
    private _appRoleIds;
    get appRoleIds(): cdktn.StringMap;
    private _appRoles;
    get appRoles(): DataAzureadServicePrincipalAppRolesList;
    get applicationTenantId(): string;
    private _clientId?;
    get clientId(): string;
    set clientId(value: string);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _featureTags;
    get featureTags(): DataAzureadServicePrincipalFeatureTagsList;
    private _features;
    get features(): DataAzureadServicePrincipalFeaturesList;
    get homepageUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get loginUrl(): string;
    get logoutUrl(): string;
    get notes(): string;
    get notificationEmailAddresses(): string[];
    private _oauth2PermissionScopeIds;
    get oauth2PermissionScopeIds(): cdktn.StringMap;
    private _oauth2PermissionScopes;
    get oauth2PermissionScopes(): DataAzureadServicePrincipalOauth2PermissionScopesList;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    get preferredSingleSignOnMode(): string;
    get redirectUris(): string[];
    get samlMetadataUrl(): string;
    private _samlSingleSignOn;
    get samlSingleSignOn(): DataAzureadServicePrincipalSamlSingleSignOnList;
    get servicePrincipalNames(): string[];
    get signInAudience(): string;
    get tags(): string[];
    get type(): string;
    private _timeouts;
    get timeouts(): DataAzureadServicePrincipalTimeoutsOutputReference;
    putTimeouts(value: DataAzureadServicePrincipalTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadServicePrincipalTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
