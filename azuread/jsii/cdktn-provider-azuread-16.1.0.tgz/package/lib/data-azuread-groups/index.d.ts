/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Common display name prefix of the groups
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#display_name_prefix DataAzureadGroups#display_name_prefix}
    */
    readonly displayNamePrefix?: string;
    /**
    * The display names of the groups
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#display_names DataAzureadGroups#display_names}
    */
    readonly displayNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#id DataAzureadGroups#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Ignore missing groups and return groups that were found. The data source will still fail if no groups are found
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#ignore_missing DataAzureadGroups#ignore_missing}
    */
    readonly ignoreMissing?: boolean | cdktn.IResolvable;
    /**
    * Whether the groups are mail-enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#mail_enabled DataAzureadGroups#mail_enabled}
    */
    readonly mailEnabled?: boolean | cdktn.IResolvable;
    /**
    * The object IDs of the groups
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#object_ids DataAzureadGroups#object_ids}
    */
    readonly objectIds?: string[];
    /**
    * Retrieve all groups with no filter
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#return_all DataAzureadGroups#return_all}
    */
    readonly returnAll?: boolean | cdktn.IResolvable;
    /**
    * Whether the groups are security-enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#security_enabled DataAzureadGroups#security_enabled}
    */
    readonly securityEnabled?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#timeouts DataAzureadGroups#timeouts}
    */
    readonly timeouts?: DataAzureadGroupsTimeouts;
}
export interface DataAzureadGroupsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#read DataAzureadGroups#read}
    */
    readonly read?: string;
}
export declare function dataAzureadGroupsTimeoutsToTerraform(struct?: DataAzureadGroupsTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadGroupsTimeoutsToHclTerraform(struct?: DataAzureadGroupsTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadGroupsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadGroupsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadGroupsTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups azuread_groups}
*/
export declare class DataAzureadGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_groups";
    /**
    * Generates CDKTN code for importing a DataAzureadGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadGroups to import
    * @param importFromId The id of the existing DataAzureadGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/groups azuread_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadGroupsConfig);
    private _displayNamePrefix?;
    get displayNamePrefix(): string;
    set displayNamePrefix(value: string);
    resetDisplayNamePrefix(): void;
    get displayNamePrefixInput(): string | undefined;
    private _displayNames?;
    get displayNames(): string[];
    set displayNames(value: string[]);
    resetDisplayNames(): void;
    get displayNamesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreMissing?;
    get ignoreMissing(): boolean | cdktn.IResolvable;
    set ignoreMissing(value: boolean | cdktn.IResolvable);
    resetIgnoreMissing(): void;
    get ignoreMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _mailEnabled?;
    get mailEnabled(): boolean | cdktn.IResolvable;
    set mailEnabled(value: boolean | cdktn.IResolvable);
    resetMailEnabled(): void;
    get mailEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _objectIds?;
    get objectIds(): string[];
    set objectIds(value: string[]);
    resetObjectIds(): void;
    get objectIdsInput(): string[] | undefined;
    private _returnAll?;
    get returnAll(): boolean | cdktn.IResolvable;
    set returnAll(value: boolean | cdktn.IResolvable);
    resetReturnAll(): void;
    get returnAllInput(): boolean | cdktn.IResolvable | undefined;
    private _securityEnabled?;
    get securityEnabled(): boolean | cdktn.IResolvable;
    set securityEnabled(value: boolean | cdktn.IResolvable);
    resetSecurityEnabled(): void;
    get securityEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): DataAzureadGroupsTimeoutsOutputReference;
    putTimeouts(value: DataAzureadGroupsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadGroupsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
