/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadNamedLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/named_location#display_name DataAzureadNamedLocation#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/named_location#id DataAzureadNamedLocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/named_location#timeouts DataAzureadNamedLocation#timeouts}
    */
    readonly timeouts?: DataAzureadNamedLocationTimeouts;
}
export interface DataAzureadNamedLocationCountry {
}
export declare function dataAzureadNamedLocationCountryToTerraform(struct?: DataAzureadNamedLocationCountry): any;
export declare function dataAzureadNamedLocationCountryToHclTerraform(struct?: DataAzureadNamedLocationCountry): any;
export declare class DataAzureadNamedLocationCountryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadNamedLocationCountry | undefined;
    set internalValue(value: DataAzureadNamedLocationCountry | undefined);
    get countriesAndRegions(): string[];
    get countryLookupMethod(): string;
    get includeUnknownCountriesAndRegions(): cdktn.IResolvable;
}
export declare class DataAzureadNamedLocationCountryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadNamedLocationCountryOutputReference;
}
export interface DataAzureadNamedLocationIp {
}
export declare function dataAzureadNamedLocationIpToTerraform(struct?: DataAzureadNamedLocationIp): any;
export declare function dataAzureadNamedLocationIpToHclTerraform(struct?: DataAzureadNamedLocationIp): any;
export declare class DataAzureadNamedLocationIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadNamedLocationIp | undefined;
    set internalValue(value: DataAzureadNamedLocationIp | undefined);
    get ipRanges(): string[];
    get trusted(): cdktn.IResolvable;
}
export declare class DataAzureadNamedLocationIpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadNamedLocationIpOutputReference;
}
export interface DataAzureadNamedLocationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/named_location#read DataAzureadNamedLocation#read}
    */
    readonly read?: string;
}
export declare function dataAzureadNamedLocationTimeoutsToTerraform(struct?: DataAzureadNamedLocationTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadNamedLocationTimeoutsToHclTerraform(struct?: DataAzureadNamedLocationTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadNamedLocationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadNamedLocationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadNamedLocationTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/named_location azuread_named_location}
*/
export declare class DataAzureadNamedLocation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_named_location";
    /**
    * Generates CDKTN code for importing a DataAzureadNamedLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadNamedLocation to import
    * @param importFromId The id of the existing DataAzureadNamedLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/named_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadNamedLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/named_location azuread_named_location} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadNamedLocationConfig
    */
    constructor(scope: Construct, id: string, config: DataAzureadNamedLocationConfig);
    private _country;
    get country(): DataAzureadNamedLocationCountryList;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ip;
    get ip(): DataAzureadNamedLocationIpList;
    get objectId(): string;
    private _timeouts;
    get timeouts(): DataAzureadNamedLocationTimeoutsOutputReference;
    putTimeouts(value: DataAzureadNamedLocationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadNamedLocationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
