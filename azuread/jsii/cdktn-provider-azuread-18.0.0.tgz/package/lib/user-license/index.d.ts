/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface UserLicenseConfig extends cdktn.TerraformMetaArguments {
    /**
    * A set of unique identifiers (GUIDs) for the service plans to disable for this license
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#disabled_plans UserLicense#disabled_plans}
    */
    readonly disabledPlans?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#id UserLicense#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier (GUID) for the SKU (license) to assign to the user
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#sku_id UserLicense#sku_id}
    */
    readonly skuId: string;
    /**
    * The object ID of the user to which the license should be assigned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#user_object_id UserLicense#user_object_id}
    */
    readonly userObjectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#timeouts UserLicense#timeouts}
    */
    readonly timeouts?: UserLicenseTimeouts;
}
export interface UserLicenseTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#create UserLicense#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#delete UserLicense#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#read UserLicense#read}
    */
    readonly read?: string;
}
export declare function userLicenseTimeoutsToTerraform(struct?: UserLicenseTimeouts | cdktn.IResolvable): any;
export declare function userLicenseTimeoutsToHclTerraform(struct?: UserLicenseTimeouts | cdktn.IResolvable): any;
export declare class UserLicenseTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): UserLicenseTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: UserLicenseTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license azuread_user_license}
*/
export declare class UserLicense extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_user_license";
    /**
    * Generates CDKTN code for importing a UserLicense resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the UserLicense to import
    * @param importFromId The id of the existing UserLicense that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the UserLicense to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/user_license azuread_user_license} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options UserLicenseConfig
    */
    constructor(scope: Construct, id: string, config: UserLicenseConfig);
    private _disabledPlans?;
    get disabledPlans(): string[];
    set disabledPlans(value: string[]);
    resetDisabledPlans(): void;
    get disabledPlansInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _skuId?;
    get skuId(): string;
    set skuId(value: string);
    get skuIdInput(): string | undefined;
    private _userObjectId?;
    get userObjectId(): string;
    set userObjectId(value: string);
    get userObjectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): UserLicenseTimeoutsOutputReference;
    putTimeouts(value: UserLicenseTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | UserLicenseTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
