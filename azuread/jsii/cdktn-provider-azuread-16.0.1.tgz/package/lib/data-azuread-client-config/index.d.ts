/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadClientConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/client_config#id DataAzureadClientConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/client_config#timeouts DataAzureadClientConfig#timeouts}
    */
    readonly timeouts?: DataAzureadClientConfigTimeouts;
}
export interface DataAzureadClientConfigTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/client_config#read DataAzureadClientConfig#read}
    */
    readonly read?: string;
}
export declare function dataAzureadClientConfigTimeoutsToTerraform(struct?: DataAzureadClientConfigTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadClientConfigTimeoutsToHclTerraform(struct?: DataAzureadClientConfigTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadClientConfigTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadClientConfigTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadClientConfigTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/client_config azuread_client_config}
*/
export declare class DataAzureadClientConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_client_config";
    /**
    * Generates CDKTN code for importing a DataAzureadClientConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadClientConfig to import
    * @param importFromId The id of the existing DataAzureadClientConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/client_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadClientConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/client_config azuread_client_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadClientConfigConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadClientConfigConfig);
    get clientId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get objectId(): string;
    get tenantId(): string;
    private _timeouts;
    get timeouts(): DataAzureadClientConfigTimeoutsOutputReference;
    putTimeouts(value: DataAzureadClientConfigTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadClientConfigTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
