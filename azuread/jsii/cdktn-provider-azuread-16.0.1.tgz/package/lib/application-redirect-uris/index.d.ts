/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationRedirectUrisConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ID of the application to which these redirect URIs belong
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#application_id ApplicationRedirectUris#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#id ApplicationRedirectUris#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A set of redirect URIs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#redirect_uris ApplicationRedirectUris#redirect_uris}
    */
    readonly redirectUris: string[];
    /**
    * The type of redirect URIs to assign to the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#type ApplicationRedirectUris#type}
    */
    readonly type: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#timeouts ApplicationRedirectUris#timeouts}
    */
    readonly timeouts?: ApplicationRedirectUrisTimeouts;
}
export interface ApplicationRedirectUrisTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#create ApplicationRedirectUris#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#delete ApplicationRedirectUris#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#read ApplicationRedirectUris#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#update ApplicationRedirectUris#update}
    */
    readonly update?: string;
}
export declare function applicationRedirectUrisTimeoutsToTerraform(struct?: ApplicationRedirectUrisTimeouts | cdktn.IResolvable): any;
export declare function applicationRedirectUrisTimeoutsToHclTerraform(struct?: ApplicationRedirectUrisTimeouts | cdktn.IResolvable): any;
export declare class ApplicationRedirectUrisTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationRedirectUrisTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationRedirectUrisTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris azuread_application_redirect_uris}
*/
export declare class ApplicationRedirectUris extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_redirect_uris";
    /**
    * Generates CDKTN code for importing a ApplicationRedirectUris resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationRedirectUris to import
    * @param importFromId The id of the existing ApplicationRedirectUris that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationRedirectUris to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_redirect_uris azuread_application_redirect_uris} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationRedirectUrisConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationRedirectUrisConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _redirectUris?;
    get redirectUris(): string[];
    set redirectUris(value: string[]);
    get redirectUrisInput(): string[] | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationRedirectUrisTimeoutsOutputReference;
    putTimeouts(value: ApplicationRedirectUrisTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationRedirectUrisTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
