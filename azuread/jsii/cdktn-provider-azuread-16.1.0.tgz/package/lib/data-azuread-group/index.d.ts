/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * The display name for the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#display_name DataAzureadGroup#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#id DataAzureadGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Specifies whether to include transitive members (a flat list of all nested members).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#include_transitive_members DataAzureadGroup#include_transitive_members}
    */
    readonly includeTransitiveMembers?: boolean | cdktn.IResolvable;
    /**
    * Whether the group is mail-enabled
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#mail_enabled DataAzureadGroup#mail_enabled}
    */
    readonly mailEnabled?: boolean | cdktn.IResolvable;
    /**
    * The mail alias for the group, unique in the organisation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#mail_nickname DataAzureadGroup#mail_nickname}
    */
    readonly mailNickname?: string;
    /**
    * The object ID of the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#object_id DataAzureadGroup#object_id}
    */
    readonly objectId?: string;
    /**
    * Whether the group is a security group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#security_enabled DataAzureadGroup#security_enabled}
    */
    readonly securityEnabled?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#timeouts DataAzureadGroup#timeouts}
    */
    readonly timeouts?: DataAzureadGroupTimeouts;
}
export interface DataAzureadGroupDynamicMembership {
}
export declare function dataAzureadGroupDynamicMembershipToTerraform(struct?: DataAzureadGroupDynamicMembership): any;
export declare function dataAzureadGroupDynamicMembershipToHclTerraform(struct?: DataAzureadGroupDynamicMembership): any;
export declare class DataAzureadGroupDynamicMembershipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadGroupDynamicMembership | undefined;
    set internalValue(value: DataAzureadGroupDynamicMembership | undefined);
    get enabled(): cdktn.IResolvable;
    get rule(): string;
}
export declare class DataAzureadGroupDynamicMembershipList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadGroupDynamicMembershipOutputReference;
}
export interface DataAzureadGroupTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#read DataAzureadGroup#read}
    */
    readonly read?: string;
}
export declare function dataAzureadGroupTimeoutsToTerraform(struct?: DataAzureadGroupTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadGroupTimeoutsToHclTerraform(struct?: DataAzureadGroupTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadGroupTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadGroupTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadGroupTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group azuread_group}
*/
export declare class DataAzureadGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_group";
    /**
    * Generates CDKTN code for importing a DataAzureadGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadGroup to import
    * @param importFromId The id of the existing DataAzureadGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group azuread_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadGroupConfig);
    get assignableToRole(): cdktn.IResolvable;
    get autoSubscribeNewMembers(): cdktn.IResolvable;
    get behaviors(): string[];
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _dynamicMembership;
    get dynamicMembership(): DataAzureadGroupDynamicMembershipList;
    get externalSendersAllowed(): cdktn.IResolvable;
    get hideFromAddressLists(): cdktn.IResolvable;
    get hideFromOutlookClients(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeTransitiveMembers?;
    get includeTransitiveMembers(): boolean | cdktn.IResolvable;
    set includeTransitiveMembers(value: boolean | cdktn.IResolvable);
    resetIncludeTransitiveMembers(): void;
    get includeTransitiveMembersInput(): boolean | cdktn.IResolvable | undefined;
    get mail(): string;
    private _mailEnabled?;
    get mailEnabled(): boolean | cdktn.IResolvable;
    set mailEnabled(value: boolean | cdktn.IResolvable);
    resetMailEnabled(): void;
    get mailEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _mailNickname?;
    get mailNickname(): string;
    set mailNickname(value: string);
    resetMailNickname(): void;
    get mailNicknameInput(): string | undefined;
    get members(): string[];
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    get onpremisesDomainName(): string;
    get onpremisesGroupType(): string;
    get onpremisesNetbiosName(): string;
    get onpremisesSamAccountName(): string;
    get onpremisesSecurityIdentifier(): string;
    get onpremisesSyncEnabled(): cdktn.IResolvable;
    get owners(): string[];
    get preferredLanguage(): string;
    get provisioningOptions(): string[];
    get proxyAddresses(): string[];
    private _securityEnabled?;
    get securityEnabled(): boolean | cdktn.IResolvable;
    set securityEnabled(value: boolean | cdktn.IResolvable);
    resetSecurityEnabled(): void;
    get securityEnabledInput(): boolean | cdktn.IResolvable | undefined;
    get theme(): string;
    get types(): string[];
    get visibility(): string;
    get writebackEnabled(): cdktn.IResolvable;
    private _timeouts;
    get timeouts(): DataAzureadGroupTimeoutsOutputReference;
    putTimeouts(value: DataAzureadGroupTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadGroupTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
