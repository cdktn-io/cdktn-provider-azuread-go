/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuthenticationStrengthPolicyX509CombinationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * A set of allowed certificate issuer subject key identifier values
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#allowed_issuer_skis AuthenticationStrengthPolicyX509CombinationConfiguration#allowed_issuer_skis}
    */
    readonly allowedIssuerSkis?: string[];
    /**
    * A set of allowed certificate policy OIDs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#allowed_policy_oids AuthenticationStrengthPolicyX509CombinationConfiguration#allowed_policy_oids}
    */
    readonly allowedPolicyOids?: string[];
    /**
    * The x509 certificate authentication method combinations this configuration applies to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#applies_to_combinations AuthenticationStrengthPolicyX509CombinationConfiguration#applies_to_combinations}
    */
    readonly appliesToCombinations: string[];
    /**
    * The object ID of the authentication strength policy to which this combination configuration applies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#authentication_strength_policy_id AuthenticationStrengthPolicyX509CombinationConfiguration#authentication_strength_policy_id}
    */
    readonly authenticationStrengthPolicyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#id AuthenticationStrengthPolicyX509CombinationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#timeouts AuthenticationStrengthPolicyX509CombinationConfiguration#timeouts}
    */
    readonly timeouts?: AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts;
}
export interface AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#create AuthenticationStrengthPolicyX509CombinationConfiguration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#delete AuthenticationStrengthPolicyX509CombinationConfiguration#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#read AuthenticationStrengthPolicyX509CombinationConfiguration#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#update AuthenticationStrengthPolicyX509CombinationConfiguration#update}
    */
    readonly update?: string;
}
export declare function authenticationStrengthPolicyX509CombinationConfigurationTimeoutsToTerraform(struct?: AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts | cdktn.IResolvable): any;
export declare function authenticationStrengthPolicyX509CombinationConfigurationTimeoutsToHclTerraform(struct?: AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts | cdktn.IResolvable): any;
export declare class AuthenticationStrengthPolicyX509CombinationConfigurationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration azuread_authentication_strength_policy_x509_combination_configuration}
*/
export declare class AuthenticationStrengthPolicyX509CombinationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_authentication_strength_policy_x509_combination_configuration";
    /**
    * Generates CDKTN code for importing a AuthenticationStrengthPolicyX509CombinationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthenticationStrengthPolicyX509CombinationConfiguration to import
    * @param importFromId The id of the existing AuthenticationStrengthPolicyX509CombinationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthenticationStrengthPolicyX509CombinationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_x509_combination_configuration azuread_authentication_strength_policy_x509_combination_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthenticationStrengthPolicyX509CombinationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AuthenticationStrengthPolicyX509CombinationConfigurationConfig);
    private _allowedIssuerSkis?;
    get allowedIssuerSkis(): string[];
    set allowedIssuerSkis(value: string[]);
    resetAllowedIssuerSkis(): void;
    get allowedIssuerSkisInput(): string[] | undefined;
    private _allowedPolicyOids?;
    get allowedPolicyOids(): string[];
    set allowedPolicyOids(value: string[]);
    resetAllowedPolicyOids(): void;
    get allowedPolicyOidsInput(): string[] | undefined;
    private _appliesToCombinations?;
    get appliesToCombinations(): string[];
    set appliesToCombinations(value: string[]);
    get appliesToCombinationsInput(): string[] | undefined;
    private _authenticationStrengthPolicyId?;
    get authenticationStrengthPolicyId(): string;
    set authenticationStrengthPolicyId(value: string);
    get authenticationStrengthPolicyIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AuthenticationStrengthPolicyX509CombinationConfigurationTimeoutsOutputReference;
    putTimeouts(value: AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AuthenticationStrengthPolicyX509CombinationConfigurationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
