/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadDirectoryRolesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_roles#id DataAzureadDirectoryRoles#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_roles#timeouts DataAzureadDirectoryRoles#timeouts}
    */
    readonly timeouts?: DataAzureadDirectoryRolesTimeouts;
}
export interface DataAzureadDirectoryRolesRoles {
}
export declare function dataAzureadDirectoryRolesRolesToTerraform(struct?: DataAzureadDirectoryRolesRoles): any;
export declare function dataAzureadDirectoryRolesRolesToHclTerraform(struct?: DataAzureadDirectoryRolesRoles): any;
export declare class DataAzureadDirectoryRolesRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadDirectoryRolesRoles | undefined;
    set internalValue(value: DataAzureadDirectoryRolesRoles | undefined);
    get description(): string;
    get displayName(): string;
    get objectId(): string;
    get templateId(): string;
}
export declare class DataAzureadDirectoryRolesRolesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadDirectoryRolesRolesOutputReference;
}
export interface DataAzureadDirectoryRolesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_roles#read DataAzureadDirectoryRoles#read}
    */
    readonly read?: string;
}
export declare function dataAzureadDirectoryRolesTimeoutsToTerraform(struct?: DataAzureadDirectoryRolesTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadDirectoryRolesTimeoutsToHclTerraform(struct?: DataAzureadDirectoryRolesTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadDirectoryRolesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadDirectoryRolesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadDirectoryRolesTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_roles azuread_directory_roles}
*/
export declare class DataAzureadDirectoryRoles extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_directory_roles";
    /**
    * Generates CDKTN code for importing a DataAzureadDirectoryRoles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadDirectoryRoles to import
    * @param importFromId The id of the existing DataAzureadDirectoryRoles that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_roles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadDirectoryRoles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_roles azuread_directory_roles} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadDirectoryRolesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadDirectoryRolesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get objectIds(): string[];
    private _roles;
    get roles(): DataAzureadDirectoryRolesRolesList;
    get templateIds(): string[];
    private _timeouts;
    get timeouts(): DataAzureadDirectoryRolesTimeoutsOutputReference;
    putTimeouts(value: DataAzureadDirectoryRolesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadDirectoryRolesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
