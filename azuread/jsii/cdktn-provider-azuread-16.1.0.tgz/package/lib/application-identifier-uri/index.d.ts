/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationIdentifierUriConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ID of the application to which the identifier URI should be added
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#application_id ApplicationIdentifierUri#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#id ApplicationIdentifierUri#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The user-defined URI or URI-like string that uniquely identifies an application within its Azure AD tenant, or within a verified custom domain if the application is multi-tenant
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#identifier_uri ApplicationIdentifierUri#identifier_uri}
    */
    readonly identifierUri: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#timeouts ApplicationIdentifierUri#timeouts}
    */
    readonly timeouts?: ApplicationIdentifierUriTimeouts;
}
export interface ApplicationIdentifierUriTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#create ApplicationIdentifierUri#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#delete ApplicationIdentifierUri#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#read ApplicationIdentifierUri#read}
    */
    readonly read?: string;
}
export declare function applicationIdentifierUriTimeoutsToTerraform(struct?: ApplicationIdentifierUriTimeouts | cdktn.IResolvable): any;
export declare function applicationIdentifierUriTimeoutsToHclTerraform(struct?: ApplicationIdentifierUriTimeouts | cdktn.IResolvable): any;
export declare class ApplicationIdentifierUriTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationIdentifierUriTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationIdentifierUriTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri azuread_application_identifier_uri}
*/
export declare class ApplicationIdentifierUri extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_identifier_uri";
    /**
    * Generates CDKTN code for importing a ApplicationIdentifierUri resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationIdentifierUri to import
    * @param importFromId The id of the existing ApplicationIdentifierUri that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationIdentifierUri to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_identifier_uri azuread_application_identifier_uri} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationIdentifierUriConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationIdentifierUriConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identifierUri?;
    get identifierUri(): string;
    set identifierUri(value: string);
    get identifierUriInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationIdentifierUriTimeoutsOutputReference;
    putTimeouts(value: ApplicationIdentifierUriTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationIdentifierUriTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
