/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupMemberConfig extends cdktn.TerraformMetaArguments {
    /**
    * The object ID of the group you want to add the member to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#group_object_id GroupMember#group_object_id}
    */
    readonly groupObjectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#id GroupMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the principal you want to add as a member to the group. Supported object types are Users, Groups or Service Principals
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#member_object_id GroupMember#member_object_id}
    */
    readonly memberObjectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#timeouts GroupMember#timeouts}
    */
    readonly timeouts?: GroupMemberTimeouts;
}
export interface GroupMemberTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#create GroupMember#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#delete GroupMember#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#read GroupMember#read}
    */
    readonly read?: string;
}
export declare function groupMemberTimeoutsToTerraform(struct?: GroupMemberTimeouts | cdktn.IResolvable): any;
export declare function groupMemberTimeoutsToHclTerraform(struct?: GroupMemberTimeouts | cdktn.IResolvable): any;
export declare class GroupMemberTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupMemberTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: GroupMemberTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member azuread_group_member}
*/
export declare class GroupMember extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_group_member";
    /**
    * Generates CDKTN code for importing a GroupMember resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupMember to import
    * @param importFromId The id of the existing GroupMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_member azuread_group_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupMemberConfig
    */
    constructor(scope: Construct, id: string, config: GroupMemberConfig);
    private _groupObjectId?;
    get groupObjectId(): string;
    set groupObjectId(value: string);
    get groupObjectIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberObjectId?;
    get memberObjectId(): string;
    set memberObjectId(value: string);
    get memberObjectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): GroupMemberTimeoutsOutputReference;
    putTimeouts(value: GroupMemberTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | GroupMemberTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
