/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupRoleManagementPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the group to which this policy is assigned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#group_id GroupRoleManagementPolicy#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#id GroupRoleManagementPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the role of this policy to the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#role_id GroupRoleManagementPolicy#role_id}
    */
    readonly roleId: string;
    /**
    * activation_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#activation_rules GroupRoleManagementPolicy#activation_rules}
    */
    readonly activationRules?: GroupRoleManagementPolicyActivationRules;
    /**
    * active_assignment_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#active_assignment_rules GroupRoleManagementPolicy#active_assignment_rules}
    */
    readonly activeAssignmentRules?: GroupRoleManagementPolicyActiveAssignmentRules;
    /**
    * eligible_assignment_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#eligible_assignment_rules GroupRoleManagementPolicy#eligible_assignment_rules}
    */
    readonly eligibleAssignmentRules?: GroupRoleManagementPolicyEligibleAssignmentRules;
    /**
    * notification_rules block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_rules GroupRoleManagementPolicy#notification_rules}
    */
    readonly notificationRules?: GroupRoleManagementPolicyNotificationRules;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#timeouts GroupRoleManagementPolicy#timeouts}
    */
    readonly timeouts?: GroupRoleManagementPolicyTimeouts;
}
export interface GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover {
    /**
    * The ID of the object to act as an approver
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#object_id GroupRoleManagementPolicy#object_id}
    */
    readonly objectId: string;
    /**
    * The type of object acting as an approver
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#type GroupRoleManagementPolicy#type}
    */
    readonly type?: string;
}
export declare function groupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverToTerraform(struct?: GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover | cdktn.IResolvable): any;
export declare function groupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverToHclTerraform(struct?: GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover | cdktn.IResolvable): any;
export declare class GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover | cdktn.IResolvable | undefined;
    set internalValue(value: GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover | cdktn.IResolvable | undefined);
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
}
export declare class GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverList extends cdktn.ComplexList {
    internalValue?: GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverOutputReference;
}
export interface GroupRoleManagementPolicyActivationRulesApprovalStage {
    /**
    * primary_approver block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#primary_approver GroupRoleManagementPolicy#primary_approver}
    */
    readonly primaryApprover: GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover[] | cdktn.IResolvable;
}
export declare function groupRoleManagementPolicyActivationRulesApprovalStageToTerraform(struct?: GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference | GroupRoleManagementPolicyActivationRulesApprovalStage): any;
export declare function groupRoleManagementPolicyActivationRulesApprovalStageToHclTerraform(struct?: GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference | GroupRoleManagementPolicyActivationRulesApprovalStage): any;
export declare class GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyActivationRulesApprovalStage | undefined;
    set internalValue(value: GroupRoleManagementPolicyActivationRulesApprovalStage | undefined);
    private _primaryApprover;
    get primaryApprover(): GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApproverList;
    putPrimaryApprover(value: GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover[] | cdktn.IResolvable): void;
    get primaryApproverInput(): cdktn.IResolvable | GroupRoleManagementPolicyActivationRulesApprovalStagePrimaryApprover[] | undefined;
}
export interface GroupRoleManagementPolicyActivationRules {
    /**
    * The time after which the an activation can be valid for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#maximum_duration GroupRoleManagementPolicy#maximum_duration}
    */
    readonly maximumDuration?: string;
    /**
    * Whether an approval is required for activation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#require_approval GroupRoleManagementPolicy#require_approval}
    */
    readonly requireApproval?: boolean | cdktn.IResolvable;
    /**
    * Whether a justification is required during activation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
    */
    readonly requireJustification?: boolean | cdktn.IResolvable;
    /**
    * Whether multi-factor authentication is required during activation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
    */
    readonly requireMultifactorAuthentication?: boolean | cdktn.IResolvable;
    /**
    * Whether ticket information is required during activation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
    */
    readonly requireTicketInfo?: boolean | cdktn.IResolvable;
    /**
    * Whether a conditional access context is required during activation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#required_conditional_access_authentication_context GroupRoleManagementPolicy#required_conditional_access_authentication_context}
    */
    readonly requiredConditionalAccessAuthenticationContext?: string;
    /**
    * approval_stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#approval_stage GroupRoleManagementPolicy#approval_stage}
    */
    readonly approvalStage?: GroupRoleManagementPolicyActivationRulesApprovalStage;
}
export declare function groupRoleManagementPolicyActivationRulesToTerraform(struct?: GroupRoleManagementPolicyActivationRulesOutputReference | GroupRoleManagementPolicyActivationRules): any;
export declare function groupRoleManagementPolicyActivationRulesToHclTerraform(struct?: GroupRoleManagementPolicyActivationRulesOutputReference | GroupRoleManagementPolicyActivationRules): any;
export declare class GroupRoleManagementPolicyActivationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyActivationRules | undefined;
    set internalValue(value: GroupRoleManagementPolicyActivationRules | undefined);
    private _maximumDuration?;
    get maximumDuration(): string;
    set maximumDuration(value: string);
    resetMaximumDuration(): void;
    get maximumDurationInput(): string | undefined;
    private _requireApproval?;
    get requireApproval(): boolean | cdktn.IResolvable;
    set requireApproval(value: boolean | cdktn.IResolvable);
    resetRequireApproval(): void;
    get requireApprovalInput(): boolean | cdktn.IResolvable | undefined;
    private _requireJustification?;
    get requireJustification(): boolean | cdktn.IResolvable;
    set requireJustification(value: boolean | cdktn.IResolvable);
    resetRequireJustification(): void;
    get requireJustificationInput(): boolean | cdktn.IResolvable | undefined;
    private _requireMultifactorAuthentication?;
    get requireMultifactorAuthentication(): boolean | cdktn.IResolvable;
    set requireMultifactorAuthentication(value: boolean | cdktn.IResolvable);
    resetRequireMultifactorAuthentication(): void;
    get requireMultifactorAuthenticationInput(): boolean | cdktn.IResolvable | undefined;
    private _requireTicketInfo?;
    get requireTicketInfo(): boolean | cdktn.IResolvable;
    set requireTicketInfo(value: boolean | cdktn.IResolvable);
    resetRequireTicketInfo(): void;
    get requireTicketInfoInput(): boolean | cdktn.IResolvable | undefined;
    private _requiredConditionalAccessAuthenticationContext?;
    get requiredConditionalAccessAuthenticationContext(): string;
    set requiredConditionalAccessAuthenticationContext(value: string);
    resetRequiredConditionalAccessAuthenticationContext(): void;
    get requiredConditionalAccessAuthenticationContextInput(): string | undefined;
    private _approvalStage;
    get approvalStage(): GroupRoleManagementPolicyActivationRulesApprovalStageOutputReference;
    putApprovalStage(value: GroupRoleManagementPolicyActivationRulesApprovalStage): void;
    resetApprovalStage(): void;
    get approvalStageInput(): GroupRoleManagementPolicyActivationRulesApprovalStage | undefined;
}
export interface GroupRoleManagementPolicyActiveAssignmentRules {
    /**
    * Must the assignment have an expiry date
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
    */
    readonly expirationRequired?: boolean | cdktn.IResolvable;
    /**
    * The duration after which assignments expire
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
    */
    readonly expireAfter?: string;
    /**
    * Whether a justification is required to make an assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#require_justification GroupRoleManagementPolicy#require_justification}
    */
    readonly requireJustification?: boolean | cdktn.IResolvable;
    /**
    * Whether multi-factor authentication is required to make an assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#require_multifactor_authentication GroupRoleManagementPolicy#require_multifactor_authentication}
    */
    readonly requireMultifactorAuthentication?: boolean | cdktn.IResolvable;
    /**
    * Whether ticket information is required to make an assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#require_ticket_info GroupRoleManagementPolicy#require_ticket_info}
    */
    readonly requireTicketInfo?: boolean | cdktn.IResolvable;
}
export declare function groupRoleManagementPolicyActiveAssignmentRulesToTerraform(struct?: GroupRoleManagementPolicyActiveAssignmentRulesOutputReference | GroupRoleManagementPolicyActiveAssignmentRules): any;
export declare function groupRoleManagementPolicyActiveAssignmentRulesToHclTerraform(struct?: GroupRoleManagementPolicyActiveAssignmentRulesOutputReference | GroupRoleManagementPolicyActiveAssignmentRules): any;
export declare class GroupRoleManagementPolicyActiveAssignmentRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyActiveAssignmentRules | undefined;
    set internalValue(value: GroupRoleManagementPolicyActiveAssignmentRules | undefined);
    private _expirationRequired?;
    get expirationRequired(): boolean | cdktn.IResolvable;
    set expirationRequired(value: boolean | cdktn.IResolvable);
    resetExpirationRequired(): void;
    get expirationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _expireAfter?;
    get expireAfter(): string;
    set expireAfter(value: string);
    resetExpireAfter(): void;
    get expireAfterInput(): string | undefined;
    private _requireJustification?;
    get requireJustification(): boolean | cdktn.IResolvable;
    set requireJustification(value: boolean | cdktn.IResolvable);
    resetRequireJustification(): void;
    get requireJustificationInput(): boolean | cdktn.IResolvable | undefined;
    private _requireMultifactorAuthentication?;
    get requireMultifactorAuthentication(): boolean | cdktn.IResolvable;
    set requireMultifactorAuthentication(value: boolean | cdktn.IResolvable);
    resetRequireMultifactorAuthentication(): void;
    get requireMultifactorAuthenticationInput(): boolean | cdktn.IResolvable | undefined;
    private _requireTicketInfo?;
    get requireTicketInfo(): boolean | cdktn.IResolvable;
    set requireTicketInfo(value: boolean | cdktn.IResolvable);
    resetRequireTicketInfo(): void;
    get requireTicketInfoInput(): boolean | cdktn.IResolvable | undefined;
}
export interface GroupRoleManagementPolicyEligibleAssignmentRules {
    /**
    * Must the assignment have an expiry date
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#expiration_required GroupRoleManagementPolicy#expiration_required}
    */
    readonly expirationRequired?: boolean | cdktn.IResolvable;
    /**
    * The duration after which assignments expire
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#expire_after GroupRoleManagementPolicy#expire_after}
    */
    readonly expireAfter?: string;
}
export declare function groupRoleManagementPolicyEligibleAssignmentRulesToTerraform(struct?: GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference | GroupRoleManagementPolicyEligibleAssignmentRules): any;
export declare function groupRoleManagementPolicyEligibleAssignmentRulesToHclTerraform(struct?: GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference | GroupRoleManagementPolicyEligibleAssignmentRules): any;
export declare class GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyEligibleAssignmentRules | undefined;
    set internalValue(value: GroupRoleManagementPolicyEligibleAssignmentRules | undefined);
    private _expirationRequired?;
    get expirationRequired(): boolean | cdktn.IResolvable;
    set expirationRequired(value: boolean | cdktn.IResolvable);
    resetExpirationRequired(): void;
    get expirationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _expireAfter?;
    get expireAfter(): string;
    set expireAfter(value: string);
    resetExpireAfter(): void;
    get expireAfterInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesActiveAssignments {
    /**
    * admin_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
    */
    readonly adminNotifications?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications;
    /**
    * approver_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
    */
    readonly approverNotifications?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications;
    /**
    * assignee_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
    */
    readonly assigneeNotifications?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications;
}
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignments): any;
export declare function groupRoleManagementPolicyNotificationRulesActiveAssignmentsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference | GroupRoleManagementPolicyNotificationRulesActiveAssignments): any;
export declare class GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesActiveAssignments | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesActiveAssignments | undefined);
    private _adminNotifications;
    get adminNotifications(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotificationsOutputReference;
    putAdminNotifications(value: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications): void;
    resetAdminNotifications(): void;
    get adminNotificationsInput(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAdminNotifications | undefined;
    private _approverNotifications;
    get approverNotifications(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotificationsOutputReference;
    putApproverNotifications(value: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications): void;
    resetApproverNotifications(): void;
    get approverNotificationsInput(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsApproverNotifications | undefined;
    private _assigneeNotifications;
    get assigneeNotifications(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotificationsOutputReference;
    putAssigneeNotifications(value: GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications): void;
    resetAssigneeNotifications(): void;
    get assigneeNotificationsInput(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsAssigneeNotifications | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleActivations {
    /**
    * admin_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
    */
    readonly adminNotifications?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications;
    /**
    * approver_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
    */
    readonly approverNotifications?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications;
    /**
    * assignee_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
    */
    readonly assigneeNotifications?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivations): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleActivationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleActivations): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleActivations | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleActivations | undefined);
    private _adminNotifications;
    get adminNotifications(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotificationsOutputReference;
    putAdminNotifications(value: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications): void;
    resetAdminNotifications(): void;
    get adminNotificationsInput(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsAdminNotifications | undefined;
    private _approverNotifications;
    get approverNotifications(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotificationsOutputReference;
    putApproverNotifications(value: GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications): void;
    resetApproverNotifications(): void;
    get approverNotificationsInput(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsApproverNotifications | undefined;
    private _assigneeNotifications;
    get assigneeNotifications(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotificationsOutputReference;
    putAssigneeNotifications(value: GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications): void;
    resetAssigneeNotifications(): void;
    get assigneeNotificationsInput(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsAssigneeNotifications | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications {
    /**
    * The additional recipients to notify
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#additional_recipients GroupRoleManagementPolicy#additional_recipients}
    */
    readonly additionalRecipients?: string[];
    /**
    * Whether the default recipients are notified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#default_recipients GroupRoleManagementPolicy#default_recipients}
    */
    readonly defaultRecipients: boolean | cdktn.IResolvable;
    /**
    * What level of notifications are sent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#notification_level GroupRoleManagementPolicy#notification_level}
    */
    readonly notificationLevel: string;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications | undefined);
    private _additionalRecipients?;
    get additionalRecipients(): string[];
    set additionalRecipients(value: string[]);
    resetAdditionalRecipients(): void;
    get additionalRecipientsInput(): string[] | undefined;
    private _defaultRecipients?;
    get defaultRecipients(): boolean | cdktn.IResolvable;
    set defaultRecipients(value: boolean | cdktn.IResolvable);
    get defaultRecipientsInput(): boolean | cdktn.IResolvable | undefined;
    private _notificationLevel?;
    get notificationLevel(): string;
    set notificationLevel(value: string);
    get notificationLevelInput(): string | undefined;
}
export interface GroupRoleManagementPolicyNotificationRulesEligibleAssignments {
    /**
    * admin_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#admin_notifications GroupRoleManagementPolicy#admin_notifications}
    */
    readonly adminNotifications?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications;
    /**
    * approver_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#approver_notifications GroupRoleManagementPolicy#approver_notifications}
    */
    readonly approverNotifications?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications;
    /**
    * assignee_notifications block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#assignee_notifications GroupRoleManagementPolicy#assignee_notifications}
    */
    readonly assigneeNotifications?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications;
}
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignments): any;
export declare function groupRoleManagementPolicyNotificationRulesEligibleAssignmentsToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference | GroupRoleManagementPolicyNotificationRulesEligibleAssignments): any;
export declare class GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRulesEligibleAssignments | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignments | undefined);
    private _adminNotifications;
    get adminNotifications(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotificationsOutputReference;
    putAdminNotifications(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications): void;
    resetAdminNotifications(): void;
    get adminNotificationsInput(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAdminNotifications | undefined;
    private _approverNotifications;
    get approverNotifications(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotificationsOutputReference;
    putApproverNotifications(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications): void;
    resetApproverNotifications(): void;
    get approverNotificationsInput(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsApproverNotifications | undefined;
    private _assigneeNotifications;
    get assigneeNotifications(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotificationsOutputReference;
    putAssigneeNotifications(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications): void;
    resetAssigneeNotifications(): void;
    get assigneeNotificationsInput(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsAssigneeNotifications | undefined;
}
export interface GroupRoleManagementPolicyNotificationRules {
    /**
    * active_assignments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#active_assignments GroupRoleManagementPolicy#active_assignments}
    */
    readonly activeAssignments?: GroupRoleManagementPolicyNotificationRulesActiveAssignments;
    /**
    * eligible_activations block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#eligible_activations GroupRoleManagementPolicy#eligible_activations}
    */
    readonly eligibleActivations?: GroupRoleManagementPolicyNotificationRulesEligibleActivations;
    /**
    * eligible_assignments block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#eligible_assignments GroupRoleManagementPolicy#eligible_assignments}
    */
    readonly eligibleAssignments?: GroupRoleManagementPolicyNotificationRulesEligibleAssignments;
}
export declare function groupRoleManagementPolicyNotificationRulesToTerraform(struct?: GroupRoleManagementPolicyNotificationRulesOutputReference | GroupRoleManagementPolicyNotificationRules): any;
export declare function groupRoleManagementPolicyNotificationRulesToHclTerraform(struct?: GroupRoleManagementPolicyNotificationRulesOutputReference | GroupRoleManagementPolicyNotificationRules): any;
export declare class GroupRoleManagementPolicyNotificationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyNotificationRules | undefined;
    set internalValue(value: GroupRoleManagementPolicyNotificationRules | undefined);
    private _activeAssignments;
    get activeAssignments(): GroupRoleManagementPolicyNotificationRulesActiveAssignmentsOutputReference;
    putActiveAssignments(value: GroupRoleManagementPolicyNotificationRulesActiveAssignments): void;
    resetActiveAssignments(): void;
    get activeAssignmentsInput(): GroupRoleManagementPolicyNotificationRulesActiveAssignments | undefined;
    private _eligibleActivations;
    get eligibleActivations(): GroupRoleManagementPolicyNotificationRulesEligibleActivationsOutputReference;
    putEligibleActivations(value: GroupRoleManagementPolicyNotificationRulesEligibleActivations): void;
    resetEligibleActivations(): void;
    get eligibleActivationsInput(): GroupRoleManagementPolicyNotificationRulesEligibleActivations | undefined;
    private _eligibleAssignments;
    get eligibleAssignments(): GroupRoleManagementPolicyNotificationRulesEligibleAssignmentsOutputReference;
    putEligibleAssignments(value: GroupRoleManagementPolicyNotificationRulesEligibleAssignments): void;
    resetEligibleAssignments(): void;
    get eligibleAssignmentsInput(): GroupRoleManagementPolicyNotificationRulesEligibleAssignments | undefined;
}
export interface GroupRoleManagementPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#create GroupRoleManagementPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#delete GroupRoleManagementPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#read GroupRoleManagementPolicy#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#update GroupRoleManagementPolicy#update}
    */
    readonly update?: string;
}
export declare function groupRoleManagementPolicyTimeoutsToTerraform(struct?: GroupRoleManagementPolicyTimeouts | cdktn.IResolvable): any;
export declare function groupRoleManagementPolicyTimeoutsToHclTerraform(struct?: GroupRoleManagementPolicyTimeouts | cdktn.IResolvable): any;
export declare class GroupRoleManagementPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupRoleManagementPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: GroupRoleManagementPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy azuread_group_role_management_policy}
*/
export declare class GroupRoleManagementPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_group_role_management_policy";
    /**
    * Generates CDKTN code for importing a GroupRoleManagementPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupRoleManagementPolicy to import
    * @param importFromId The id of the existing GroupRoleManagementPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupRoleManagementPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/group_role_management_policy azuread_group_role_management_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupRoleManagementPolicyConfig
    */
    constructor(scope: Construct, id: string, config: GroupRoleManagementPolicyConfig);
    get description(): string;
    get displayName(): string;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    private _activationRules;
    get activationRules(): GroupRoleManagementPolicyActivationRulesOutputReference;
    putActivationRules(value: GroupRoleManagementPolicyActivationRules): void;
    resetActivationRules(): void;
    get activationRulesInput(): GroupRoleManagementPolicyActivationRules | undefined;
    private _activeAssignmentRules;
    get activeAssignmentRules(): GroupRoleManagementPolicyActiveAssignmentRulesOutputReference;
    putActiveAssignmentRules(value: GroupRoleManagementPolicyActiveAssignmentRules): void;
    resetActiveAssignmentRules(): void;
    get activeAssignmentRulesInput(): GroupRoleManagementPolicyActiveAssignmentRules | undefined;
    private _eligibleAssignmentRules;
    get eligibleAssignmentRules(): GroupRoleManagementPolicyEligibleAssignmentRulesOutputReference;
    putEligibleAssignmentRules(value: GroupRoleManagementPolicyEligibleAssignmentRules): void;
    resetEligibleAssignmentRules(): void;
    get eligibleAssignmentRulesInput(): GroupRoleManagementPolicyEligibleAssignmentRules | undefined;
    private _notificationRules;
    get notificationRules(): GroupRoleManagementPolicyNotificationRulesOutputReference;
    putNotificationRules(value: GroupRoleManagementPolicyNotificationRules): void;
    resetNotificationRules(): void;
    get notificationRulesInput(): GroupRoleManagementPolicyNotificationRules | undefined;
    private _timeouts;
    get timeouts(): GroupRoleManagementPolicyTimeoutsOutputReference;
    putTimeouts(value: GroupRoleManagementPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | GroupRoleManagementPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
