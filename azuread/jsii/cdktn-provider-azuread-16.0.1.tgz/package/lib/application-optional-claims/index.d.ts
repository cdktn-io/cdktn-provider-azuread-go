/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationOptionalClaimsAConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ID of the application to which these optional claims belong
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#application_id ApplicationOptionalClaimsA#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#id ApplicationOptionalClaimsA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * access_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#access_token ApplicationOptionalClaimsA#access_token}
    */
    readonly accessToken?: ApplicationOptionalClaimsAccessTokenA[] | cdktn.IResolvable;
    /**
    * id_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#id_token ApplicationOptionalClaimsA#id_token}
    */
    readonly idToken?: ApplicationOptionalClaimsIdTokenA[] | cdktn.IResolvable;
    /**
    * saml2_token block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#saml2_token ApplicationOptionalClaimsA#saml2_token}
    */
    readonly saml2Token?: ApplicationOptionalClaimsSaml2TokenA[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#timeouts ApplicationOptionalClaimsA#timeouts}
    */
    readonly timeouts?: ApplicationOptionalClaimsTimeouts;
}
export interface ApplicationOptionalClaimsAccessTokenA {
    /**
    * List of additional properties of the claim. If a property exists in this list, it modifies the behaviour of the optional claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#additional_properties ApplicationOptionalClaimsA#additional_properties}
    */
    readonly additionalProperties?: string[];
    /**
    * Whether the claim specified by the client is necessary to ensure a smooth authorization experience
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#essential ApplicationOptionalClaimsA#essential}
    */
    readonly essential?: boolean | cdktn.IResolvable;
    /**
    * The name of the optional claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#name ApplicationOptionalClaimsA#name}
    */
    readonly name: string;
    /**
    * The source of the claim. If `source` is absent, the claim is a predefined optional claim. If `source` is `user`, the value of `name` is the extension property from the user object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#source ApplicationOptionalClaimsA#source}
    */
    readonly source?: string;
}
export declare function applicationOptionalClaimsAccessTokenAToTerraform(struct?: ApplicationOptionalClaimsAccessTokenA | cdktn.IResolvable): any;
export declare function applicationOptionalClaimsAccessTokenAToHclTerraform(struct?: ApplicationOptionalClaimsAccessTokenA | cdktn.IResolvable): any;
export declare class ApplicationOptionalClaimsAccessTokenAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationOptionalClaimsAccessTokenA | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationOptionalClaimsAccessTokenA | cdktn.IResolvable | undefined);
    private _additionalProperties?;
    get additionalProperties(): string[];
    set additionalProperties(value: string[]);
    resetAdditionalProperties(): void;
    get additionalPropertiesInput(): string[] | undefined;
    private _essential?;
    get essential(): boolean | cdktn.IResolvable;
    set essential(value: boolean | cdktn.IResolvable);
    resetEssential(): void;
    get essentialInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class ApplicationOptionalClaimsAccessTokenAList extends cdktn.ComplexList {
    internalValue?: ApplicationOptionalClaimsAccessTokenA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationOptionalClaimsAccessTokenAOutputReference;
}
export interface ApplicationOptionalClaimsIdTokenA {
    /**
    * List of additional properties of the claim. If a property exists in this list, it modifies the behaviour of the optional claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#additional_properties ApplicationOptionalClaimsA#additional_properties}
    */
    readonly additionalProperties?: string[];
    /**
    * Whether the claim specified by the client is necessary to ensure a smooth authorization experience
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#essential ApplicationOptionalClaimsA#essential}
    */
    readonly essential?: boolean | cdktn.IResolvable;
    /**
    * The name of the optional claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#name ApplicationOptionalClaimsA#name}
    */
    readonly name: string;
    /**
    * The source of the claim. If `source` is absent, the claim is a predefined optional claim. If `source` is `user`, the value of `name` is the extension property from the user object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#source ApplicationOptionalClaimsA#source}
    */
    readonly source?: string;
}
export declare function applicationOptionalClaimsIdTokenAToTerraform(struct?: ApplicationOptionalClaimsIdTokenA | cdktn.IResolvable): any;
export declare function applicationOptionalClaimsIdTokenAToHclTerraform(struct?: ApplicationOptionalClaimsIdTokenA | cdktn.IResolvable): any;
export declare class ApplicationOptionalClaimsIdTokenAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationOptionalClaimsIdTokenA | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationOptionalClaimsIdTokenA | cdktn.IResolvable | undefined);
    private _additionalProperties?;
    get additionalProperties(): string[];
    set additionalProperties(value: string[]);
    resetAdditionalProperties(): void;
    get additionalPropertiesInput(): string[] | undefined;
    private _essential?;
    get essential(): boolean | cdktn.IResolvable;
    set essential(value: boolean | cdktn.IResolvable);
    resetEssential(): void;
    get essentialInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class ApplicationOptionalClaimsIdTokenAList extends cdktn.ComplexList {
    internalValue?: ApplicationOptionalClaimsIdTokenA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationOptionalClaimsIdTokenAOutputReference;
}
export interface ApplicationOptionalClaimsSaml2TokenA {
    /**
    * List of additional properties of the claim. If a property exists in this list, it modifies the behaviour of the optional claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#additional_properties ApplicationOptionalClaimsA#additional_properties}
    */
    readonly additionalProperties?: string[];
    /**
    * Whether the claim specified by the client is necessary to ensure a smooth authorization experience
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#essential ApplicationOptionalClaimsA#essential}
    */
    readonly essential?: boolean | cdktn.IResolvable;
    /**
    * The name of the optional claim
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#name ApplicationOptionalClaimsA#name}
    */
    readonly name: string;
    /**
    * The source of the claim. If `source` is absent, the claim is a predefined optional claim. If `source` is `user`, the value of `name` is the extension property from the user object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#source ApplicationOptionalClaimsA#source}
    */
    readonly source?: string;
}
export declare function applicationOptionalClaimsSaml2TokenAToTerraform(struct?: ApplicationOptionalClaimsSaml2TokenA | cdktn.IResolvable): any;
export declare function applicationOptionalClaimsSaml2TokenAToHclTerraform(struct?: ApplicationOptionalClaimsSaml2TokenA | cdktn.IResolvable): any;
export declare class ApplicationOptionalClaimsSaml2TokenAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): ApplicationOptionalClaimsSaml2TokenA | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationOptionalClaimsSaml2TokenA | cdktn.IResolvable | undefined);
    private _additionalProperties?;
    get additionalProperties(): string[];
    set additionalProperties(value: string[]);
    resetAdditionalProperties(): void;
    get additionalPropertiesInput(): string[] | undefined;
    private _essential?;
    get essential(): boolean | cdktn.IResolvable;
    set essential(value: boolean | cdktn.IResolvable);
    resetEssential(): void;
    get essentialInput(): boolean | cdktn.IResolvable | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _source?;
    get source(): string;
    set source(value: string);
    resetSource(): void;
    get sourceInput(): string | undefined;
}
export declare class ApplicationOptionalClaimsSaml2TokenAList extends cdktn.ComplexList {
    internalValue?: ApplicationOptionalClaimsSaml2TokenA[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): ApplicationOptionalClaimsSaml2TokenAOutputReference;
}
export interface ApplicationOptionalClaimsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#create ApplicationOptionalClaimsA#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#delete ApplicationOptionalClaimsA#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#read ApplicationOptionalClaimsA#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#update ApplicationOptionalClaimsA#update}
    */
    readonly update?: string;
}
export declare function applicationOptionalClaimsTimeoutsToTerraform(struct?: ApplicationOptionalClaimsTimeouts | cdktn.IResolvable): any;
export declare function applicationOptionalClaimsTimeoutsToHclTerraform(struct?: ApplicationOptionalClaimsTimeouts | cdktn.IResolvable): any;
export declare class ApplicationOptionalClaimsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationOptionalClaimsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationOptionalClaimsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims azuread_application_optional_claims}
*/
export declare class ApplicationOptionalClaimsA extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_optional_claims";
    /**
    * Generates CDKTN code for importing a ApplicationOptionalClaimsA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationOptionalClaimsA to import
    * @param importFromId The id of the existing ApplicationOptionalClaimsA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationOptionalClaimsA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_optional_claims azuread_application_optional_claims} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationOptionalClaimsAConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationOptionalClaimsAConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _accessToken;
    get accessToken(): ApplicationOptionalClaimsAccessTokenAList;
    putAccessToken(value: ApplicationOptionalClaimsAccessTokenA[] | cdktn.IResolvable): void;
    resetAccessToken(): void;
    get accessTokenInput(): cdktn.IResolvable | ApplicationOptionalClaimsAccessTokenA[] | undefined;
    private _idToken;
    get idToken(): ApplicationOptionalClaimsIdTokenAList;
    putIdToken(value: ApplicationOptionalClaimsIdTokenA[] | cdktn.IResolvable): void;
    resetIdToken(): void;
    get idTokenInput(): cdktn.IResolvable | ApplicationOptionalClaimsIdTokenA[] | undefined;
    private _saml2Token;
    get saml2Token(): ApplicationOptionalClaimsSaml2TokenAList;
    putSaml2Token(value: ApplicationOptionalClaimsSaml2TokenA[] | cdktn.IResolvable): void;
    resetSaml2Token(): void;
    get saml2TokenInput(): cdktn.IResolvable | ApplicationOptionalClaimsSaml2TokenA[] | undefined;
    private _timeouts;
    get timeouts(): ApplicationOptionalClaimsTimeoutsOutputReference;
    putTimeouts(value: ApplicationOptionalClaimsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationOptionalClaimsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
