/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AppRoleAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the app role to be assigned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#app_role_id AppRoleAssignment#app_role_id}
    */
    readonly appRoleId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#id AppRoleAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the user, group or service principal to be assigned this app role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#principal_object_id AppRoleAssignment#principal_object_id}
    */
    readonly principalObjectId: string;
    /**
    * The object ID of the service principal representing the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#resource_object_id AppRoleAssignment#resource_object_id}
    */
    readonly resourceObjectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#timeouts AppRoleAssignment#timeouts}
    */
    readonly timeouts?: AppRoleAssignmentTimeouts;
}
export interface AppRoleAssignmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#create AppRoleAssignment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#delete AppRoleAssignment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#read AppRoleAssignment#read}
    */
    readonly read?: string;
}
export declare function appRoleAssignmentTimeoutsToTerraform(struct?: AppRoleAssignmentTimeouts | cdktn.IResolvable): any;
export declare function appRoleAssignmentTimeoutsToHclTerraform(struct?: AppRoleAssignmentTimeouts | cdktn.IResolvable): any;
export declare class AppRoleAssignmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AppRoleAssignmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AppRoleAssignmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment azuread_app_role_assignment}
*/
export declare class AppRoleAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_app_role_assignment";
    /**
    * Generates CDKTN code for importing a AppRoleAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AppRoleAssignment to import
    * @param importFromId The id of the existing AppRoleAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AppRoleAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/app_role_assignment azuread_app_role_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AppRoleAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: AppRoleAssignmentConfig);
    private _appRoleId?;
    get appRoleId(): string;
    set appRoleId(value: string);
    get appRoleIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get principalDisplayName(): string;
    private _principalObjectId?;
    get principalObjectId(): string;
    set principalObjectId(value: string);
    get principalObjectIdInput(): string | undefined;
    get principalType(): string;
    get resourceDisplayName(): string;
    private _resourceObjectId?;
    get resourceObjectId(): string;
    set resourceObjectId(value: string);
    get resourceObjectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AppRoleAssignmentTimeoutsOutputReference;
    putTimeouts(value: AppRoleAssignmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AppRoleAssignmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
