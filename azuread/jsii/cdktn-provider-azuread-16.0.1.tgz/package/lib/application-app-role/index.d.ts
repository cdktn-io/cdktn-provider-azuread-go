/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationAppRoleAConfig extends cdktn.TerraformMetaArguments {
    /**
    * Specifies whether this app role definition can be assigned to users and groups by setting to `User`, or to other applications (that are accessing this application in a standalone scenario) by setting to `Application`, or to both
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#allowed_member_types ApplicationAppRoleA#allowed_member_types}
    */
    readonly allowedMemberTypes: string[];
    /**
    * The resource ID of the application to which this app role should be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#application_id ApplicationAppRoleA#application_id}
    */
    readonly applicationId: string;
    /**
    * Description of the app role that appears when the role is being assigned and, if the role functions as an application permissions, during the consent experiences
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#description ApplicationAppRoleA#description}
    */
    readonly description: string;
    /**
    * Display name for the app role that appears during app role assignment and in consent experiences
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#display_name ApplicationAppRoleA#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#id ApplicationAppRoleA#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier of the app role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#role_id ApplicationAppRoleA#role_id}
    */
    readonly roleId: string;
    /**
    * The value that is used for the `roles` claim in ID tokens and OAuth access tokens that are authenticating an assigned service or user principal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#value ApplicationAppRoleA#value}
    */
    readonly value?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#timeouts ApplicationAppRoleA#timeouts}
    */
    readonly timeouts?: ApplicationAppRoleTimeouts;
}
export interface ApplicationAppRoleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#create ApplicationAppRoleA#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#delete ApplicationAppRoleA#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#read ApplicationAppRoleA#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#update ApplicationAppRoleA#update}
    */
    readonly update?: string;
}
export declare function applicationAppRoleTimeoutsToTerraform(struct?: ApplicationAppRoleTimeouts | cdktn.IResolvable): any;
export declare function applicationAppRoleTimeoutsToHclTerraform(struct?: ApplicationAppRoleTimeouts | cdktn.IResolvable): any;
export declare class ApplicationAppRoleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationAppRoleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationAppRoleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role azuread_application_app_role}
*/
export declare class ApplicationAppRoleA extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_app_role";
    /**
    * Generates CDKTN code for importing a ApplicationAppRoleA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationAppRoleA to import
    * @param importFromId The id of the existing ApplicationAppRoleA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationAppRoleA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_app_role azuread_application_app_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationAppRoleAConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationAppRoleAConfig);
    private _allowedMemberTypes?;
    get allowedMemberTypes(): string[];
    set allowedMemberTypes(value: string[]);
    get allowedMemberTypesInput(): string[] | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    resetValue(): void;
    get valueInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationAppRoleTimeoutsOutputReference;
    putTimeouts(value: ApplicationAppRoleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationAppRoleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
