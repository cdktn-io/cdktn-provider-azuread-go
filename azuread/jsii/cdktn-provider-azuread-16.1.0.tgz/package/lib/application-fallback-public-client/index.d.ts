/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationFallbackPublicClientConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ID of the application to which the fallback public client setting should be applied
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#application_id ApplicationFallbackPublicClient#application_id}
    */
    readonly applicationId: string;
    /**
    * Specifies explicitly whether the application is a public client. Appropriate for apps using token grant flows that don't use a redirect URI
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#enabled ApplicationFallbackPublicClient#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#id ApplicationFallbackPublicClient#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#timeouts ApplicationFallbackPublicClient#timeouts}
    */
    readonly timeouts?: ApplicationFallbackPublicClientTimeouts;
}
export interface ApplicationFallbackPublicClientTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#create ApplicationFallbackPublicClient#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#delete ApplicationFallbackPublicClient#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#read ApplicationFallbackPublicClient#read}
    */
    readonly read?: string;
}
export declare function applicationFallbackPublicClientTimeoutsToTerraform(struct?: ApplicationFallbackPublicClientTimeouts | cdktn.IResolvable): any;
export declare function applicationFallbackPublicClientTimeoutsToHclTerraform(struct?: ApplicationFallbackPublicClientTimeouts | cdktn.IResolvable): any;
export declare class ApplicationFallbackPublicClientTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationFallbackPublicClientTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationFallbackPublicClientTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client azuread_application_fallback_public_client}
*/
export declare class ApplicationFallbackPublicClient extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_fallback_public_client";
    /**
    * Generates CDKTN code for importing a ApplicationFallbackPublicClient resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationFallbackPublicClient to import
    * @param importFromId The id of the existing ApplicationFallbackPublicClient that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationFallbackPublicClient to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_fallback_public_client azuread_application_fallback_public_client} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationFallbackPublicClientConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationFallbackPublicClientConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationFallbackPublicClientTimeoutsOutputReference;
    putTimeouts(value: ApplicationFallbackPublicClientTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationFallbackPublicClientTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
