/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectoryRoleEligibilityScheduleRequestConfig extends cdktn.TerraformMetaArguments {
    /**
    * Identifier of the directory object representing the scope of the role eligibility schedule request
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#directory_scope_id DirectoryRoleEligibilityScheduleRequest#directory_scope_id}
    */
    readonly directoryScopeId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#id DirectoryRoleEligibilityScheduleRequest#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Justification for why the role is assigned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#justification DirectoryRoleEligibilityScheduleRequest#justification}
    */
    readonly justification: string;
    /**
    * The object ID of the member principal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#principal_id DirectoryRoleEligibilityScheduleRequest#principal_id}
    */
    readonly principalId: string;
    /**
    * The object ID of the directory role for this role eligibility schedule request
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#role_definition_id DirectoryRoleEligibilityScheduleRequest#role_definition_id}
    */
    readonly roleDefinitionId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#timeouts DirectoryRoleEligibilityScheduleRequest#timeouts}
    */
    readonly timeouts?: DirectoryRoleEligibilityScheduleRequestTimeouts;
}
export interface DirectoryRoleEligibilityScheduleRequestTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#create DirectoryRoleEligibilityScheduleRequest#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#delete DirectoryRoleEligibilityScheduleRequest#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#read DirectoryRoleEligibilityScheduleRequest#read}
    */
    readonly read?: string;
}
export declare function directoryRoleEligibilityScheduleRequestTimeoutsToTerraform(struct?: DirectoryRoleEligibilityScheduleRequestTimeouts | cdktn.IResolvable): any;
export declare function directoryRoleEligibilityScheduleRequestTimeoutsToHclTerraform(struct?: DirectoryRoleEligibilityScheduleRequestTimeouts | cdktn.IResolvable): any;
export declare class DirectoryRoleEligibilityScheduleRequestTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectoryRoleEligibilityScheduleRequestTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DirectoryRoleEligibilityScheduleRequestTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request azuread_directory_role_eligibility_schedule_request}
*/
export declare class DirectoryRoleEligibilityScheduleRequest extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_directory_role_eligibility_schedule_request";
    /**
    * Generates CDKTN code for importing a DirectoryRoleEligibilityScheduleRequest resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectoryRoleEligibilityScheduleRequest to import
    * @param importFromId The id of the existing DirectoryRoleEligibilityScheduleRequest that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectoryRoleEligibilityScheduleRequest to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_eligibility_schedule_request azuread_directory_role_eligibility_schedule_request} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectoryRoleEligibilityScheduleRequestConfig
    */
    constructor(scope: Construct, id: string, config: DirectoryRoleEligibilityScheduleRequestConfig);
    private _directoryScopeId?;
    get directoryScopeId(): string;
    set directoryScopeId(value: string);
    get directoryScopeIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _justification?;
    get justification(): string;
    set justification(value: string);
    get justificationInput(): string | undefined;
    private _principalId?;
    get principalId(): string;
    set principalId(value: string);
    get principalIdInput(): string | undefined;
    private _roleDefinitionId?;
    get roleDefinitionId(): string;
    set roleDefinitionId(value: string);
    get roleDefinitionIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DirectoryRoleEligibilityScheduleRequestTimeoutsOutputReference;
    putTimeouts(value: DirectoryRoleEligibilityScheduleRequestTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DirectoryRoleEligibilityScheduleRequestTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
