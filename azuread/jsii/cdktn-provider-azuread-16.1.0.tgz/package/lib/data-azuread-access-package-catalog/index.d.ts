/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadAccessPackageCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * The display name of the access package catalog
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog#display_name DataAzureadAccessPackageCatalog#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog#id DataAzureadAccessPackageCatalog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of this access package catalog
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog#object_id DataAzureadAccessPackageCatalog#object_id}
    */
    readonly objectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog#timeouts DataAzureadAccessPackageCatalog#timeouts}
    */
    readonly timeouts?: DataAzureadAccessPackageCatalogTimeouts;
}
export interface DataAzureadAccessPackageCatalogTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog#read DataAzureadAccessPackageCatalog#read}
    */
    readonly read?: string;
}
export declare function dataAzureadAccessPackageCatalogTimeoutsToTerraform(struct?: DataAzureadAccessPackageCatalogTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadAccessPackageCatalogTimeoutsToHclTerraform(struct?: DataAzureadAccessPackageCatalogTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadAccessPackageCatalogTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadAccessPackageCatalogTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadAccessPackageCatalogTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog azuread_access_package_catalog}
*/
export declare class DataAzureadAccessPackageCatalog extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_access_package_catalog";
    /**
    * Generates CDKTN code for importing a DataAzureadAccessPackageCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadAccessPackageCatalog to import
    * @param importFromId The id of the existing DataAzureadAccessPackageCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadAccessPackageCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/access_package_catalog azuread_access_package_catalog} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadAccessPackageCatalogConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadAccessPackageCatalogConfig);
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get externallyVisible(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    get published(): cdktn.IResolvable;
    private _timeouts;
    get timeouts(): DataAzureadAccessPackageCatalogTimeoutsOutputReference;
    putTimeouts(value: DataAzureadAccessPackageCatalogTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadAccessPackageCatalogTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
