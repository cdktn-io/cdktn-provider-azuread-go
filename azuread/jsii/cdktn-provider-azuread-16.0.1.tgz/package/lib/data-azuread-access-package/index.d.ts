/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadAccessPackageConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Catalog this access package is in
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package#catalog_id DataAzureadAccessPackage#catalog_id}
    */
    readonly catalogId?: string;
    /**
    * The display name of the access package
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package#display_name DataAzureadAccessPackage#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package#id DataAzureadAccessPackage#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of this access package
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package#object_id DataAzureadAccessPackage#object_id}
    */
    readonly objectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package#timeouts DataAzureadAccessPackage#timeouts}
    */
    readonly timeouts?: DataAzureadAccessPackageTimeouts;
}
export interface DataAzureadAccessPackageTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package#read DataAzureadAccessPackage#read}
    */
    readonly read?: string;
}
export declare function dataAzureadAccessPackageTimeoutsToTerraform(struct?: DataAzureadAccessPackageTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadAccessPackageTimeoutsToHclTerraform(struct?: DataAzureadAccessPackageTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadAccessPackageTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadAccessPackageTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadAccessPackageTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package azuread_access_package}
*/
export declare class DataAzureadAccessPackage extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_access_package";
    /**
    * Generates CDKTN code for importing a DataAzureadAccessPackage resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadAccessPackage to import
    * @param importFromId The id of the existing DataAzureadAccessPackage that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadAccessPackage to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package azuread_access_package} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadAccessPackageConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadAccessPackageConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    resetCatalogId(): void;
    get catalogIdInput(): string | undefined;
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get hidden(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzureadAccessPackageTimeoutsOutputReference;
    putTimeouts(value: DataAzureadAccessPackageTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadAccessPackageTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
