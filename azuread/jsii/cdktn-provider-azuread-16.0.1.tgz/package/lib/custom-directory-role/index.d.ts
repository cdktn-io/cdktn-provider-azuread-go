/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface CustomDirectoryRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the custom directory role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#description CustomDirectoryRole#description}
    */
    readonly description?: string;
    /**
    * The display name of the custom directory role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#display_name CustomDirectoryRole#display_name}
    */
    readonly displayName: string;
    /**
    * Indicates whether the role is enabled for assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#enabled CustomDirectoryRole#enabled}
    */
    readonly enabled: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#id CustomDirectoryRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Custom template identifier that is typically used if one needs an identifier to be the same across different directories.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#template_id CustomDirectoryRole#template_id}
    */
    readonly templateId?: string;
    /**
    * The version of the role definition.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#version CustomDirectoryRole#version}
    */
    readonly version: string;
    /**
    * permissions block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#permissions CustomDirectoryRole#permissions}
    */
    readonly permissions: CustomDirectoryRolePermissions[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#timeouts CustomDirectoryRole#timeouts}
    */
    readonly timeouts?: CustomDirectoryRoleTimeouts;
}
export interface CustomDirectoryRolePermissions {
    /**
    * Set of tasks that can be performed on a resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#allowed_resource_actions CustomDirectoryRole#allowed_resource_actions}
    */
    readonly allowedResourceActions: string[];
}
export declare function customDirectoryRolePermissionsToTerraform(struct?: CustomDirectoryRolePermissions | cdktn.IResolvable): any;
export declare function customDirectoryRolePermissionsToHclTerraform(struct?: CustomDirectoryRolePermissions | cdktn.IResolvable): any;
export declare class CustomDirectoryRolePermissionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): CustomDirectoryRolePermissions | cdktn.IResolvable | undefined;
    set internalValue(value: CustomDirectoryRolePermissions | cdktn.IResolvable | undefined);
    private _allowedResourceActions?;
    get allowedResourceActions(): string[];
    set allowedResourceActions(value: string[]);
    get allowedResourceActionsInput(): string[] | undefined;
}
export declare class CustomDirectoryRolePermissionsList extends cdktn.ComplexList {
    internalValue?: CustomDirectoryRolePermissions[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): CustomDirectoryRolePermissionsOutputReference;
}
export interface CustomDirectoryRoleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#create CustomDirectoryRole#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#delete CustomDirectoryRole#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#read CustomDirectoryRole#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#update CustomDirectoryRole#update}
    */
    readonly update?: string;
}
export declare function customDirectoryRoleTimeoutsToTerraform(struct?: CustomDirectoryRoleTimeouts | cdktn.IResolvable): any;
export declare function customDirectoryRoleTimeoutsToHclTerraform(struct?: CustomDirectoryRoleTimeouts | cdktn.IResolvable): any;
export declare class CustomDirectoryRoleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): CustomDirectoryRoleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: CustomDirectoryRoleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role azuread_custom_directory_role}
*/
export declare class CustomDirectoryRole extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_custom_directory_role";
    /**
    * Generates CDKTN code for importing a CustomDirectoryRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the CustomDirectoryRole to import
    * @param importFromId The id of the existing CustomDirectoryRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the CustomDirectoryRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/custom_directory_role azuread_custom_directory_role} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options CustomDirectoryRoleConfig
    */
    constructor(scope: Construct, id: string, config: CustomDirectoryRoleConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get objectId(): string;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    resetTemplateId(): void;
    get templateIdInput(): string | undefined;
    private _version?;
    get version(): string;
    set version(value: string);
    get versionInput(): string | undefined;
    private _permissions;
    get permissions(): CustomDirectoryRolePermissionsList;
    putPermissions(value: CustomDirectoryRolePermissions[] | cdktn.IResolvable): void;
    get permissionsInput(): cdktn.IResolvable | CustomDirectoryRolePermissions[] | undefined;
    private _timeouts;
    get timeouts(): CustomDirectoryRoleTimeoutsOutputReference;
    putTimeouts(value: CustomDirectoryRoleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | CustomDirectoryRoleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
