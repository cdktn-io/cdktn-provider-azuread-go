/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface GroupLicenseConfig extends cdktn.TerraformMetaArguments {
    /**
    * A set of unique identifiers (GUIDs) for the service plans to disable for this license
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#disabled_plans GroupLicense#disabled_plans}
    */
    readonly disabledPlans?: string[];
    /**
    * The object ID of the group to which the license should be assigned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#group_object_id GroupLicense#group_object_id}
    */
    readonly groupObjectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#id GroupLicense#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier (GUID) for the SKU (license) to assign to the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#sku_id GroupLicense#sku_id}
    */
    readonly skuId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#timeouts GroupLicense#timeouts}
    */
    readonly timeouts?: GroupLicenseTimeouts;
}
export interface GroupLicenseTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#create GroupLicense#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#delete GroupLicense#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#read GroupLicense#read}
    */
    readonly read?: string;
}
export declare function groupLicenseTimeoutsToTerraform(struct?: GroupLicenseTimeouts | cdktn.IResolvable): any;
export declare function groupLicenseTimeoutsToHclTerraform(struct?: GroupLicenseTimeouts | cdktn.IResolvable): any;
export declare class GroupLicenseTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): GroupLicenseTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: GroupLicenseTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license azuread_group_license}
*/
export declare class GroupLicense extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_group_license";
    /**
    * Generates CDKTN code for importing a GroupLicense resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the GroupLicense to import
    * @param importFromId The id of the existing GroupLicense that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the GroupLicense to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/group_license azuread_group_license} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options GroupLicenseConfig
    */
    constructor(scope: Construct, id: string, config: GroupLicenseConfig);
    private _disabledPlans?;
    get disabledPlans(): string[];
    set disabledPlans(value: string[]);
    resetDisabledPlans(): void;
    get disabledPlansInput(): string[] | undefined;
    private _groupObjectId?;
    get groupObjectId(): string;
    set groupObjectId(value: string);
    get groupObjectIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _skuId?;
    get skuId(): string;
    set skuId(value: string);
    get skuIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): GroupLicenseTimeoutsOutputReference;
    putTimeouts(value: GroupLicenseTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | GroupLicenseTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
