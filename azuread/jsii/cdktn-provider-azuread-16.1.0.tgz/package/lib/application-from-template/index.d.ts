/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationFromTemplateConfig extends cdktn.TerraformMetaArguments {
    /**
    * The display name for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#display_name ApplicationFromTemplate#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#id ApplicationFromTemplate#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The UUID of the template to instantiate for this application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#template_id ApplicationFromTemplate#template_id}
    */
    readonly templateId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#timeouts ApplicationFromTemplate#timeouts}
    */
    readonly timeouts?: ApplicationFromTemplateTimeouts;
}
export interface ApplicationFromTemplateTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#create ApplicationFromTemplate#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#delete ApplicationFromTemplate#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#read ApplicationFromTemplate#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#update ApplicationFromTemplate#update}
    */
    readonly update?: string;
}
export declare function applicationFromTemplateTimeoutsToTerraform(struct?: ApplicationFromTemplateTimeouts | cdktn.IResolvable): any;
export declare function applicationFromTemplateTimeoutsToHclTerraform(struct?: ApplicationFromTemplateTimeouts | cdktn.IResolvable): any;
export declare class ApplicationFromTemplateTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationFromTemplateTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationFromTemplateTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template azuread_application_from_template}
*/
export declare class ApplicationFromTemplate extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_from_template";
    /**
    * Generates CDKTN code for importing a ApplicationFromTemplate resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationFromTemplate to import
    * @param importFromId The id of the existing ApplicationFromTemplate that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationFromTemplate to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/application_from_template azuread_application_from_template} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationFromTemplateConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationFromTemplateConfig);
    get applicationId(): string;
    get applicationObjectId(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get servicePrincipalId(): string;
    get servicePrincipalObjectId(): string;
    private _templateId?;
    get templateId(): string;
    set templateId(value: string);
    get templateIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationFromTemplateTimeoutsOutputReference;
    putTimeouts(value: ApplicationFromTemplateTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationFromTemplateTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
