/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadDomainsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Set to `true` to only return domains whose DNS is managed by Microsoft 365
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#admin_managed DataAzureadDomains#admin_managed}
    */
    readonly adminManaged?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#id DataAzureadDomains#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Set to `true` if unverified Azure AD domains should be included
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#include_unverified DataAzureadDomains#include_unverified}
    */
    readonly includeUnverified?: boolean | cdktn.IResolvable;
    /**
    * Set to `true` to only return the default domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#only_default DataAzureadDomains#only_default}
    */
    readonly onlyDefault?: boolean | cdktn.IResolvable;
    /**
    * Set to `true` to only return the initial domain, which is your primary Azure Active Directory tenant domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#only_initial DataAzureadDomains#only_initial}
    */
    readonly onlyInitial?: boolean | cdktn.IResolvable;
    /**
    * Set to `true` to only return verified root domains. Excludes subdomains and unverified domains
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#only_root DataAzureadDomains#only_root}
    */
    readonly onlyRoot?: boolean | cdktn.IResolvable;
    /**
    * A list of supported services that must be supported by a domain
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#supports_services DataAzureadDomains#supports_services}
    */
    readonly supportsServices?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#timeouts DataAzureadDomains#timeouts}
    */
    readonly timeouts?: DataAzureadDomainsTimeouts;
}
export interface DataAzureadDomainsDomains {
}
export declare function dataAzureadDomainsDomainsToTerraform(struct?: DataAzureadDomainsDomains): any;
export declare function dataAzureadDomainsDomainsToHclTerraform(struct?: DataAzureadDomainsDomains): any;
export declare class DataAzureadDomainsDomainsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadDomainsDomains | undefined;
    set internalValue(value: DataAzureadDomainsDomains | undefined);
    get adminManaged(): cdktn.IResolvable;
    get authenticationType(): string;
    get default(): cdktn.IResolvable;
    get domainName(): string;
    get initial(): cdktn.IResolvable;
    get root(): cdktn.IResolvable;
    get supportedServices(): string[];
    get verified(): cdktn.IResolvable;
}
export declare class DataAzureadDomainsDomainsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadDomainsDomainsOutputReference;
}
export interface DataAzureadDomainsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#read DataAzureadDomains#read}
    */
    readonly read?: string;
}
export declare function dataAzureadDomainsTimeoutsToTerraform(struct?: DataAzureadDomainsTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadDomainsTimeoutsToHclTerraform(struct?: DataAzureadDomainsTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadDomainsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadDomainsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadDomainsTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains azuread_domains}
*/
export declare class DataAzureadDomains extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_domains";
    /**
    * Generates CDKTN code for importing a DataAzureadDomains resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadDomains to import
    * @param importFromId The id of the existing DataAzureadDomains that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadDomains to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/domains azuread_domains} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadDomainsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadDomainsConfig);
    private _adminManaged?;
    get adminManaged(): boolean | cdktn.IResolvable;
    set adminManaged(value: boolean | cdktn.IResolvable);
    resetAdminManaged(): void;
    get adminManagedInput(): boolean | cdktn.IResolvable | undefined;
    private _domains;
    get domains(): DataAzureadDomainsDomainsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _includeUnverified?;
    get includeUnverified(): boolean | cdktn.IResolvable;
    set includeUnverified(value: boolean | cdktn.IResolvable);
    resetIncludeUnverified(): void;
    get includeUnverifiedInput(): boolean | cdktn.IResolvable | undefined;
    private _onlyDefault?;
    get onlyDefault(): boolean | cdktn.IResolvable;
    set onlyDefault(value: boolean | cdktn.IResolvable);
    resetOnlyDefault(): void;
    get onlyDefaultInput(): boolean | cdktn.IResolvable | undefined;
    private _onlyInitial?;
    get onlyInitial(): boolean | cdktn.IResolvable;
    set onlyInitial(value: boolean | cdktn.IResolvable);
    resetOnlyInitial(): void;
    get onlyInitialInput(): boolean | cdktn.IResolvable | undefined;
    private _onlyRoot?;
    get onlyRoot(): boolean | cdktn.IResolvable;
    set onlyRoot(value: boolean | cdktn.IResolvable);
    resetOnlyRoot(): void;
    get onlyRootInput(): boolean | cdktn.IResolvable | undefined;
    private _supportsServices?;
    get supportsServices(): string[];
    set supportsServices(value: string[]);
    resetSupportsServices(): void;
    get supportsServicesInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): DataAzureadDomainsTimeoutsOutputReference;
    putTimeouts(value: DataAzureadDomainsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadDomainsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
