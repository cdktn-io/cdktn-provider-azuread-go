/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessPackageAssignmentPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the access package that will contain the policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#access_package_id AccessPackageAssignmentPolicy#access_package_id}
    */
    readonly accessPackageId: string;
    /**
    * The description of the policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#description AccessPackageAssignmentPolicy#description}
    */
    readonly description: string;
    /**
    * The display name of the policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#display_name AccessPackageAssignmentPolicy#display_name}
    */
    readonly displayName: string;
    /**
    * How many days this assignment is valid for
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
    */
    readonly durationInDays?: number;
    /**
    * The date that this assignment expires, formatted as an RFC3339 date string in UTC (e.g. 2018-01-01T01:02:03Z)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#expiration_date AccessPackageAssignmentPolicy#expiration_date}
    */
    readonly expirationDate?: string;
    /**
    * When enabled, users will be able to request extension of their access to this package before their access expires
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#extension_enabled AccessPackageAssignmentPolicy#extension_enabled}
    */
    readonly extensionEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#id AccessPackageAssignmentPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * approval_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#approval_settings AccessPackageAssignmentPolicy#approval_settings}
    */
    readonly approvalSettings?: AccessPackageAssignmentPolicyApprovalSettings;
    /**
    * assignment_review_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#assignment_review_settings AccessPackageAssignmentPolicy#assignment_review_settings}
    */
    readonly assignmentReviewSettings?: AccessPackageAssignmentPolicyAssignmentReviewSettings;
    /**
    * question block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#question AccessPackageAssignmentPolicy#question}
    */
    readonly question?: AccessPackageAssignmentPolicyQuestion[] | cdktn.IResolvable;
    /**
    * requestor_settings block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#requestor_settings AccessPackageAssignmentPolicy#requestor_settings}
    */
    readonly requestorSettings?: AccessPackageAssignmentPolicyRequestorSettings;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#timeouts AccessPackageAssignmentPolicy#timeouts}
    */
    readonly timeouts?: AccessPackageAssignmentPolicyTimeouts;
}
export interface AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover {
    /**
    * For a user in an approval stage, this property indicates whether the user is a backup fallback approver
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
    */
    readonly backup?: boolean | cdktn.IResolvable;
    /**
    * The object ID of the subject
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
    */
    readonly objectId?: string;
    /**
    * Type of users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
    */
    readonly subjectType: string;
}
export declare function accessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverToTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverToHclTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover | cdktn.IResolvable | undefined);
    private _backup?;
    get backup(): boolean | cdktn.IResolvable;
    set backup(value: boolean | cdktn.IResolvable);
    resetBackup(): void;
    get backupInput(): boolean | cdktn.IResolvable | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    private _subjectType?;
    get subjectType(): string;
    set subjectType(value: string);
    get subjectTypeInput(): string | undefined;
}
export declare class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverOutputReference;
}
export interface AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover {
    /**
    * For a user in an approval stage, this property indicates whether the user is a backup fallback approver
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
    */
    readonly backup?: boolean | cdktn.IResolvable;
    /**
    * The object ID of the subject
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
    */
    readonly objectId?: string;
    /**
    * Type of users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
    */
    readonly subjectType: string;
}
export declare function accessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverToTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverToHclTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover | cdktn.IResolvable | undefined);
    private _backup?;
    get backup(): boolean | cdktn.IResolvable;
    set backup(value: boolean | cdktn.IResolvable);
    resetBackup(): void;
    get backupInput(): boolean | cdktn.IResolvable | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    private _subjectType?;
    get subjectType(): string;
    set subjectType(value: string);
    get subjectTypeInput(): string | undefined;
}
export declare class AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverOutputReference;
}
export interface AccessPackageAssignmentPolicyApprovalSettingsApprovalStage {
    /**
    * If no action taken, forward to alternate approvers?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#alternative_approval_enabled AccessPackageAssignmentPolicy#alternative_approval_enabled}
    */
    readonly alternativeApprovalEnabled?: boolean | cdktn.IResolvable;
    /**
    * Decision must be made in how many days? If a request is not approved within this time period after it is made, it will be automatically rejected
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#approval_timeout_in_days AccessPackageAssignmentPolicy#approval_timeout_in_days}
    */
    readonly approvalTimeoutInDays: number;
    /**
    * Whether an approver must provide a justification for their decision. Justification is visible to other approvers and the requestor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#approver_justification_required AccessPackageAssignmentPolicy#approver_justification_required}
    */
    readonly approverJustificationRequired?: boolean | cdktn.IResolvable;
    /**
    * Forward to alternate approver(s) after how many days?
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#enable_alternative_approval_in_days AccessPackageAssignmentPolicy#enable_alternative_approval_in_days}
    */
    readonly enableAlternativeApprovalInDays?: number;
    /**
    * alternative_approver block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#alternative_approver AccessPackageAssignmentPolicy#alternative_approver}
    */
    readonly alternativeApprover?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover[] | cdktn.IResolvable;
    /**
    * primary_approver block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#primary_approver AccessPackageAssignmentPolicy#primary_approver}
    */
    readonly primaryApprover?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover[] | cdktn.IResolvable;
}
export declare function accessPackageAssignmentPolicyApprovalSettingsApprovalStageToTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStage | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyApprovalSettingsApprovalStageToHclTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStage | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyApprovalSettingsApprovalStage | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyApprovalSettingsApprovalStage | cdktn.IResolvable | undefined);
    private _alternativeApprovalEnabled?;
    get alternativeApprovalEnabled(): boolean | cdktn.IResolvable;
    set alternativeApprovalEnabled(value: boolean | cdktn.IResolvable);
    resetAlternativeApprovalEnabled(): void;
    get alternativeApprovalEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _approvalTimeoutInDays?;
    get approvalTimeoutInDays(): number;
    set approvalTimeoutInDays(value: number);
    get approvalTimeoutInDaysInput(): number | undefined;
    private _approverJustificationRequired?;
    get approverJustificationRequired(): boolean | cdktn.IResolvable;
    set approverJustificationRequired(value: boolean | cdktn.IResolvable);
    resetApproverJustificationRequired(): void;
    get approverJustificationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _enableAlternativeApprovalInDays?;
    get enableAlternativeApprovalInDays(): number;
    set enableAlternativeApprovalInDays(value: number);
    resetEnableAlternativeApprovalInDays(): void;
    get enableAlternativeApprovalInDaysInput(): number | undefined;
    private _alternativeApprover;
    get alternativeApprover(): AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApproverList;
    putAlternativeApprover(value: AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover[] | cdktn.IResolvable): void;
    resetAlternativeApprover(): void;
    get alternativeApproverInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyApprovalSettingsApprovalStageAlternativeApprover[] | undefined;
    private _primaryApprover;
    get primaryApprover(): AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApproverList;
    putPrimaryApprover(value: AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover[] | cdktn.IResolvable): void;
    resetPrimaryApprover(): void;
    get primaryApproverInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyApprovalSettingsApprovalStagePrimaryApprover[] | undefined;
}
export declare class AccessPackageAssignmentPolicyApprovalSettingsApprovalStageList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStage[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyApprovalSettingsApprovalStageOutputReference;
}
export interface AccessPackageAssignmentPolicyApprovalSettings {
    /**
    * Whether an approval is required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#approval_required AccessPackageAssignmentPolicy#approval_required}
    */
    readonly approvalRequired?: boolean | cdktn.IResolvable;
    /**
    * Whether an approval is required to grant extension. Same approval settings used to approve initial access will apply
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#approval_required_for_extension AccessPackageAssignmentPolicy#approval_required_for_extension}
    */
    readonly approvalRequiredForExtension?: boolean | cdktn.IResolvable;
    /**
    * Whether requestor are required to provide a justification to request an access package. Justification is visible to other approvers and the requestor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#requestor_justification_required AccessPackageAssignmentPolicy#requestor_justification_required}
    */
    readonly requestorJustificationRequired?: boolean | cdktn.IResolvable;
    /**
    * approval_stage block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#approval_stage AccessPackageAssignmentPolicy#approval_stage}
    */
    readonly approvalStage?: AccessPackageAssignmentPolicyApprovalSettingsApprovalStage[] | cdktn.IResolvable;
}
export declare function accessPackageAssignmentPolicyApprovalSettingsToTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsOutputReference | AccessPackageAssignmentPolicyApprovalSettings): any;
export declare function accessPackageAssignmentPolicyApprovalSettingsToHclTerraform(struct?: AccessPackageAssignmentPolicyApprovalSettingsOutputReference | AccessPackageAssignmentPolicyApprovalSettings): any;
export declare class AccessPackageAssignmentPolicyApprovalSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageAssignmentPolicyApprovalSettings | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyApprovalSettings | undefined);
    private _approvalRequired?;
    get approvalRequired(): boolean | cdktn.IResolvable;
    set approvalRequired(value: boolean | cdktn.IResolvable);
    resetApprovalRequired(): void;
    get approvalRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _approvalRequiredForExtension?;
    get approvalRequiredForExtension(): boolean | cdktn.IResolvable;
    set approvalRequiredForExtension(value: boolean | cdktn.IResolvable);
    resetApprovalRequiredForExtension(): void;
    get approvalRequiredForExtensionInput(): boolean | cdktn.IResolvable | undefined;
    private _requestorJustificationRequired?;
    get requestorJustificationRequired(): boolean | cdktn.IResolvable;
    set requestorJustificationRequired(value: boolean | cdktn.IResolvable);
    resetRequestorJustificationRequired(): void;
    get requestorJustificationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _approvalStage;
    get approvalStage(): AccessPackageAssignmentPolicyApprovalSettingsApprovalStageList;
    putApprovalStage(value: AccessPackageAssignmentPolicyApprovalSettingsApprovalStage[] | cdktn.IResolvable): void;
    resetApprovalStage(): void;
    get approvalStageInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyApprovalSettingsApprovalStage[] | undefined;
}
export interface AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer {
    /**
    * For a user in an approval stage, this property indicates whether the user is a backup fallback approver
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
    */
    readonly backup?: boolean | cdktn.IResolvable;
    /**
    * The object ID of the subject
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
    */
    readonly objectId?: string;
    /**
    * Type of users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
    */
    readonly subjectType: string;
}
export declare function accessPackageAssignmentPolicyAssignmentReviewSettingsReviewerToTerraform(struct?: AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyAssignmentReviewSettingsReviewerToHclTerraform(struct?: AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer | cdktn.IResolvable | undefined);
    private _backup?;
    get backup(): boolean | cdktn.IResolvable;
    set backup(value: boolean | cdktn.IResolvable);
    resetBackup(): void;
    get backupInput(): boolean | cdktn.IResolvable | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    private _subjectType?;
    get subjectType(): string;
    set subjectType(value: string);
    get subjectTypeInput(): string | undefined;
}
export declare class AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerOutputReference;
}
export interface AccessPackageAssignmentPolicyAssignmentReviewSettings {
    /**
    * Whether to show Show reviewer decision helpers. If enabled, system recommendations based on users' access information will be shown to the reviewers. The reviewer will be recommended to approve the review if the user has signed-in at least once during the last 30 days. The reviewer will be recommended to deny the review if the user has not signed-in during the last 30 days
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#access_recommendation_enabled AccessPackageAssignmentPolicy#access_recommendation_enabled}
    */
    readonly accessRecommendationEnabled?: boolean | cdktn.IResolvable;
    /**
    * What actions the system takes if reviewers don't respond in time
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#access_review_timeout_behavior AccessPackageAssignmentPolicy#access_review_timeout_behavior}
    */
    readonly accessReviewTimeoutBehavior?: string;
    /**
    * Whether a reviewer need provide a justification for their decision. Justification is visible to other reviewers and the requestor
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#approver_justification_required AccessPackageAssignmentPolicy#approver_justification_required}
    */
    readonly approverJustificationRequired?: boolean | cdktn.IResolvable;
    /**
    * How many days each occurrence of the access review series will run
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#duration_in_days AccessPackageAssignmentPolicy#duration_in_days}
    */
    readonly durationInDays?: number;
    /**
    * Whether to enable assignment review
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#enabled AccessPackageAssignmentPolicy#enabled}
    */
    readonly enabled?: boolean | cdktn.IResolvable;
    /**
    * This will determine how often the access review campaign runs
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#review_frequency AccessPackageAssignmentPolicy#review_frequency}
    */
    readonly reviewFrequency?: string;
    /**
    * Self review or specific reviewers
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#review_type AccessPackageAssignmentPolicy#review_type}
    */
    readonly reviewType?: string;
    /**
    * This is the date the access review campaign will start on, formatted as an RFC3339 date string in UTC(e.g. 2018-01-01T01:02:03Z), default is now. Once an access review has been created, you cannot update its start date
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#starting_on AccessPackageAssignmentPolicy#starting_on}
    */
    readonly startingOn?: string;
    /**
    * reviewer block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#reviewer AccessPackageAssignmentPolicy#reviewer}
    */
    readonly reviewer?: AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer[] | cdktn.IResolvable;
}
export declare function accessPackageAssignmentPolicyAssignmentReviewSettingsToTerraform(struct?: AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference | AccessPackageAssignmentPolicyAssignmentReviewSettings): any;
export declare function accessPackageAssignmentPolicyAssignmentReviewSettingsToHclTerraform(struct?: AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference | AccessPackageAssignmentPolicyAssignmentReviewSettings): any;
export declare class AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageAssignmentPolicyAssignmentReviewSettings | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyAssignmentReviewSettings | undefined);
    private _accessRecommendationEnabled?;
    get accessRecommendationEnabled(): boolean | cdktn.IResolvable;
    set accessRecommendationEnabled(value: boolean | cdktn.IResolvable);
    resetAccessRecommendationEnabled(): void;
    get accessRecommendationEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _accessReviewTimeoutBehavior?;
    get accessReviewTimeoutBehavior(): string;
    set accessReviewTimeoutBehavior(value: string);
    resetAccessReviewTimeoutBehavior(): void;
    get accessReviewTimeoutBehaviorInput(): string | undefined;
    private _approverJustificationRequired?;
    get approverJustificationRequired(): boolean | cdktn.IResolvable;
    set approverJustificationRequired(value: boolean | cdktn.IResolvable);
    resetApproverJustificationRequired(): void;
    get approverJustificationRequiredInput(): boolean | cdktn.IResolvable | undefined;
    private _durationInDays?;
    get durationInDays(): number;
    set durationInDays(value: number);
    resetDurationInDays(): void;
    get durationInDaysInput(): number | undefined;
    private _enabled?;
    get enabled(): boolean | cdktn.IResolvable;
    set enabled(value: boolean | cdktn.IResolvable);
    resetEnabled(): void;
    get enabledInput(): boolean | cdktn.IResolvable | undefined;
    private _reviewFrequency?;
    get reviewFrequency(): string;
    set reviewFrequency(value: string);
    resetReviewFrequency(): void;
    get reviewFrequencyInput(): string | undefined;
    private _reviewType?;
    get reviewType(): string;
    set reviewType(value: string);
    resetReviewType(): void;
    get reviewTypeInput(): string | undefined;
    private _startingOn?;
    get startingOn(): string;
    set startingOn(value: string);
    resetStartingOn(): void;
    get startingOnInput(): string | undefined;
    private _reviewer;
    get reviewer(): AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewerList;
    putReviewer(value: AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer[] | cdktn.IResolvable): void;
    resetReviewer(): void;
    get reviewerInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyAssignmentReviewSettingsReviewer[] | undefined;
}
export interface AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText {
    /**
    * The localized content of this question
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#content AccessPackageAssignmentPolicy#content}
    */
    readonly content: string;
    /**
    * The language code of this question content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#language_code AccessPackageAssignmentPolicy#language_code}
    */
    readonly languageCode: string;
}
export declare function accessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextToTerraform(struct?: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextToHclTerraform(struct?: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
}
export declare class AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextOutputReference;
}
export interface AccessPackageAssignmentPolicyQuestionChoiceDisplayValue {
    /**
    * The default text of this question
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
    */
    readonly defaultText: string;
    /**
    * localized_text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
    */
    readonly localizedText?: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText[] | cdktn.IResolvable;
}
export declare function accessPackageAssignmentPolicyQuestionChoiceDisplayValueToTerraform(struct?: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference | AccessPackageAssignmentPolicyQuestionChoiceDisplayValue): any;
export declare function accessPackageAssignmentPolicyQuestionChoiceDisplayValueToHclTerraform(struct?: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference | AccessPackageAssignmentPolicyQuestionChoiceDisplayValue): any;
export declare class AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageAssignmentPolicyQuestionChoiceDisplayValue | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyQuestionChoiceDisplayValue | undefined);
    private _defaultText?;
    get defaultText(): string;
    set defaultText(value: string);
    get defaultTextInput(): string | undefined;
    private _localizedText;
    get localizedText(): AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedTextList;
    putLocalizedText(value: AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText[] | cdktn.IResolvable): void;
    resetLocalizedText(): void;
    get localizedTextInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyQuestionChoiceDisplayValueLocalizedText[] | undefined;
}
export interface AccessPackageAssignmentPolicyQuestionChoice {
    /**
    * The actual value of this choice
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#actual_value AccessPackageAssignmentPolicy#actual_value}
    */
    readonly actualValue: string;
    /**
    * display_value block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#display_value AccessPackageAssignmentPolicy#display_value}
    */
    readonly displayValue: AccessPackageAssignmentPolicyQuestionChoiceDisplayValue;
}
export declare function accessPackageAssignmentPolicyQuestionChoiceToTerraform(struct?: AccessPackageAssignmentPolicyQuestionChoice | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyQuestionChoiceToHclTerraform(struct?: AccessPackageAssignmentPolicyQuestionChoice | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyQuestionChoiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyQuestionChoice | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyQuestionChoice | cdktn.IResolvable | undefined);
    private _actualValue?;
    get actualValue(): string;
    set actualValue(value: string);
    get actualValueInput(): string | undefined;
    private _displayValue;
    get displayValue(): AccessPackageAssignmentPolicyQuestionChoiceDisplayValueOutputReference;
    putDisplayValue(value: AccessPackageAssignmentPolicyQuestionChoiceDisplayValue): void;
    get displayValueInput(): AccessPackageAssignmentPolicyQuestionChoiceDisplayValue | undefined;
}
export declare class AccessPackageAssignmentPolicyQuestionChoiceList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyQuestionChoice[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyQuestionChoiceOutputReference;
}
export interface AccessPackageAssignmentPolicyQuestionTextLocalizedText {
    /**
    * The localized content of this question
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#content AccessPackageAssignmentPolicy#content}
    */
    readonly content: string;
    /**
    * The language code of this question content
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#language_code AccessPackageAssignmentPolicy#language_code}
    */
    readonly languageCode: string;
}
export declare function accessPackageAssignmentPolicyQuestionTextLocalizedTextToTerraform(struct?: AccessPackageAssignmentPolicyQuestionTextLocalizedText | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyQuestionTextLocalizedTextToHclTerraform(struct?: AccessPackageAssignmentPolicyQuestionTextLocalizedText | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyQuestionTextLocalizedTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyQuestionTextLocalizedText | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyQuestionTextLocalizedText | cdktn.IResolvable | undefined);
    private _content?;
    get content(): string;
    set content(value: string);
    get contentInput(): string | undefined;
    private _languageCode?;
    get languageCode(): string;
    set languageCode(value: string);
    get languageCodeInput(): string | undefined;
}
export declare class AccessPackageAssignmentPolicyQuestionTextLocalizedTextList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyQuestionTextLocalizedText[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyQuestionTextLocalizedTextOutputReference;
}
export interface AccessPackageAssignmentPolicyQuestionText {
    /**
    * The default text of this question
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#default_text AccessPackageAssignmentPolicy#default_text}
    */
    readonly defaultText: string;
    /**
    * localized_text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#localized_text AccessPackageAssignmentPolicy#localized_text}
    */
    readonly localizedText?: AccessPackageAssignmentPolicyQuestionTextLocalizedText[] | cdktn.IResolvable;
}
export declare function accessPackageAssignmentPolicyQuestionTextToTerraform(struct?: AccessPackageAssignmentPolicyQuestionTextOutputReference | AccessPackageAssignmentPolicyQuestionText): any;
export declare function accessPackageAssignmentPolicyQuestionTextToHclTerraform(struct?: AccessPackageAssignmentPolicyQuestionTextOutputReference | AccessPackageAssignmentPolicyQuestionText): any;
export declare class AccessPackageAssignmentPolicyQuestionTextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageAssignmentPolicyQuestionText | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyQuestionText | undefined);
    private _defaultText?;
    get defaultText(): string;
    set defaultText(value: string);
    get defaultTextInput(): string | undefined;
    private _localizedText;
    get localizedText(): AccessPackageAssignmentPolicyQuestionTextLocalizedTextList;
    putLocalizedText(value: AccessPackageAssignmentPolicyQuestionTextLocalizedText[] | cdktn.IResolvable): void;
    resetLocalizedText(): void;
    get localizedTextInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyQuestionTextLocalizedText[] | undefined;
}
export interface AccessPackageAssignmentPolicyQuestion {
    /**
    * Whether this question is required
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#required AccessPackageAssignmentPolicy#required}
    */
    readonly required?: boolean | cdktn.IResolvable;
    /**
    * The sequence number of this question
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#sequence AccessPackageAssignmentPolicy#sequence}
    */
    readonly sequence?: number;
    /**
    * choice block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#choice AccessPackageAssignmentPolicy#choice}
    */
    readonly choice?: AccessPackageAssignmentPolicyQuestionChoice[] | cdktn.IResolvable;
    /**
    * text block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#text AccessPackageAssignmentPolicy#text}
    */
    readonly text: AccessPackageAssignmentPolicyQuestionText;
}
export declare function accessPackageAssignmentPolicyQuestionToTerraform(struct?: AccessPackageAssignmentPolicyQuestion | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyQuestionToHclTerraform(struct?: AccessPackageAssignmentPolicyQuestion | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyQuestionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyQuestion | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyQuestion | cdktn.IResolvable | undefined);
    private _required?;
    get required(): boolean | cdktn.IResolvable;
    set required(value: boolean | cdktn.IResolvable);
    resetRequired(): void;
    get requiredInput(): boolean | cdktn.IResolvable | undefined;
    private _sequence?;
    get sequence(): number;
    set sequence(value: number);
    resetSequence(): void;
    get sequenceInput(): number | undefined;
    private _choice;
    get choice(): AccessPackageAssignmentPolicyQuestionChoiceList;
    putChoice(value: AccessPackageAssignmentPolicyQuestionChoice[] | cdktn.IResolvable): void;
    resetChoice(): void;
    get choiceInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyQuestionChoice[] | undefined;
    private _text;
    get text(): AccessPackageAssignmentPolicyQuestionTextOutputReference;
    putText(value: AccessPackageAssignmentPolicyQuestionText): void;
    get textInput(): AccessPackageAssignmentPolicyQuestionText | undefined;
}
export declare class AccessPackageAssignmentPolicyQuestionList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyQuestion[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyQuestionOutputReference;
}
export interface AccessPackageAssignmentPolicyRequestorSettingsRequestor {
    /**
    * For a user in an approval stage, this property indicates whether the user is a backup fallback approver
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#backup AccessPackageAssignmentPolicy#backup}
    */
    readonly backup?: boolean | cdktn.IResolvable;
    /**
    * The object ID of the subject
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#object_id AccessPackageAssignmentPolicy#object_id}
    */
    readonly objectId?: string;
    /**
    * Type of users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#subject_type AccessPackageAssignmentPolicy#subject_type}
    */
    readonly subjectType: string;
}
export declare function accessPackageAssignmentPolicyRequestorSettingsRequestorToTerraform(struct?: AccessPackageAssignmentPolicyRequestorSettingsRequestor | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyRequestorSettingsRequestorToHclTerraform(struct?: AccessPackageAssignmentPolicyRequestorSettingsRequestor | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyRequestorSettingsRequestorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): AccessPackageAssignmentPolicyRequestorSettingsRequestor | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyRequestorSettingsRequestor | cdktn.IResolvable | undefined);
    private _backup?;
    get backup(): boolean | cdktn.IResolvable;
    set backup(value: boolean | cdktn.IResolvable);
    resetBackup(): void;
    get backupInput(): boolean | cdktn.IResolvable | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    private _subjectType?;
    get subjectType(): string;
    set subjectType(value: string);
    get subjectTypeInput(): string | undefined;
}
export declare class AccessPackageAssignmentPolicyRequestorSettingsRequestorList extends cdktn.ComplexList {
    internalValue?: AccessPackageAssignmentPolicyRequestorSettingsRequestor[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): AccessPackageAssignmentPolicyRequestorSettingsRequestorOutputReference;
}
export interface AccessPackageAssignmentPolicyRequestorSettings {
    /**
    * Whether to accept requests now, when disabled, no new requests can be made using this policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#requests_accepted AccessPackageAssignmentPolicy#requests_accepted}
    */
    readonly requestsAccepted?: boolean | cdktn.IResolvable;
    /**
    * Specify the scopes of the requestors
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#scope_type AccessPackageAssignmentPolicy#scope_type}
    */
    readonly scopeType?: string;
    /**
    * requestor block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#requestor AccessPackageAssignmentPolicy#requestor}
    */
    readonly requestor?: AccessPackageAssignmentPolicyRequestorSettingsRequestor[] | cdktn.IResolvable;
}
export declare function accessPackageAssignmentPolicyRequestorSettingsToTerraform(struct?: AccessPackageAssignmentPolicyRequestorSettingsOutputReference | AccessPackageAssignmentPolicyRequestorSettings): any;
export declare function accessPackageAssignmentPolicyRequestorSettingsToHclTerraform(struct?: AccessPackageAssignmentPolicyRequestorSettingsOutputReference | AccessPackageAssignmentPolicyRequestorSettings): any;
export declare class AccessPackageAssignmentPolicyRequestorSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageAssignmentPolicyRequestorSettings | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyRequestorSettings | undefined);
    private _requestsAccepted?;
    get requestsAccepted(): boolean | cdktn.IResolvable;
    set requestsAccepted(value: boolean | cdktn.IResolvable);
    resetRequestsAccepted(): void;
    get requestsAcceptedInput(): boolean | cdktn.IResolvable | undefined;
    private _scopeType?;
    get scopeType(): string;
    set scopeType(value: string);
    resetScopeType(): void;
    get scopeTypeInput(): string | undefined;
    private _requestor;
    get requestor(): AccessPackageAssignmentPolicyRequestorSettingsRequestorList;
    putRequestor(value: AccessPackageAssignmentPolicyRequestorSettingsRequestor[] | cdktn.IResolvable): void;
    resetRequestor(): void;
    get requestorInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyRequestorSettingsRequestor[] | undefined;
}
export interface AccessPackageAssignmentPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#create AccessPackageAssignmentPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#delete AccessPackageAssignmentPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#read AccessPackageAssignmentPolicy#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#update AccessPackageAssignmentPolicy#update}
    */
    readonly update?: string;
}
export declare function accessPackageAssignmentPolicyTimeoutsToTerraform(struct?: AccessPackageAssignmentPolicyTimeouts | cdktn.IResolvable): any;
export declare function accessPackageAssignmentPolicyTimeoutsToHclTerraform(struct?: AccessPackageAssignmentPolicyTimeouts | cdktn.IResolvable): any;
export declare class AccessPackageAssignmentPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageAssignmentPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageAssignmentPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy azuread_access_package_assignment_policy}
*/
export declare class AccessPackageAssignmentPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_access_package_assignment_policy";
    /**
    * Generates CDKTN code for importing a AccessPackageAssignmentPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPackageAssignmentPolicy to import
    * @param importFromId The id of the existing AccessPackageAssignmentPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPackageAssignmentPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_assignment_policy azuread_access_package_assignment_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPackageAssignmentPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AccessPackageAssignmentPolicyConfig);
    private _accessPackageId?;
    get accessPackageId(): string;
    set accessPackageId(value: string);
    get accessPackageIdInput(): string | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _durationInDays?;
    get durationInDays(): number;
    set durationInDays(value: number);
    resetDurationInDays(): void;
    get durationInDaysInput(): number | undefined;
    private _expirationDate?;
    get expirationDate(): string;
    set expirationDate(value: string);
    resetExpirationDate(): void;
    get expirationDateInput(): string | undefined;
    private _extensionEnabled?;
    get extensionEnabled(): boolean | cdktn.IResolvable;
    set extensionEnabled(value: boolean | cdktn.IResolvable);
    resetExtensionEnabled(): void;
    get extensionEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _approvalSettings;
    get approvalSettings(): AccessPackageAssignmentPolicyApprovalSettingsOutputReference;
    putApprovalSettings(value: AccessPackageAssignmentPolicyApprovalSettings): void;
    resetApprovalSettings(): void;
    get approvalSettingsInput(): AccessPackageAssignmentPolicyApprovalSettings | undefined;
    private _assignmentReviewSettings;
    get assignmentReviewSettings(): AccessPackageAssignmentPolicyAssignmentReviewSettingsOutputReference;
    putAssignmentReviewSettings(value: AccessPackageAssignmentPolicyAssignmentReviewSettings): void;
    resetAssignmentReviewSettings(): void;
    get assignmentReviewSettingsInput(): AccessPackageAssignmentPolicyAssignmentReviewSettings | undefined;
    private _question;
    get question(): AccessPackageAssignmentPolicyQuestionList;
    putQuestion(value: AccessPackageAssignmentPolicyQuestion[] | cdktn.IResolvable): void;
    resetQuestion(): void;
    get questionInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyQuestion[] | undefined;
    private _requestorSettings;
    get requestorSettings(): AccessPackageAssignmentPolicyRequestorSettingsOutputReference;
    putRequestorSettings(value: AccessPackageAssignmentPolicyRequestorSettings): void;
    resetRequestorSettings(): void;
    get requestorSettingsInput(): AccessPackageAssignmentPolicyRequestorSettings | undefined;
    private _timeouts;
    get timeouts(): AccessPackageAssignmentPolicyTimeoutsOutputReference;
    putTimeouts(value: AccessPackageAssignmentPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessPackageAssignmentPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
