/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuthenticationStrengthPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The allowed MFA methods for this policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#allowed_combinations AuthenticationStrengthPolicy#allowed_combinations}
    */
    readonly allowedCombinations: string[];
    /**
    * The description for the authentication strength policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#description AuthenticationStrengthPolicy#description}
    */
    readonly description?: string;
    /**
    * The display name for the authentication strength policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#display_name AuthenticationStrengthPolicy#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#id AuthenticationStrengthPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#timeouts AuthenticationStrengthPolicy#timeouts}
    */
    readonly timeouts?: AuthenticationStrengthPolicyTimeouts;
}
export interface AuthenticationStrengthPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#create AuthenticationStrengthPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#delete AuthenticationStrengthPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#read AuthenticationStrengthPolicy#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#update AuthenticationStrengthPolicy#update}
    */
    readonly update?: string;
}
export declare function authenticationStrengthPolicyTimeoutsToTerraform(struct?: AuthenticationStrengthPolicyTimeouts | cdktn.IResolvable): any;
export declare function authenticationStrengthPolicyTimeoutsToHclTerraform(struct?: AuthenticationStrengthPolicyTimeouts | cdktn.IResolvable): any;
export declare class AuthenticationStrengthPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuthenticationStrengthPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AuthenticationStrengthPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy azuread_authentication_strength_policy}
*/
export declare class AuthenticationStrengthPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_authentication_strength_policy";
    /**
    * Generates CDKTN code for importing a AuthenticationStrengthPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthenticationStrengthPolicy to import
    * @param importFromId The id of the existing AuthenticationStrengthPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthenticationStrengthPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/authentication_strength_policy azuread_authentication_strength_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthenticationStrengthPolicyConfig
    */
    constructor(scope: Construct, id: string, config: AuthenticationStrengthPolicyConfig);
    private _allowedCombinations?;
    get allowedCombinations(): string[];
    set allowedCombinations(value: string[]);
    get allowedCombinationsInput(): string[] | undefined;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AuthenticationStrengthPolicyTimeoutsOutputReference;
    putTimeouts(value: AuthenticationStrengthPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AuthenticationStrengthPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
