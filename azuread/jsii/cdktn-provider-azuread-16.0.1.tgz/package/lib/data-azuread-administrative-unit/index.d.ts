/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadAdministrativeUnitConfig extends cdktn.TerraformMetaArguments {
    /**
    * The display name for the administrative unit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#display_name DataAzureadAdministrativeUnit#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#id DataAzureadAdministrativeUnit#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the administrative unit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#object_id DataAzureadAdministrativeUnit#object_id}
    */
    readonly objectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#timeouts DataAzureadAdministrativeUnit#timeouts}
    */
    readonly timeouts?: DataAzureadAdministrativeUnitTimeouts;
}
export interface DataAzureadAdministrativeUnitTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#create DataAzureadAdministrativeUnit#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#delete DataAzureadAdministrativeUnit#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#read DataAzureadAdministrativeUnit#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#update DataAzureadAdministrativeUnit#update}
    */
    readonly update?: string;
}
export declare function dataAzureadAdministrativeUnitTimeoutsToTerraform(struct?: DataAzureadAdministrativeUnitTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadAdministrativeUnitTimeoutsToHclTerraform(struct?: DataAzureadAdministrativeUnitTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadAdministrativeUnitTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadAdministrativeUnitTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadAdministrativeUnitTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit azuread_administrative_unit}
*/
export declare class DataAzureadAdministrativeUnit extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_administrative_unit";
    /**
    * Generates CDKTN code for importing a DataAzureadAdministrativeUnit resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadAdministrativeUnit to import
    * @param importFromId The id of the existing DataAzureadAdministrativeUnit that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadAdministrativeUnit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/administrative_unit azuread_administrative_unit} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadAdministrativeUnitConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadAdministrativeUnitConfig);
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get members(): string[];
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    get visibility(): string;
    private _timeouts;
    get timeouts(): DataAzureadAdministrativeUnitTimeoutsOutputReference;
    putTimeouts(value: DataAzureadAdministrativeUnitTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadAdministrativeUnitTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
