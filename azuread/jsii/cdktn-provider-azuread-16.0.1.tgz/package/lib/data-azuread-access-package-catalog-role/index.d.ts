/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadAccessPackageCatalogRoleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The display name of the catalog role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role#display_name DataAzureadAccessPackageCatalogRole#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role#id DataAzureadAccessPackageCatalogRole#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the catalog role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role#object_id DataAzureadAccessPackageCatalogRole#object_id}
    */
    readonly objectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role#timeouts DataAzureadAccessPackageCatalogRole#timeouts}
    */
    readonly timeouts?: DataAzureadAccessPackageCatalogRoleTimeouts;
}
export interface DataAzureadAccessPackageCatalogRoleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role#read DataAzureadAccessPackageCatalogRole#read}
    */
    readonly read?: string;
}
export declare function dataAzureadAccessPackageCatalogRoleTimeoutsToTerraform(struct?: DataAzureadAccessPackageCatalogRoleTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadAccessPackageCatalogRoleTimeoutsToHclTerraform(struct?: DataAzureadAccessPackageCatalogRoleTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadAccessPackageCatalogRoleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadAccessPackageCatalogRoleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadAccessPackageCatalogRoleTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role azuread_access_package_catalog_role}
*/
export declare class DataAzureadAccessPackageCatalogRole extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_access_package_catalog_role";
    /**
    * Generates CDKTN code for importing a DataAzureadAccessPackageCatalogRole resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadAccessPackageCatalogRole to import
    * @param importFromId The id of the existing DataAzureadAccessPackageCatalogRole that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadAccessPackageCatalogRole to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/access_package_catalog_role azuread_access_package_catalog_role} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadAccessPackageCatalogRoleConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadAccessPackageCatalogRoleConfig);
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    get templateId(): string;
    private _timeouts;
    get timeouts(): DataAzureadAccessPackageCatalogRoleTimeoutsOutputReference;
    putTimeouts(value: DataAzureadAccessPackageCatalogRoleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadAccessPackageCatalogRoleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
