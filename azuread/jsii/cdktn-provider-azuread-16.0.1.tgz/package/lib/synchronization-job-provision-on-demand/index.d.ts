/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SynchronizationJobProvisionOnDemandConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#id SynchronizationJobProvisionOnDemand#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the service principal for which this synchronization job should be provisioned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#service_principal_id SynchronizationJobProvisionOnDemand#service_principal_id}
    */
    readonly servicePrincipalId: string;
    /**
    * The identifier for the synchronization jop.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#synchronization_job_id SynchronizationJobProvisionOnDemand#synchronization_job_id}
    */
    readonly synchronizationJobId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#triggers SynchronizationJobProvisionOnDemand#triggers}
    */
    readonly triggers?: {
        [key: string]: string;
    };
    /**
    * parameter block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#parameter SynchronizationJobProvisionOnDemand#parameter}
    */
    readonly parameter: SynchronizationJobProvisionOnDemandParameter[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#timeouts SynchronizationJobProvisionOnDemand#timeouts}
    */
    readonly timeouts?: SynchronizationJobProvisionOnDemandTimeouts;
}
export interface SynchronizationJobProvisionOnDemandParameterSubject {
    /**
    * The identifier of an object to which a synchronization job is to be applied. Can be one of the following: (1) An onPremisesDistinguishedName for synchronization from Active Directory to Azure AD. (2) The user ID for synchronization from Azure AD to a third-party. (3) The Worker ID of the Workday worker for synchronization from Workday to either Active Directory or Azure AD.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#object_id SynchronizationJobProvisionOnDemand#object_id}
    */
    readonly objectId: string;
    /**
    * The type of the object to which a synchronization job is to be applied. Can be one of the following: `user` for synchronizing between Active Directory and Azure AD, `User` for synchronizing a user between Azure AD and a third-party application, `Worker` for synchronization a user between Workday and either Active Directory or Azure AD, `Group` for synchronizing a group between Azure AD and a third-party application.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#object_type_name SynchronizationJobProvisionOnDemand#object_type_name}
    */
    readonly objectTypeName: string;
}
export declare function synchronizationJobProvisionOnDemandParameterSubjectToTerraform(struct?: SynchronizationJobProvisionOnDemandParameterSubject | cdktn.IResolvable): any;
export declare function synchronizationJobProvisionOnDemandParameterSubjectToHclTerraform(struct?: SynchronizationJobProvisionOnDemandParameterSubject | cdktn.IResolvable): any;
export declare class SynchronizationJobProvisionOnDemandParameterSubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SynchronizationJobProvisionOnDemandParameterSubject | cdktn.IResolvable | undefined;
    set internalValue(value: SynchronizationJobProvisionOnDemandParameterSubject | cdktn.IResolvable | undefined);
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    private _objectTypeName?;
    get objectTypeName(): string;
    set objectTypeName(value: string);
    get objectTypeNameInput(): string | undefined;
}
export declare class SynchronizationJobProvisionOnDemandParameterSubjectList extends cdktn.ComplexList {
    internalValue?: SynchronizationJobProvisionOnDemandParameterSubject[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SynchronizationJobProvisionOnDemandParameterSubjectOutputReference;
}
export interface SynchronizationJobProvisionOnDemandParameter {
    /**
    * The identifier of the synchronization rule to be applied. This rule ID is defined in the schema for a given synchronization job or template.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#rule_id SynchronizationJobProvisionOnDemand#rule_id}
    */
    readonly ruleId: string;
    /**
    * subject block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#subject SynchronizationJobProvisionOnDemand#subject}
    */
    readonly subject: SynchronizationJobProvisionOnDemandParameterSubject[] | cdktn.IResolvable;
}
export declare function synchronizationJobProvisionOnDemandParameterToTerraform(struct?: SynchronizationJobProvisionOnDemandParameter | cdktn.IResolvable): any;
export declare function synchronizationJobProvisionOnDemandParameterToHclTerraform(struct?: SynchronizationJobProvisionOnDemandParameter | cdktn.IResolvable): any;
export declare class SynchronizationJobProvisionOnDemandParameterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SynchronizationJobProvisionOnDemandParameter | cdktn.IResolvable | undefined;
    set internalValue(value: SynchronizationJobProvisionOnDemandParameter | cdktn.IResolvable | undefined);
    private _ruleId?;
    get ruleId(): string;
    set ruleId(value: string);
    get ruleIdInput(): string | undefined;
    private _subject;
    get subject(): SynchronizationJobProvisionOnDemandParameterSubjectList;
    putSubject(value: SynchronizationJobProvisionOnDemandParameterSubject[] | cdktn.IResolvable): void;
    get subjectInput(): cdktn.IResolvable | SynchronizationJobProvisionOnDemandParameterSubject[] | undefined;
}
export declare class SynchronizationJobProvisionOnDemandParameterList extends cdktn.ComplexList {
    internalValue?: SynchronizationJobProvisionOnDemandParameter[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SynchronizationJobProvisionOnDemandParameterOutputReference;
}
export interface SynchronizationJobProvisionOnDemandTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#create SynchronizationJobProvisionOnDemand#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#delete SynchronizationJobProvisionOnDemand#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#read SynchronizationJobProvisionOnDemand#read}
    */
    readonly read?: string;
}
export declare function synchronizationJobProvisionOnDemandTimeoutsToTerraform(struct?: SynchronizationJobProvisionOnDemandTimeouts | cdktn.IResolvable): any;
export declare function synchronizationJobProvisionOnDemandTimeoutsToHclTerraform(struct?: SynchronizationJobProvisionOnDemandTimeouts | cdktn.IResolvable): any;
export declare class SynchronizationJobProvisionOnDemandTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SynchronizationJobProvisionOnDemandTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: SynchronizationJobProvisionOnDemandTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand azuread_synchronization_job_provision_on_demand}
*/
export declare class SynchronizationJobProvisionOnDemand extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_synchronization_job_provision_on_demand";
    /**
    * Generates CDKTN code for importing a SynchronizationJobProvisionOnDemand resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SynchronizationJobProvisionOnDemand to import
    * @param importFromId The id of the existing SynchronizationJobProvisionOnDemand that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SynchronizationJobProvisionOnDemand to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_job_provision_on_demand azuread_synchronization_job_provision_on_demand} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SynchronizationJobProvisionOnDemandConfig
    */
    constructor(scope: Construct, id: string, config: SynchronizationJobProvisionOnDemandConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
    private _synchronizationJobId?;
    get synchronizationJobId(): string;
    set synchronizationJobId(value: string);
    get synchronizationJobIdInput(): string | undefined;
    private _triggers?;
    get triggers(): {
        [key: string]: string;
    };
    set triggers(value: {
        [key: string]: string;
    });
    resetTriggers(): void;
    get triggersInput(): {
        [key: string]: string;
    } | undefined;
    private _parameter;
    get parameter(): SynchronizationJobProvisionOnDemandParameterList;
    putParameter(value: SynchronizationJobProvisionOnDemandParameter[] | cdktn.IResolvable): void;
    get parameterInput(): cdktn.IResolvable | SynchronizationJobProvisionOnDemandParameter[] | undefined;
    private _timeouts;
    get timeouts(): SynchronizationJobProvisionOnDemandTimeoutsOutputReference;
    putTimeouts(value: SynchronizationJobProvisionOnDemandTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | SynchronizationJobProvisionOnDemandTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
