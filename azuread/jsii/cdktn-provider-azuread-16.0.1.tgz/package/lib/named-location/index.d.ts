/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface NamedLocationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#display_name NamedLocation#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#id NamedLocation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * country block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#country NamedLocation#country}
    */
    readonly country?: NamedLocationCountry;
    /**
    * ip block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#ip NamedLocation#ip}
    */
    readonly ip?: NamedLocationIp;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#timeouts NamedLocation#timeouts}
    */
    readonly timeouts?: NamedLocationTimeouts;
}
export interface NamedLocationCountry {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#countries_and_regions NamedLocation#countries_and_regions}
    */
    readonly countriesAndRegions: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#country_lookup_method NamedLocation#country_lookup_method}
    */
    readonly countryLookupMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#include_unknown_countries_and_regions NamedLocation#include_unknown_countries_and_regions}
    */
    readonly includeUnknownCountriesAndRegions?: boolean | cdktn.IResolvable;
}
export declare function namedLocationCountryToTerraform(struct?: NamedLocationCountryOutputReference | NamedLocationCountry): any;
export declare function namedLocationCountryToHclTerraform(struct?: NamedLocationCountryOutputReference | NamedLocationCountry): any;
export declare class NamedLocationCountryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NamedLocationCountry | undefined;
    set internalValue(value: NamedLocationCountry | undefined);
    private _countriesAndRegions?;
    get countriesAndRegions(): string[];
    set countriesAndRegions(value: string[]);
    get countriesAndRegionsInput(): string[] | undefined;
    private _countryLookupMethod?;
    get countryLookupMethod(): string;
    set countryLookupMethod(value: string);
    resetCountryLookupMethod(): void;
    get countryLookupMethodInput(): string | undefined;
    private _includeUnknownCountriesAndRegions?;
    get includeUnknownCountriesAndRegions(): boolean | cdktn.IResolvable;
    set includeUnknownCountriesAndRegions(value: boolean | cdktn.IResolvable);
    resetIncludeUnknownCountriesAndRegions(): void;
    get includeUnknownCountriesAndRegionsInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NamedLocationIp {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#ip_ranges NamedLocation#ip_ranges}
    */
    readonly ipRanges: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#trusted NamedLocation#trusted}
    */
    readonly trusted?: boolean | cdktn.IResolvable;
}
export declare function namedLocationIpToTerraform(struct?: NamedLocationIpOutputReference | NamedLocationIp): any;
export declare function namedLocationIpToHclTerraform(struct?: NamedLocationIpOutputReference | NamedLocationIp): any;
export declare class NamedLocationIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NamedLocationIp | undefined;
    set internalValue(value: NamedLocationIp | undefined);
    private _ipRanges?;
    get ipRanges(): string[];
    set ipRanges(value: string[]);
    get ipRangesInput(): string[] | undefined;
    private _trusted?;
    get trusted(): boolean | cdktn.IResolvable;
    set trusted(value: boolean | cdktn.IResolvable);
    resetTrusted(): void;
    get trustedInput(): boolean | cdktn.IResolvable | undefined;
}
export interface NamedLocationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#create NamedLocation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#delete NamedLocation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#read NamedLocation#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#update NamedLocation#update}
    */
    readonly update?: string;
}
export declare function namedLocationTimeoutsToTerraform(struct?: NamedLocationTimeouts | cdktn.IResolvable): any;
export declare function namedLocationTimeoutsToHclTerraform(struct?: NamedLocationTimeouts | cdktn.IResolvable): any;
export declare class NamedLocationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): NamedLocationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: NamedLocationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location azuread_named_location}
*/
export declare class NamedLocation extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_named_location";
    /**
    * Generates CDKTN code for importing a NamedLocation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the NamedLocation to import
    * @param importFromId The id of the existing NamedLocation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the NamedLocation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/named_location azuread_named_location} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options NamedLocationConfig
    */
    constructor(scope: Construct, id: string, config: NamedLocationConfig);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get objectId(): string;
    private _country;
    get country(): NamedLocationCountryOutputReference;
    putCountry(value: NamedLocationCountry): void;
    resetCountry(): void;
    get countryInput(): NamedLocationCountry | undefined;
    private _ip;
    get ip(): NamedLocationIpOutputReference;
    putIp(value: NamedLocationIp): void;
    resetIp(): void;
    get ipInput(): NamedLocationIp | undefined;
    private _timeouts;
    get timeouts(): NamedLocationTimeoutsOutputReference;
    putTimeouts(value: NamedLocationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | NamedLocationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
