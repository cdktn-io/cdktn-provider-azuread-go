/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadUsersConfig extends cdktn.TerraformMetaArguments {
    /**
    * The employee identifier assigned to the user by the organisation
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#employee_ids DataAzureadUsers#employee_ids}
    */
    readonly employeeIds?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#id DataAzureadUsers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Ignore missing users and return users that were found. The data source will still fail if no users are found
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#ignore_missing DataAzureadUsers#ignore_missing}
    */
    readonly ignoreMissing?: boolean | cdktn.IResolvable;
    /**
    * The email aliases of the users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#mail_nicknames DataAzureadUsers#mail_nicknames}
    */
    readonly mailNicknames?: string[];
    /**
    * The SMTP address of the users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#mails DataAzureadUsers#mails}
    */
    readonly mails?: string[];
    /**
    * The object IDs of the users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#object_ids DataAzureadUsers#object_ids}
    */
    readonly objectIds?: string[];
    /**
    * Fetch all users with no filter and return all that were found. The data source will still fail if no users are found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#return_all DataAzureadUsers#return_all}
    */
    readonly returnAll?: boolean | cdktn.IResolvable;
    /**
    * The user principal names (UPNs) of the users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#user_principal_names DataAzureadUsers#user_principal_names}
    */
    readonly userPrincipalNames?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#timeouts DataAzureadUsers#timeouts}
    */
    readonly timeouts?: DataAzureadUsersTimeouts;
}
export interface DataAzureadUsersUsers {
}
export declare function dataAzureadUsersUsersToTerraform(struct?: DataAzureadUsersUsers): any;
export declare function dataAzureadUsersUsersToHclTerraform(struct?: DataAzureadUsersUsers): any;
export declare class DataAzureadUsersUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadUsersUsers | undefined;
    set internalValue(value: DataAzureadUsersUsers | undefined);
    get accountEnabled(): cdktn.IResolvable;
    get displayName(): string;
    get employeeId(): string;
    get mail(): string;
    get mailNickname(): string;
    get objectId(): string;
    get onpremisesImmutableId(): string;
    get onpremisesSamAccountName(): string;
    get onpremisesUserPrincipalName(): string;
    get usageLocation(): string;
    get userPrincipalName(): string;
}
export declare class DataAzureadUsersUsersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadUsersUsersOutputReference;
}
export interface DataAzureadUsersTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#read DataAzureadUsers#read}
    */
    readonly read?: string;
}
export declare function dataAzureadUsersTimeoutsToTerraform(struct?: DataAzureadUsersTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadUsersTimeoutsToHclTerraform(struct?: DataAzureadUsersTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadUsersTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadUsersTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadUsersTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users azuread_users}
*/
export declare class DataAzureadUsers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_users";
    /**
    * Generates CDKTN code for importing a DataAzureadUsers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadUsers to import
    * @param importFromId The id of the existing DataAzureadUsers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadUsers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/users azuread_users} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadUsersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadUsersConfig);
    private _employeeIds?;
    get employeeIds(): string[];
    set employeeIds(value: string[]);
    resetEmployeeIds(): void;
    get employeeIdsInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreMissing?;
    get ignoreMissing(): boolean | cdktn.IResolvable;
    set ignoreMissing(value: boolean | cdktn.IResolvable);
    resetIgnoreMissing(): void;
    get ignoreMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _mailNicknames?;
    get mailNicknames(): string[];
    set mailNicknames(value: string[]);
    resetMailNicknames(): void;
    get mailNicknamesInput(): string[] | undefined;
    private _mails?;
    get mails(): string[];
    set mails(value: string[]);
    resetMails(): void;
    get mailsInput(): string[] | undefined;
    private _objectIds?;
    get objectIds(): string[];
    set objectIds(value: string[]);
    resetObjectIds(): void;
    get objectIdsInput(): string[] | undefined;
    private _returnAll?;
    get returnAll(): boolean | cdktn.IResolvable;
    set returnAll(value: boolean | cdktn.IResolvable);
    resetReturnAll(): void;
    get returnAllInput(): boolean | cdktn.IResolvable | undefined;
    private _userPrincipalNames?;
    get userPrincipalNames(): string[];
    set userPrincipalNames(value: string[]);
    resetUserPrincipalNames(): void;
    get userPrincipalNamesInput(): string[] | undefined;
    private _users;
    get users(): DataAzureadUsersUsersList;
    private _timeouts;
    get timeouts(): DataAzureadUsersTimeoutsOutputReference;
    putTimeouts(value: DataAzureadUsersTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadUsersTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
