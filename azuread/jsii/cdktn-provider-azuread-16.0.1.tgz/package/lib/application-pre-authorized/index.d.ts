/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationPreAuthorizedConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ID of the application to which this pre-authorized application should be added
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#application_id ApplicationPreAuthorized#application_id}
    */
    readonly applicationId: string;
    /**
    * The client ID of the pre-authorized application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#authorized_client_id ApplicationPreAuthorized#authorized_client_id}
    */
    readonly authorizedClientId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#id ApplicationPreAuthorized#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The IDs of the permission scopes required by the pre-authorized application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#permission_ids ApplicationPreAuthorized#permission_ids}
    */
    readonly permissionIds: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#timeouts ApplicationPreAuthorized#timeouts}
    */
    readonly timeouts?: ApplicationPreAuthorizedTimeouts;
}
export interface ApplicationPreAuthorizedTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#create ApplicationPreAuthorized#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#delete ApplicationPreAuthorized#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#read ApplicationPreAuthorized#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#update ApplicationPreAuthorized#update}
    */
    readonly update?: string;
}
export declare function applicationPreAuthorizedTimeoutsToTerraform(struct?: ApplicationPreAuthorizedTimeouts | cdktn.IResolvable): any;
export declare function applicationPreAuthorizedTimeoutsToHclTerraform(struct?: ApplicationPreAuthorizedTimeouts | cdktn.IResolvable): any;
export declare class ApplicationPreAuthorizedTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationPreAuthorizedTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationPreAuthorizedTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized azuread_application_pre_authorized}
*/
export declare class ApplicationPreAuthorized extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_pre_authorized";
    /**
    * Generates CDKTN code for importing a ApplicationPreAuthorized resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationPreAuthorized to import
    * @param importFromId The id of the existing ApplicationPreAuthorized that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationPreAuthorized to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_pre_authorized azuread_application_pre_authorized} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationPreAuthorizedConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationPreAuthorizedConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _authorizedClientId?;
    get authorizedClientId(): string;
    set authorizedClientId(value: string);
    get authorizedClientIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _permissionIds?;
    get permissionIds(): string[];
    set permissionIds(value: string[]);
    get permissionIdsInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ApplicationPreAuthorizedTimeoutsOutputReference;
    putTimeouts(value: ApplicationPreAuthorizedTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationPreAuthorizedTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
