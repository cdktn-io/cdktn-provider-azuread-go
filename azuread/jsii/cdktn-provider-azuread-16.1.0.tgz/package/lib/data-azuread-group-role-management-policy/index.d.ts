/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadGroupRoleManagementPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * ID of the group to which this policy is assigned
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy#group_id DataAzureadGroupRoleManagementPolicy#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy#id DataAzureadGroupRoleManagementPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the role of this policy to the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy#role_id DataAzureadGroupRoleManagementPolicy#role_id}
    */
    readonly roleId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy#timeouts DataAzureadGroupRoleManagementPolicy#timeouts}
    */
    readonly timeouts?: DataAzureadGroupRoleManagementPolicyTimeouts;
}
export interface DataAzureadGroupRoleManagementPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy#read DataAzureadGroupRoleManagementPolicy#read}
    */
    readonly read?: string;
}
export declare function dataAzureadGroupRoleManagementPolicyTimeoutsToTerraform(struct?: DataAzureadGroupRoleManagementPolicyTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadGroupRoleManagementPolicyTimeoutsToHclTerraform(struct?: DataAzureadGroupRoleManagementPolicyTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadGroupRoleManagementPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadGroupRoleManagementPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadGroupRoleManagementPolicyTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy azuread_group_role_management_policy}
*/
export declare class DataAzureadGroupRoleManagementPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_group_role_management_policy";
    /**
    * Generates CDKTN code for importing a DataAzureadGroupRoleManagementPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadGroupRoleManagementPolicy to import
    * @param importFromId The id of the existing DataAzureadGroupRoleManagementPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadGroupRoleManagementPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/group_role_management_policy azuread_group_role_management_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadGroupRoleManagementPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataAzureadGroupRoleManagementPolicyConfig);
    get description(): string;
    get displayName(): string;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzureadGroupRoleManagementPolicyTimeoutsOutputReference;
    putTimeouts(value: DataAzureadGroupRoleManagementPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadGroupRoleManagementPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
