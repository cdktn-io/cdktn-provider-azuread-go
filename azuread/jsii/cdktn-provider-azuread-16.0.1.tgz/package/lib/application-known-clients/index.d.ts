/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationKnownClientsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ID of the application to which this API access is granted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#application_id ApplicationKnownClients#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#id ApplicationKnownClients#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A list of known client IDs, used for bundling consent if you have a solution that includes an API and a client application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#known_client_ids ApplicationKnownClients#known_client_ids}
    */
    readonly knownClientIds: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#timeouts ApplicationKnownClients#timeouts}
    */
    readonly timeouts?: ApplicationKnownClientsTimeouts;
}
export interface ApplicationKnownClientsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#create ApplicationKnownClients#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#delete ApplicationKnownClients#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#read ApplicationKnownClients#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#update ApplicationKnownClients#update}
    */
    readonly update?: string;
}
export declare function applicationKnownClientsTimeoutsToTerraform(struct?: ApplicationKnownClientsTimeouts | cdktn.IResolvable): any;
export declare function applicationKnownClientsTimeoutsToHclTerraform(struct?: ApplicationKnownClientsTimeouts | cdktn.IResolvable): any;
export declare class ApplicationKnownClientsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationKnownClientsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationKnownClientsTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients azuread_application_known_clients}
*/
export declare class ApplicationKnownClients extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_known_clients";
    /**
    * Generates CDKTN code for importing a ApplicationKnownClients resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationKnownClients to import
    * @param importFromId The id of the existing ApplicationKnownClients that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationKnownClients to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_known_clients azuread_application_known_clients} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationKnownClientsConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationKnownClientsConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _knownClientIds?;
    get knownClientIds(): string[];
    set knownClientIds(value: string[]);
    get knownClientIdsInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ApplicationKnownClientsTimeoutsOutputReference;
    putTimeouts(value: ApplicationKnownClientsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationKnownClientsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
