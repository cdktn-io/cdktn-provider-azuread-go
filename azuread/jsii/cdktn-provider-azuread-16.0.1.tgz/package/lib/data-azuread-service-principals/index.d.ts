/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadServicePrincipalsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The client IDs of the applications associated with the service principals
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#client_ids DataAzureadServicePrincipals#client_ids}
    */
    readonly clientIds?: string[];
    /**
    * The display names of the applications associated with the service principals
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#display_names DataAzureadServicePrincipals#display_names}
    */
    readonly displayNames?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#id DataAzureadServicePrincipals#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Ignore missing service principals and return the service principals that were found. The data source will still fail if no service principals are found
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#ignore_missing DataAzureadServicePrincipals#ignore_missing}
    */
    readonly ignoreMissing?: boolean | cdktn.IResolvable;
    /**
    * The object IDs of the service principals
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#object_ids DataAzureadServicePrincipals#object_ids}
    */
    readonly objectIds?: string[];
    /**
    * Fetch all service principals with no filter and return all that were found. The data source will still fail if no service principals are found.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#return_all DataAzureadServicePrincipals#return_all}
    */
    readonly returnAll?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#timeouts DataAzureadServicePrincipals#timeouts}
    */
    readonly timeouts?: DataAzureadServicePrincipalsTimeouts;
}
export interface DataAzureadServicePrincipalsServicePrincipals {
}
export declare function dataAzureadServicePrincipalsServicePrincipalsToTerraform(struct?: DataAzureadServicePrincipalsServicePrincipals): any;
export declare function dataAzureadServicePrincipalsServicePrincipalsToHclTerraform(struct?: DataAzureadServicePrincipalsServicePrincipals): any;
export declare class DataAzureadServicePrincipalsServicePrincipalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadServicePrincipalsServicePrincipals | undefined;
    set internalValue(value: DataAzureadServicePrincipalsServicePrincipals | undefined);
    get accountEnabled(): cdktn.IResolvable;
    get appRoleAssignmentRequired(): cdktn.IResolvable;
    get applicationTenantId(): string;
    get clientId(): string;
    get displayName(): string;
    get objectId(): string;
    get preferredSingleSignOnMode(): string;
    get samlMetadataUrl(): string;
    get servicePrincipalNames(): string[];
    get signInAudience(): string;
    get tags(): string[];
    get type(): string;
}
export declare class DataAzureadServicePrincipalsServicePrincipalsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadServicePrincipalsServicePrincipalsOutputReference;
}
export interface DataAzureadServicePrincipalsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#read DataAzureadServicePrincipals#read}
    */
    readonly read?: string;
}
export declare function dataAzureadServicePrincipalsTimeoutsToTerraform(struct?: DataAzureadServicePrincipalsTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadServicePrincipalsTimeoutsToHclTerraform(struct?: DataAzureadServicePrincipalsTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadServicePrincipalsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadServicePrincipalsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadServicePrincipalsTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals azuread_service_principals}
*/
export declare class DataAzureadServicePrincipals extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_service_principals";
    /**
    * Generates CDKTN code for importing a DataAzureadServicePrincipals resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadServicePrincipals to import
    * @param importFromId The id of the existing DataAzureadServicePrincipals that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadServicePrincipals to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/service_principals azuread_service_principals} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadServicePrincipalsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadServicePrincipalsConfig);
    private _clientIds?;
    get clientIds(): string[];
    set clientIds(value: string[]);
    resetClientIds(): void;
    get clientIdsInput(): string[] | undefined;
    private _displayNames?;
    get displayNames(): string[];
    set displayNames(value: string[]);
    resetDisplayNames(): void;
    get displayNamesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ignoreMissing?;
    get ignoreMissing(): boolean | cdktn.IResolvable;
    set ignoreMissing(value: boolean | cdktn.IResolvable);
    resetIgnoreMissing(): void;
    get ignoreMissingInput(): boolean | cdktn.IResolvable | undefined;
    private _objectIds?;
    get objectIds(): string[];
    set objectIds(value: string[]);
    resetObjectIds(): void;
    get objectIdsInput(): string[] | undefined;
    private _returnAll?;
    get returnAll(): boolean | cdktn.IResolvable;
    set returnAll(value: boolean | cdktn.IResolvable);
    resetReturnAll(): void;
    get returnAllInput(): boolean | cdktn.IResolvable | undefined;
    private _servicePrincipals;
    get servicePrincipals(): DataAzureadServicePrincipalsServicePrincipalsList;
    private _timeouts;
    get timeouts(): DataAzureadServicePrincipalsTimeoutsOutputReference;
    putTimeouts(value: DataAzureadServicePrincipalsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadServicePrincipalsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
