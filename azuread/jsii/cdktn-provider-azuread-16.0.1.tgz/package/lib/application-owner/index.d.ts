/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationOwnerConfig extends cdktn.TerraformMetaArguments {
    /**
    * The resource ID of the application to which the owner should be added
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#application_id ApplicationOwner#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#id ApplicationOwner#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Object ID of the principal that will be granted ownership of the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#owner_object_id ApplicationOwner#owner_object_id}
    */
    readonly ownerObjectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#timeouts ApplicationOwner#timeouts}
    */
    readonly timeouts?: ApplicationOwnerTimeouts;
}
export interface ApplicationOwnerTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#create ApplicationOwner#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#delete ApplicationOwner#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#read ApplicationOwner#read}
    */
    readonly read?: string;
}
export declare function applicationOwnerTimeoutsToTerraform(struct?: ApplicationOwnerTimeouts | cdktn.IResolvable): any;
export declare function applicationOwnerTimeoutsToHclTerraform(struct?: ApplicationOwnerTimeouts | cdktn.IResolvable): any;
export declare class ApplicationOwnerTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationOwnerTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationOwnerTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner azuread_application_owner}
*/
export declare class ApplicationOwner extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_owner";
    /**
    * Generates CDKTN code for importing a ApplicationOwner resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationOwner to import
    * @param importFromId The id of the existing ApplicationOwner that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationOwner to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_owner azuread_application_owner} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationOwnerConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationOwnerConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ownerObjectId?;
    get ownerObjectId(): string;
    set ownerObjectId(value: string);
    get ownerObjectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationOwnerTimeoutsOutputReference;
    putTimeouts(value: ApplicationOwnerTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationOwnerTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
