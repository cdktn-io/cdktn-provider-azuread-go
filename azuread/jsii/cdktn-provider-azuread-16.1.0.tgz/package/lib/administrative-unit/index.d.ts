/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AdministrativeUnitConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description for the administrative unit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#description AdministrativeUnit#description}
    */
    readonly description?: string;
    /**
    * The display name for the administrative unit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#display_name AdministrativeUnit#display_name}
    */
    readonly displayName: string;
    /**
    * Whether the administrative unit and its members are hidden or publicly viewable in the directory
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#hidden_membership_enabled AdministrativeUnit#hidden_membership_enabled}
    */
    readonly hiddenMembershipEnabled?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#id AdministrativeUnit#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A set of object IDs of members who should be present in this administrative unit. Supported object types are Users or Groups
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#members AdministrativeUnit#members}
    */
    readonly members?: string[];
    /**
    * If `true`, will return an error if an existing administrative unit is found with the same name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#prevent_duplicate_names AdministrativeUnit#prevent_duplicate_names}
    */
    readonly preventDuplicateNames?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#timeouts AdministrativeUnit#timeouts}
    */
    readonly timeouts?: AdministrativeUnitTimeouts;
}
export interface AdministrativeUnitTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#create AdministrativeUnit#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#delete AdministrativeUnit#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#read AdministrativeUnit#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#update AdministrativeUnit#update}
    */
    readonly update?: string;
}
export declare function administrativeUnitTimeoutsToTerraform(struct?: AdministrativeUnitTimeouts | cdktn.IResolvable): any;
export declare function administrativeUnitTimeoutsToHclTerraform(struct?: AdministrativeUnitTimeouts | cdktn.IResolvable): any;
export declare class AdministrativeUnitTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AdministrativeUnitTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AdministrativeUnitTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit azuread_administrative_unit}
*/
export declare class AdministrativeUnit extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_administrative_unit";
    /**
    * Generates CDKTN code for importing a AdministrativeUnit resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AdministrativeUnit to import
    * @param importFromId The id of the existing AdministrativeUnit that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AdministrativeUnit to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/administrative_unit azuread_administrative_unit} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AdministrativeUnitConfig
    */
    constructor(scope: Construct, id: string, config: AdministrativeUnitConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _hiddenMembershipEnabled?;
    get hiddenMembershipEnabled(): boolean | cdktn.IResolvable;
    set hiddenMembershipEnabled(value: boolean | cdktn.IResolvable);
    resetHiddenMembershipEnabled(): void;
    get hiddenMembershipEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _members?;
    get members(): string[];
    set members(value: string[]);
    resetMembers(): void;
    get membersInput(): string[] | undefined;
    get objectId(): string;
    private _preventDuplicateNames?;
    get preventDuplicateNames(): boolean | cdktn.IResolvable;
    set preventDuplicateNames(value: boolean | cdktn.IResolvable);
    resetPreventDuplicateNames(): void;
    get preventDuplicateNamesInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AdministrativeUnitTimeoutsOutputReference;
    putTimeouts(value: AdministrativeUnitTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AdministrativeUnitTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
