/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AzureadProviderConfig {
    /**
    * The Azure DevOps Pipeline Service Connection ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#ado_pipeline_service_connection_id AzureadProvider#ado_pipeline_service_connection_id}
    */
    readonly adoPipelineServiceConnectionId?: string;
    /**
    * Base64 encoded PKCS#12 certificate bundle to use when authenticating as a Service Principal using a Client Certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#client_certificate AzureadProvider#client_certificate}
    */
    readonly clientCertificate?: string;
    /**
    * The password to decrypt the Client Certificate. For use when authenticating as a Service Principal using a Client Certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#client_certificate_password AzureadProvider#client_certificate_password}
    */
    readonly clientCertificatePassword?: string;
    /**
    * The path to the Client Certificate associated with the Service Principal for use when authenticating as a Service Principal using a Client Certificate
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#client_certificate_path AzureadProvider#client_certificate_path}
    */
    readonly clientCertificatePath?: string;
    /**
    * The Client ID which should be used for service principal authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#client_id AzureadProvider#client_id}
    */
    readonly clientId?: string;
    /**
    * The path to a file containing the Client ID which should be used for service principal authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#client_id_file_path AzureadProvider#client_id_file_path}
    */
    readonly clientIdFilePath?: string;
    /**
    * The application password to use when authenticating as a Service Principal using a Client Secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#client_secret AzureadProvider#client_secret}
    */
    readonly clientSecret?: string;
    /**
    * The path to a file containing the application password to use when authenticating as a Service Principal using a Client Secret
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#client_secret_file_path AzureadProvider#client_secret_file_path}
    */
    readonly clientSecretFilePath?: string;
    /**
    * Disable the Terraform Partner ID, which is used if a custom `partner_id` isn't specified
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#disable_terraform_partner_id AzureadProvider#disable_terraform_partner_id}
    */
    readonly disableTerraformPartnerId?: boolean | cdktn.IResolvable;
    /**
    * The cloud environment which should be used. Possible values are: `global` (also `public`), `usgovernmentl4` (also `usgovernment`), `usgovernmentl5` (also `dod`), and `china`. Defaults to `global`. Not used and should not be specified when `metadata_host` is specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#environment AzureadProvider#environment}
    */
    readonly environment?: string;
    /**
    * The Hostname which should be used for the Azure Metadata Service.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#metadata_host AzureadProvider#metadata_host}
    */
    readonly metadataHost?: string;
    /**
    * The path to a custom endpoint for Managed Identity - in most circumstances this should be detected automatically
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#msi_endpoint AzureadProvider#msi_endpoint}
    */
    readonly msiEndpoint?: string;
    /**
    * The bearer token for the request to the OIDC provider. For use when authenticating as a Service Principal using OpenID Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#oidc_request_token AzureadProvider#oidc_request_token}
    */
    readonly oidcRequestToken?: string;
    /**
    * The URL for the OIDC provider from which to request an ID token. For use when authenticating as a Service Principal using OpenID Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#oidc_request_url AzureadProvider#oidc_request_url}
    */
    readonly oidcRequestUrl?: string;
    /**
    * The ID token for use when authenticating as a Service Principal using OpenID Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#oidc_token AzureadProvider#oidc_token}
    */
    readonly oidcToken?: string;
    /**
    * The path to a file containing an ID token for use when authenticating as a Service Principal using OpenID Connect.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#oidc_token_file_path AzureadProvider#oidc_token_file_path}
    */
    readonly oidcTokenFilePath?: string;
    /**
    * A GUID/UUID that is registered with Microsoft to facilitate partner resource usage attribution
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#partner_id AzureadProvider#partner_id}
    */
    readonly partnerId?: string;
    /**
    * The Tenant ID which should be used. Works with all authentication methods except Managed Identity
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#tenant_id AzureadProvider#tenant_id}
    */
    readonly tenantId?: string;
    /**
    * Allow Azure AKS Workload Identity to be used for Authentication.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#use_aks_workload_identity AzureadProvider#use_aks_workload_identity}
    */
    readonly useAksWorkloadIdentity?: boolean | cdktn.IResolvable;
    /**
    * Allow Azure CLI to be used for Authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#use_cli AzureadProvider#use_cli}
    */
    readonly useCli?: boolean | cdktn.IResolvable;
    /**
    * Allow Managed Identity to be used for Authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#use_msi AzureadProvider#use_msi}
    */
    readonly useMsi?: boolean | cdktn.IResolvable;
    /**
    * Allow OpenID Connect to be used for authentication
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#use_oidc AzureadProvider#use_oidc}
    */
    readonly useOidc?: boolean | cdktn.IResolvable;
    /**
    * Alias name
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#alias AzureadProvider#alias}
    */
    readonly alias?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs azuread}
*/
export declare class AzureadProvider extends cdktn.TerraformProvider {
    static readonly tfResourceType = "azuread";
    /**
    * Generates CDKTN code for importing a AzureadProvider resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AzureadProvider to import
    * @param importFromId The id of the existing AzureadProvider that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AzureadProvider to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs azuread} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AzureadProviderConfig = {}
    */
    constructor(scope: Construct, id: string, config?: AzureadProviderConfig);
    private _adoPipelineServiceConnectionId?;
    get adoPipelineServiceConnectionId(): string | undefined;
    set adoPipelineServiceConnectionId(value: string | undefined);
    resetAdoPipelineServiceConnectionId(): void;
    get adoPipelineServiceConnectionIdInput(): string | undefined;
    private _clientCertificate?;
    get clientCertificate(): string | undefined;
    set clientCertificate(value: string | undefined);
    resetClientCertificate(): void;
    get clientCertificateInput(): string | undefined;
    private _clientCertificatePassword?;
    get clientCertificatePassword(): string | undefined;
    set clientCertificatePassword(value: string | undefined);
    resetClientCertificatePassword(): void;
    get clientCertificatePasswordInput(): string | undefined;
    private _clientCertificatePath?;
    get clientCertificatePath(): string | undefined;
    set clientCertificatePath(value: string | undefined);
    resetClientCertificatePath(): void;
    get clientCertificatePathInput(): string | undefined;
    private _clientId?;
    get clientId(): string | undefined;
    set clientId(value: string | undefined);
    resetClientId(): void;
    get clientIdInput(): string | undefined;
    private _clientIdFilePath?;
    get clientIdFilePath(): string | undefined;
    set clientIdFilePath(value: string | undefined);
    resetClientIdFilePath(): void;
    get clientIdFilePathInput(): string | undefined;
    private _clientSecret?;
    get clientSecret(): string | undefined;
    set clientSecret(value: string | undefined);
    resetClientSecret(): void;
    get clientSecretInput(): string | undefined;
    private _clientSecretFilePath?;
    get clientSecretFilePath(): string | undefined;
    set clientSecretFilePath(value: string | undefined);
    resetClientSecretFilePath(): void;
    get clientSecretFilePathInput(): string | undefined;
    private _disableTerraformPartnerId?;
    get disableTerraformPartnerId(): boolean | cdktn.IResolvable | undefined;
    set disableTerraformPartnerId(value: boolean | cdktn.IResolvable | undefined);
    resetDisableTerraformPartnerId(): void;
    get disableTerraformPartnerIdInput(): boolean | cdktn.IResolvable | undefined;
    private _environment?;
    get environment(): string | undefined;
    set environment(value: string | undefined);
    resetEnvironment(): void;
    get environmentInput(): string | undefined;
    private _metadataHost?;
    get metadataHost(): string | undefined;
    set metadataHost(value: string | undefined);
    resetMetadataHost(): void;
    get metadataHostInput(): string | undefined;
    private _msiEndpoint?;
    get msiEndpoint(): string | undefined;
    set msiEndpoint(value: string | undefined);
    resetMsiEndpoint(): void;
    get msiEndpointInput(): string | undefined;
    private _oidcRequestToken?;
    get oidcRequestToken(): string | undefined;
    set oidcRequestToken(value: string | undefined);
    resetOidcRequestToken(): void;
    get oidcRequestTokenInput(): string | undefined;
    private _oidcRequestUrl?;
    get oidcRequestUrl(): string | undefined;
    set oidcRequestUrl(value: string | undefined);
    resetOidcRequestUrl(): void;
    get oidcRequestUrlInput(): string | undefined;
    private _oidcToken?;
    get oidcToken(): string | undefined;
    set oidcToken(value: string | undefined);
    resetOidcToken(): void;
    get oidcTokenInput(): string | undefined;
    private _oidcTokenFilePath?;
    get oidcTokenFilePath(): string | undefined;
    set oidcTokenFilePath(value: string | undefined);
    resetOidcTokenFilePath(): void;
    get oidcTokenFilePathInput(): string | undefined;
    private _partnerId?;
    get partnerId(): string | undefined;
    set partnerId(value: string | undefined);
    resetPartnerId(): void;
    get partnerIdInput(): string | undefined;
    private _tenantId?;
    get tenantId(): string | undefined;
    set tenantId(value: string | undefined);
    resetTenantId(): void;
    get tenantIdInput(): string | undefined;
    private _useAksWorkloadIdentity?;
    get useAksWorkloadIdentity(): boolean | cdktn.IResolvable | undefined;
    set useAksWorkloadIdentity(value: boolean | cdktn.IResolvable | undefined);
    resetUseAksWorkloadIdentity(): void;
    get useAksWorkloadIdentityInput(): boolean | cdktn.IResolvable | undefined;
    private _useCli?;
    get useCli(): boolean | cdktn.IResolvable | undefined;
    set useCli(value: boolean | cdktn.IResolvable | undefined);
    resetUseCli(): void;
    get useCliInput(): boolean | cdktn.IResolvable | undefined;
    private _useMsi?;
    get useMsi(): boolean | cdktn.IResolvable | undefined;
    set useMsi(value: boolean | cdktn.IResolvable | undefined);
    resetUseMsi(): void;
    get useMsiInput(): boolean | cdktn.IResolvable | undefined;
    private _useOidc?;
    get useOidc(): boolean | cdktn.IResolvable | undefined;
    set useOidc(value: boolean | cdktn.IResolvable | undefined);
    resetUseOidc(): void;
    get useOidcInput(): boolean | cdktn.IResolvable | undefined;
    private _alias?;
    get alias(): string | undefined;
    set alias(value: string | undefined);
    resetAlias(): void;
    get aliasInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
