/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessPackageResourcePackageAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of access package this resource association is configured to
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#access_package_id AccessPackageResourcePackageAssociation#access_package_id}
    */
    readonly accessPackageId: string;
    /**
    * The role of access type to the specified resource, valid values are `Member` and `Owner`
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#access_type AccessPackageResourcePackageAssociation#access_type}
    */
    readonly accessType?: string;
    /**
    * The ID of the access package catalog association
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#catalog_resource_association_id AccessPackageResourcePackageAssociation#catalog_resource_association_id}
    */
    readonly catalogResourceAssociationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#id AccessPackageResourcePackageAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#timeouts AccessPackageResourcePackageAssociation#timeouts}
    */
    readonly timeouts?: AccessPackageResourcePackageAssociationTimeouts;
}
export interface AccessPackageResourcePackageAssociationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#create AccessPackageResourcePackageAssociation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#delete AccessPackageResourcePackageAssociation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#read AccessPackageResourcePackageAssociation#read}
    */
    readonly read?: string;
}
export declare function accessPackageResourcePackageAssociationTimeoutsToTerraform(struct?: AccessPackageResourcePackageAssociationTimeouts | cdktn.IResolvable): any;
export declare function accessPackageResourcePackageAssociationTimeoutsToHclTerraform(struct?: AccessPackageResourcePackageAssociationTimeouts | cdktn.IResolvable): any;
export declare class AccessPackageResourcePackageAssociationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageResourcePackageAssociationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageResourcePackageAssociationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association azuread_access_package_resource_package_association}
*/
export declare class AccessPackageResourcePackageAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_access_package_resource_package_association";
    /**
    * Generates CDKTN code for importing a AccessPackageResourcePackageAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPackageResourcePackageAssociation to import
    * @param importFromId The id of the existing AccessPackageResourcePackageAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPackageResourcePackageAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_resource_package_association azuread_access_package_resource_package_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPackageResourcePackageAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AccessPackageResourcePackageAssociationConfig);
    private _accessPackageId?;
    get accessPackageId(): string;
    set accessPackageId(value: string);
    get accessPackageIdInput(): string | undefined;
    private _accessType?;
    get accessType(): string;
    set accessType(value: string);
    resetAccessType(): void;
    get accessTypeInput(): string | undefined;
    private _catalogResourceAssociationId?;
    get catalogResourceAssociationId(): string;
    set catalogResourceAssociationId(value: string);
    get catalogResourceAssociationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AccessPackageResourcePackageAssociationTimeoutsOutputReference;
    putTimeouts(value: AccessPackageResourcePackageAssociationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessPackageResourcePackageAssociationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
