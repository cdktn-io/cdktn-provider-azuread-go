/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadDirectoryRoleTemplatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/directory_role_templates#id DataAzureadDirectoryRoleTemplates#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/directory_role_templates#timeouts DataAzureadDirectoryRoleTemplates#timeouts}
    */
    readonly timeouts?: DataAzureadDirectoryRoleTemplatesTimeouts;
}
export interface DataAzureadDirectoryRoleTemplatesRoleTemplates {
}
export declare function dataAzureadDirectoryRoleTemplatesRoleTemplatesToTerraform(struct?: DataAzureadDirectoryRoleTemplatesRoleTemplates): any;
export declare function dataAzureadDirectoryRoleTemplatesRoleTemplatesToHclTerraform(struct?: DataAzureadDirectoryRoleTemplatesRoleTemplates): any;
export declare class DataAzureadDirectoryRoleTemplatesRoleTemplatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadDirectoryRoleTemplatesRoleTemplates | undefined;
    set internalValue(value: DataAzureadDirectoryRoleTemplatesRoleTemplates | undefined);
    get description(): string;
    get displayName(): string;
    get objectId(): string;
}
export declare class DataAzureadDirectoryRoleTemplatesRoleTemplatesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadDirectoryRoleTemplatesRoleTemplatesOutputReference;
}
export interface DataAzureadDirectoryRoleTemplatesTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/directory_role_templates#read DataAzureadDirectoryRoleTemplates#read}
    */
    readonly read?: string;
}
export declare function dataAzureadDirectoryRoleTemplatesTimeoutsToTerraform(struct?: DataAzureadDirectoryRoleTemplatesTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadDirectoryRoleTemplatesTimeoutsToHclTerraform(struct?: DataAzureadDirectoryRoleTemplatesTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadDirectoryRoleTemplatesTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadDirectoryRoleTemplatesTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadDirectoryRoleTemplatesTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/directory_role_templates azuread_directory_role_templates}
*/
export declare class DataAzureadDirectoryRoleTemplates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_directory_role_templates";
    /**
    * Generates CDKTN code for importing a DataAzureadDirectoryRoleTemplates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadDirectoryRoleTemplates to import
    * @param importFromId The id of the existing DataAzureadDirectoryRoleTemplates that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/directory_role_templates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadDirectoryRoleTemplates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/data-sources/directory_role_templates azuread_directory_role_templates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadDirectoryRoleTemplatesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadDirectoryRoleTemplatesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get objectIds(): string[];
    private _roleTemplates;
    get roleTemplates(): DataAzureadDirectoryRoleTemplatesRoleTemplatesList;
    private _timeouts;
    get timeouts(): DataAzureadDirectoryRoleTemplatesTimeoutsOutputReference;
    putTimeouts(value: DataAzureadDirectoryRoleTemplatesTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadDirectoryRoleTemplatesTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
