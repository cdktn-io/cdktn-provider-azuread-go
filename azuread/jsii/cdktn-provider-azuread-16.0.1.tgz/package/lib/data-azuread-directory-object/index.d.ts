/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadDirectoryObjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_object#id DataAzureadDirectoryObject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the Directory Object
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_object#object_id DataAzureadDirectoryObject#object_id}
    */
    readonly objectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_object#timeouts DataAzureadDirectoryObject#timeouts}
    */
    readonly timeouts?: DataAzureadDirectoryObjectTimeouts;
}
export interface DataAzureadDirectoryObjectTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_object#read DataAzureadDirectoryObject#read}
    */
    readonly read?: string;
}
export declare function dataAzureadDirectoryObjectTimeoutsToTerraform(struct?: DataAzureadDirectoryObjectTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadDirectoryObjectTimeoutsToHclTerraform(struct?: DataAzureadDirectoryObjectTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadDirectoryObjectTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadDirectoryObjectTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadDirectoryObjectTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_object azuread_directory_object}
*/
export declare class DataAzureadDirectoryObject extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_directory_object";
    /**
    * Generates CDKTN code for importing a DataAzureadDirectoryObject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadDirectoryObject to import
    * @param importFromId The id of the existing DataAzureadDirectoryObject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_object#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadDirectoryObject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/directory_object azuread_directory_object} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadDirectoryObjectConfig
    */
    constructor(scope: Construct, id: string, config: DataAzureadDirectoryObjectConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    get objectIdInput(): string | undefined;
    get type(): string;
    private _timeouts;
    get timeouts(): DataAzureadDirectoryObjectTimeoutsOutputReference;
    putTimeouts(value: DataAzureadDirectoryObjectTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadDirectoryObjectTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
