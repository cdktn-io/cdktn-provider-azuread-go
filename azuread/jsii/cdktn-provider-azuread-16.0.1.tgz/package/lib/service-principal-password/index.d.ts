/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ServicePrincipalPasswordConfig extends cdktn.TerraformMetaArguments {
    /**
    * A display name for the password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#display_name ServicePrincipalPassword#display_name}
    */
    readonly displayName?: string;
    /**
    * The end date until which the password is valid, formatted as an RFC3339 date string (e.g. `2018-01-01T01:02:03Z`)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#end_date ServicePrincipalPassword#end_date}
    */
    readonly endDate?: string;
    /**
    * A relative duration for which the password is valid until, for example `240h` (10 days) or `2400h30m`. Changing this field forces a new resource to be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#end_date_relative ServicePrincipalPassword#end_date_relative}
    */
    readonly endDateRelative?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#id ServicePrincipalPassword#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Arbitrary map of values that, when changed, will trigger rotation of the password
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#rotate_when_changed ServicePrincipalPassword#rotate_when_changed}
    */
    readonly rotateWhenChanged?: {
        [key: string]: string;
    };
    /**
    * The ID of the service principal for which this password should be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#service_principal_id ServicePrincipalPassword#service_principal_id}
    */
    readonly servicePrincipalId: string;
    /**
    * The start date from which the password is valid, formatted as an RFC3339 date string (e.g. `2018-01-01T01:02:03Z`). If this isn't specified, the current date is used
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#start_date ServicePrincipalPassword#start_date}
    */
    readonly startDate?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#timeouts ServicePrincipalPassword#timeouts}
    */
    readonly timeouts?: ServicePrincipalPasswordTimeouts;
}
export interface ServicePrincipalPasswordTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#create ServicePrincipalPassword#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#delete ServicePrincipalPassword#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#read ServicePrincipalPassword#read}
    */
    readonly read?: string;
}
export declare function servicePrincipalPasswordTimeoutsToTerraform(struct?: ServicePrincipalPasswordTimeouts | cdktn.IResolvable): any;
export declare function servicePrincipalPasswordTimeoutsToHclTerraform(struct?: ServicePrincipalPasswordTimeouts | cdktn.IResolvable): any;
export declare class ServicePrincipalPasswordTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ServicePrincipalPasswordTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ServicePrincipalPasswordTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password azuread_service_principal_password}
*/
export declare class ServicePrincipalPassword extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_service_principal_password";
    /**
    * Generates CDKTN code for importing a ServicePrincipalPassword resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ServicePrincipalPassword to import
    * @param importFromId The id of the existing ServicePrincipalPassword that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ServicePrincipalPassword to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/service_principal_password azuread_service_principal_password} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ServicePrincipalPasswordConfig
    */
    constructor(scope: Construct, id: string, config: ServicePrincipalPasswordConfig);
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _endDate?;
    get endDate(): string;
    set endDate(value: string);
    resetEndDate(): void;
    get endDateInput(): string | undefined;
    private _endDateRelative?;
    get endDateRelative(): string;
    set endDateRelative(value: string);
    resetEndDateRelative(): void;
    get endDateRelativeInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get keyId(): string;
    private _rotateWhenChanged?;
    get rotateWhenChanged(): {
        [key: string]: string;
    };
    set rotateWhenChanged(value: {
        [key: string]: string;
    });
    resetRotateWhenChanged(): void;
    get rotateWhenChangedInput(): {
        [key: string]: string;
    } | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    get value(): string;
    private _timeouts;
    get timeouts(): ServicePrincipalPasswordTimeoutsOutputReference;
    putTimeouts(value: ServicePrincipalPasswordTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ServicePrincipalPasswordTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
