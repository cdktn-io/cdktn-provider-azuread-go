/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface PrivilegedAccessGroupEligibilityScheduleConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the assignment to the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#assignment_type PrivilegedAccessGroupEligibilitySchedule#assignment_type}
    */
    readonly assignmentType: string;
    /**
    * The duration of the assignment, formatted as an ISO8601 duration string (e.g. P3D for 3 days)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#duration PrivilegedAccessGroupEligibilitySchedule#duration}
    */
    readonly duration?: string;
    /**
    * The date that this assignment expires, formatted as an RFC3339 date string in UTC (e.g. 2018-01-01T01:02:03Z)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#expiration_date PrivilegedAccessGroupEligibilitySchedule#expiration_date}
    */
    readonly expirationDate?: string;
    /**
    * The ID of the Group representing the scope of the assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#group_id PrivilegedAccessGroupEligibilitySchedule#group_id}
    */
    readonly groupId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#id PrivilegedAccessGroupEligibilitySchedule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The justification for the assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#justification PrivilegedAccessGroupEligibilitySchedule#justification}
    */
    readonly justification?: string;
    /**
    * Is the assignment permanent
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#permanent_assignment PrivilegedAccessGroupEligibilitySchedule#permanent_assignment}
    */
    readonly permanentAssignment?: boolean | cdktn.IResolvable;
    /**
    * The ID of the Principal assigned to the schedule
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#principal_id PrivilegedAccessGroupEligibilitySchedule#principal_id}
    */
    readonly principalId: string;
    /**
    * The date that this assignment starts, formatted as an RFC3339 date string in UTC (e.g. 2018-01-01T01:02:03Z)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#start_date PrivilegedAccessGroupEligibilitySchedule#start_date}
    */
    readonly startDate?: string;
    /**
    * The ticket number authorising the assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#ticket_number PrivilegedAccessGroupEligibilitySchedule#ticket_number}
    */
    readonly ticketNumber?: string;
    /**
    * The ticket system authorising the assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#ticket_system PrivilegedAccessGroupEligibilitySchedule#ticket_system}
    */
    readonly ticketSystem?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#timeouts PrivilegedAccessGroupEligibilitySchedule#timeouts}
    */
    readonly timeouts?: PrivilegedAccessGroupEligibilityScheduleTimeouts;
}
export interface PrivilegedAccessGroupEligibilityScheduleTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#create PrivilegedAccessGroupEligibilitySchedule#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#delete PrivilegedAccessGroupEligibilitySchedule#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#read PrivilegedAccessGroupEligibilitySchedule#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#update PrivilegedAccessGroupEligibilitySchedule#update}
    */
    readonly update?: string;
}
export declare function privilegedAccessGroupEligibilityScheduleTimeoutsToTerraform(struct?: PrivilegedAccessGroupEligibilityScheduleTimeouts | cdktn.IResolvable): any;
export declare function privilegedAccessGroupEligibilityScheduleTimeoutsToHclTerraform(struct?: PrivilegedAccessGroupEligibilityScheduleTimeouts | cdktn.IResolvable): any;
export declare class PrivilegedAccessGroupEligibilityScheduleTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): PrivilegedAccessGroupEligibilityScheduleTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: PrivilegedAccessGroupEligibilityScheduleTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule azuread_privileged_access_group_eligibility_schedule}
*/
export declare class PrivilegedAccessGroupEligibilitySchedule extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_privileged_access_group_eligibility_schedule";
    /**
    * Generates CDKTN code for importing a PrivilegedAccessGroupEligibilitySchedule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the PrivilegedAccessGroupEligibilitySchedule to import
    * @param importFromId The id of the existing PrivilegedAccessGroupEligibilitySchedule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the PrivilegedAccessGroupEligibilitySchedule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/privileged_access_group_eligibility_schedule azuread_privileged_access_group_eligibility_schedule} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options PrivilegedAccessGroupEligibilityScheduleConfig
    */
    constructor(scope: Construct, id: string, config: PrivilegedAccessGroupEligibilityScheduleConfig);
    private _assignmentType?;
    get assignmentType(): string;
    set assignmentType(value: string);
    get assignmentTypeInput(): string | undefined;
    private _duration?;
    get duration(): string;
    set duration(value: string);
    resetDuration(): void;
    get durationInput(): string | undefined;
    private _expirationDate?;
    get expirationDate(): string;
    set expirationDate(value: string);
    resetExpirationDate(): void;
    get expirationDateInput(): string | undefined;
    private _groupId?;
    get groupId(): string;
    set groupId(value: string);
    get groupIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _justification?;
    get justification(): string;
    set justification(value: string);
    resetJustification(): void;
    get justificationInput(): string | undefined;
    private _permanentAssignment?;
    get permanentAssignment(): boolean | cdktn.IResolvable;
    set permanentAssignment(value: boolean | cdktn.IResolvable);
    resetPermanentAssignment(): void;
    get permanentAssignmentInput(): boolean | cdktn.IResolvable | undefined;
    private _principalId?;
    get principalId(): string;
    set principalId(value: string);
    get principalIdInput(): string | undefined;
    private _startDate?;
    get startDate(): string;
    set startDate(value: string);
    resetStartDate(): void;
    get startDateInput(): string | undefined;
    get status(): string;
    private _ticketNumber?;
    get ticketNumber(): string;
    set ticketNumber(value: string);
    resetTicketNumber(): void;
    get ticketNumberInput(): string | undefined;
    private _ticketSystem?;
    get ticketSystem(): string;
    set ticketSystem(value: string);
    resetTicketSystem(): void;
    get ticketSystemInput(): string | undefined;
    private _timeouts;
    get timeouts(): PrivilegedAccessGroupEligibilityScheduleTimeoutsOutputReference;
    putTimeouts(value: PrivilegedAccessGroupEligibilityScheduleTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | PrivilegedAccessGroupEligibilityScheduleTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
