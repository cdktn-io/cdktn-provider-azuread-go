/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ClaimsMappingPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * A string collection containing a JSON string that defines the rules and settings for this policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#definition ClaimsMappingPolicy#definition}
    */
    readonly definition: string[];
    /**
    * Display name for this policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#display_name ClaimsMappingPolicy#display_name}
    */
    readonly displayName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#id ClaimsMappingPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#timeouts ClaimsMappingPolicy#timeouts}
    */
    readonly timeouts?: ClaimsMappingPolicyTimeouts;
}
export interface ClaimsMappingPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#create ClaimsMappingPolicy#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#delete ClaimsMappingPolicy#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#read ClaimsMappingPolicy#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#update ClaimsMappingPolicy#update}
    */
    readonly update?: string;
}
export declare function claimsMappingPolicyTimeoutsToTerraform(struct?: ClaimsMappingPolicyTimeouts | cdktn.IResolvable): any;
export declare function claimsMappingPolicyTimeoutsToHclTerraform(struct?: ClaimsMappingPolicyTimeouts | cdktn.IResolvable): any;
export declare class ClaimsMappingPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ClaimsMappingPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ClaimsMappingPolicyTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy azuread_claims_mapping_policy}
*/
export declare class ClaimsMappingPolicy extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_claims_mapping_policy";
    /**
    * Generates CDKTN code for importing a ClaimsMappingPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ClaimsMappingPolicy to import
    * @param importFromId The id of the existing ClaimsMappingPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ClaimsMappingPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/claims_mapping_policy azuread_claims_mapping_policy} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ClaimsMappingPolicyConfig
    */
    constructor(scope: Construct, id: string, config: ClaimsMappingPolicyConfig);
    private _definition?;
    get definition(): string[];
    set definition(value: string[]);
    get definitionInput(): string[] | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): ClaimsMappingPolicyTimeoutsOutputReference;
    putTimeouts(value: ClaimsMappingPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ClaimsMappingPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
