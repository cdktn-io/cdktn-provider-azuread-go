/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DirectoryRoleMemberConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#id DirectoryRoleMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the member
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#member_object_id DirectoryRoleMember#member_object_id}
    */
    readonly memberObjectId?: string;
    /**
    * The object ID of the directory role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#role_object_id DirectoryRoleMember#role_object_id}
    */
    readonly roleObjectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#timeouts DirectoryRoleMember#timeouts}
    */
    readonly timeouts?: DirectoryRoleMemberTimeouts;
}
export interface DirectoryRoleMemberTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#create DirectoryRoleMember#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#delete DirectoryRoleMember#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#read DirectoryRoleMember#read}
    */
    readonly read?: string;
}
export declare function directoryRoleMemberTimeoutsToTerraform(struct?: DirectoryRoleMemberTimeouts | cdktn.IResolvable): any;
export declare function directoryRoleMemberTimeoutsToHclTerraform(struct?: DirectoryRoleMemberTimeouts | cdktn.IResolvable): any;
export declare class DirectoryRoleMemberTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DirectoryRoleMemberTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DirectoryRoleMemberTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member azuread_directory_role_member}
*/
export declare class DirectoryRoleMember extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_directory_role_member";
    /**
    * Generates CDKTN code for importing a DirectoryRoleMember resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DirectoryRoleMember to import
    * @param importFromId The id of the existing DirectoryRoleMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DirectoryRoleMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/directory_role_member azuread_directory_role_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DirectoryRoleMemberConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DirectoryRoleMemberConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberObjectId?;
    get memberObjectId(): string;
    set memberObjectId(value: string);
    resetMemberObjectId(): void;
    get memberObjectIdInput(): string | undefined;
    private _roleObjectId?;
    get roleObjectId(): string;
    set roleObjectId(value: string);
    resetRoleObjectId(): void;
    get roleObjectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DirectoryRoleMemberTimeoutsOutputReference;
    putTimeouts(value: DirectoryRoleMemberTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DirectoryRoleMemberTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
