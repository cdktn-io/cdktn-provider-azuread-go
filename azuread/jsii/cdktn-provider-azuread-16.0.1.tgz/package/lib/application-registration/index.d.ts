/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationRegistrationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Description of the application as shown to end users
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#description ApplicationRegistration#description}
    */
    readonly description?: string;
    /**
    * The display name for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#display_name ApplicationRegistration#display_name}
    */
    readonly displayName: string;
    /**
    * Configures the `groups` claim that the app expects issued in a user or OAuth access token
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#group_membership_claims ApplicationRegistration#group_membership_claims}
    */
    readonly groupMembershipClaims?: string[];
    /**
    * URL of the home page for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#homepage_url ApplicationRegistration#homepage_url}
    */
    readonly homepageUrl?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#id ApplicationRegistration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether this application can request an access token using OAuth implicit flow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#implicit_access_token_issuance_enabled ApplicationRegistration#implicit_access_token_issuance_enabled}
    */
    readonly implicitAccessTokenIssuanceEnabled?: boolean | cdktn.IResolvable;
    /**
    * Whether this application can request an ID token using OAuth implicit flow
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#implicit_id_token_issuance_enabled ApplicationRegistration#implicit_id_token_issuance_enabled}
    */
    readonly implicitIdTokenIssuanceEnabled?: boolean | cdktn.IResolvable;
    /**
    * URL of the logout page for the application, where the session is cleared for single sign-out
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#logout_url ApplicationRegistration#logout_url}
    */
    readonly logoutUrl?: string;
    /**
    * URL of the marketing page for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#marketing_url ApplicationRegistration#marketing_url}
    */
    readonly marketingUrl?: string;
    /**
    * User-specified notes relevant for the management of the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#notes ApplicationRegistration#notes}
    */
    readonly notes?: string;
    /**
    * URL of the privacy statement for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#privacy_statement_url ApplicationRegistration#privacy_statement_url}
    */
    readonly privacyStatementUrl?: string;
    /**
    * The access token version expected by this resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#requested_access_token_version ApplicationRegistration#requested_access_token_version}
    */
    readonly requestedAccessTokenVersion?: number;
    /**
    * References application or contact information from a service or asset management database
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#service_management_reference ApplicationRegistration#service_management_reference}
    */
    readonly serviceManagementReference?: string;
    /**
    * The Microsoft account types that are supported for the current application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#sign_in_audience ApplicationRegistration#sign_in_audience}
    */
    readonly signInAudience?: string;
    /**
    * URL of the support page for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#support_url ApplicationRegistration#support_url}
    */
    readonly supportUrl?: string;
    /**
    * URL of the terms of service statement for the application
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#terms_of_service_url ApplicationRegistration#terms_of_service_url}
    */
    readonly termsOfServiceUrl?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#timeouts ApplicationRegistration#timeouts}
    */
    readonly timeouts?: ApplicationRegistrationTimeouts;
}
export interface ApplicationRegistrationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#create ApplicationRegistration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#delete ApplicationRegistration#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#read ApplicationRegistration#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#update ApplicationRegistration#update}
    */
    readonly update?: string;
}
export declare function applicationRegistrationTimeoutsToTerraform(struct?: ApplicationRegistrationTimeouts | cdktn.IResolvable): any;
export declare function applicationRegistrationTimeoutsToHclTerraform(struct?: ApplicationRegistrationTimeouts | cdktn.IResolvable): any;
export declare class ApplicationRegistrationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationRegistrationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationRegistrationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration azuread_application_registration}
*/
export declare class ApplicationRegistration extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_registration";
    /**
    * Generates CDKTN code for importing a ApplicationRegistration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationRegistration to import
    * @param importFromId The id of the existing ApplicationRegistration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationRegistration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_registration azuread_application_registration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationRegistrationConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationRegistrationConfig);
    get clientId(): string;
    private _description?;
    get description(): string;
    set description(value: string);
    resetDescription(): void;
    get descriptionInput(): string | undefined;
    get disabledByMicrosoft(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _groupMembershipClaims?;
    get groupMembershipClaims(): string[];
    set groupMembershipClaims(value: string[]);
    resetGroupMembershipClaims(): void;
    get groupMembershipClaimsInput(): string[] | undefined;
    private _homepageUrl?;
    get homepageUrl(): string;
    set homepageUrl(value: string);
    resetHomepageUrl(): void;
    get homepageUrlInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _implicitAccessTokenIssuanceEnabled?;
    get implicitAccessTokenIssuanceEnabled(): boolean | cdktn.IResolvable;
    set implicitAccessTokenIssuanceEnabled(value: boolean | cdktn.IResolvable);
    resetImplicitAccessTokenIssuanceEnabled(): void;
    get implicitAccessTokenIssuanceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _implicitIdTokenIssuanceEnabled?;
    get implicitIdTokenIssuanceEnabled(): boolean | cdktn.IResolvable;
    set implicitIdTokenIssuanceEnabled(value: boolean | cdktn.IResolvable);
    resetImplicitIdTokenIssuanceEnabled(): void;
    get implicitIdTokenIssuanceEnabledInput(): boolean | cdktn.IResolvable | undefined;
    private _logoutUrl?;
    get logoutUrl(): string;
    set logoutUrl(value: string);
    resetLogoutUrl(): void;
    get logoutUrlInput(): string | undefined;
    private _marketingUrl?;
    get marketingUrl(): string;
    set marketingUrl(value: string);
    resetMarketingUrl(): void;
    get marketingUrlInput(): string | undefined;
    private _notes?;
    get notes(): string;
    set notes(value: string);
    resetNotes(): void;
    get notesInput(): string | undefined;
    get objectId(): string;
    private _privacyStatementUrl?;
    get privacyStatementUrl(): string;
    set privacyStatementUrl(value: string);
    resetPrivacyStatementUrl(): void;
    get privacyStatementUrlInput(): string | undefined;
    get publisherDomain(): string;
    private _requestedAccessTokenVersion?;
    get requestedAccessTokenVersion(): number;
    set requestedAccessTokenVersion(value: number);
    resetRequestedAccessTokenVersion(): void;
    get requestedAccessTokenVersionInput(): number | undefined;
    private _serviceManagementReference?;
    get serviceManagementReference(): string;
    set serviceManagementReference(value: string);
    resetServiceManagementReference(): void;
    get serviceManagementReferenceInput(): string | undefined;
    private _signInAudience?;
    get signInAudience(): string;
    set signInAudience(value: string);
    resetSignInAudience(): void;
    get signInAudienceInput(): string | undefined;
    private _supportUrl?;
    get supportUrl(): string;
    set supportUrl(value: string);
    resetSupportUrl(): void;
    get supportUrlInput(): string | undefined;
    private _termsOfServiceUrl?;
    get termsOfServiceUrl(): string;
    set termsOfServiceUrl(value: string);
    resetTermsOfServiceUrl(): void;
    get termsOfServiceUrlInput(): string | undefined;
    private _timeouts;
    get timeouts(): ApplicationRegistrationTimeoutsOutputReference;
    putTimeouts(value: ApplicationRegistrationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationRegistrationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
