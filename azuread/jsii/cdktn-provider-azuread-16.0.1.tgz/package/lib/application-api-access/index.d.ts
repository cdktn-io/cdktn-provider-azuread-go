/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface ApplicationApiAccessConfig extends cdktn.TerraformMetaArguments {
    /**
    * The client ID of the API to which access is being granted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#api_client_id ApplicationApiAccess#api_client_id}
    */
    readonly apiClientId: string;
    /**
    * The resource ID of the application to which this API access is granted
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#application_id ApplicationApiAccess#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#id ApplicationApiAccess#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A set of role IDs to be granted to the application, as published by the API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#role_ids ApplicationApiAccess#role_ids}
    */
    readonly roleIds?: string[];
    /**
    * A set of scope IDs to be granted to the application, as published by the API
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#scope_ids ApplicationApiAccess#scope_ids}
    */
    readonly scopeIds?: string[];
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#timeouts ApplicationApiAccess#timeouts}
    */
    readonly timeouts?: ApplicationApiAccessTimeouts;
}
export interface ApplicationApiAccessTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#create ApplicationApiAccess#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#delete ApplicationApiAccess#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#read ApplicationApiAccess#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#update ApplicationApiAccess#update}
    */
    readonly update?: string;
}
export declare function applicationApiAccessTimeoutsToTerraform(struct?: ApplicationApiAccessTimeouts | cdktn.IResolvable): any;
export declare function applicationApiAccessTimeoutsToHclTerraform(struct?: ApplicationApiAccessTimeouts | cdktn.IResolvable): any;
export declare class ApplicationApiAccessTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): ApplicationApiAccessTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: ApplicationApiAccessTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access azuread_application_api_access}
*/
export declare class ApplicationApiAccess extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_application_api_access";
    /**
    * Generates CDKTN code for importing a ApplicationApiAccess resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the ApplicationApiAccess to import
    * @param importFromId The id of the existing ApplicationApiAccess that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the ApplicationApiAccess to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/application_api_access azuread_application_api_access} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options ApplicationApiAccessConfig
    */
    constructor(scope: Construct, id: string, config: ApplicationApiAccessConfig);
    private _apiClientId?;
    get apiClientId(): string;
    set apiClientId(value: string);
    get apiClientIdInput(): string | undefined;
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _roleIds?;
    get roleIds(): string[];
    set roleIds(value: string[]);
    resetRoleIds(): void;
    get roleIdsInput(): string[] | undefined;
    private _scopeIds?;
    get scopeIds(): string[];
    set scopeIds(value: string[]);
    resetScopeIds(): void;
    get scopeIdsInput(): string[] | undefined;
    private _timeouts;
    get timeouts(): ApplicationApiAccessTimeoutsOutputReference;
    putTimeouts(value: ApplicationApiAccessTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | ApplicationApiAccessTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
