/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AuthenticationStrengthPolicyFido2CombinationConfigurationConfig extends cdktn.TerraformMetaArguments {
    /**
    * A set of AAGUIDs allowed to be used as part of the `fido2` combination
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#allowed_aaguids AuthenticationStrengthPolicyFido2CombinationConfiguration#allowed_aaguids}
    */
    readonly allowedAaguids: string[];
    /**
    * The object ID of the authentication strength policy to which this combination configuration applies
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#authentication_strength_policy_id AuthenticationStrengthPolicyFido2CombinationConfiguration#authentication_strength_policy_id}
    */
    readonly authenticationStrengthPolicyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#id AuthenticationStrengthPolicyFido2CombinationConfiguration#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#timeouts AuthenticationStrengthPolicyFido2CombinationConfiguration#timeouts}
    */
    readonly timeouts?: AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts;
}
export interface AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#create AuthenticationStrengthPolicyFido2CombinationConfiguration#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#delete AuthenticationStrengthPolicyFido2CombinationConfiguration#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#read AuthenticationStrengthPolicyFido2CombinationConfiguration#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#update AuthenticationStrengthPolicyFido2CombinationConfiguration#update}
    */
    readonly update?: string;
}
export declare function authenticationStrengthPolicyFido2CombinationConfigurationTimeoutsToTerraform(struct?: AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts | cdktn.IResolvable): any;
export declare function authenticationStrengthPolicyFido2CombinationConfigurationTimeoutsToHclTerraform(struct?: AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts | cdktn.IResolvable): any;
export declare class AuthenticationStrengthPolicyFido2CombinationConfigurationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration azuread_authentication_strength_policy_fido2_combination_configuration}
*/
export declare class AuthenticationStrengthPolicyFido2CombinationConfiguration extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_authentication_strength_policy_fido2_combination_configuration";
    /**
    * Generates CDKTN code for importing a AuthenticationStrengthPolicyFido2CombinationConfiguration resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AuthenticationStrengthPolicyFido2CombinationConfiguration to import
    * @param importFromId The id of the existing AuthenticationStrengthPolicyFido2CombinationConfiguration that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AuthenticationStrengthPolicyFido2CombinationConfiguration to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/resources/authentication_strength_policy_fido2_combination_configuration azuread_authentication_strength_policy_fido2_combination_configuration} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AuthenticationStrengthPolicyFido2CombinationConfigurationConfig
    */
    constructor(scope: Construct, id: string, config: AuthenticationStrengthPolicyFido2CombinationConfigurationConfig);
    private _allowedAaguids?;
    get allowedAaguids(): string[];
    set allowedAaguids(value: string[]);
    get allowedAaguidsInput(): string[] | undefined;
    private _authenticationStrengthPolicyId?;
    get authenticationStrengthPolicyId(): string;
    set authenticationStrengthPolicyId(value: string);
    get authenticationStrengthPolicyIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _timeouts;
    get timeouts(): AuthenticationStrengthPolicyFido2CombinationConfigurationTimeoutsOutputReference;
    putTimeouts(value: AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AuthenticationStrengthPolicyFido2CombinationConfigurationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
