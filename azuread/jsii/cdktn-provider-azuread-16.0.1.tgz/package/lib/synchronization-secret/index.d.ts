/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface SynchronizationSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#id SynchronizationSecret#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the service principal for which this synchronization secret should be created
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#service_principal_id SynchronizationSecret#service_principal_id}
    */
    readonly servicePrincipalId: string;
    /**
    * credential block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#credential SynchronizationSecret#credential}
    */
    readonly credential?: SynchronizationSecretCredential[] | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#timeouts SynchronizationSecret#timeouts}
    */
    readonly timeouts?: SynchronizationSecretTimeouts;
}
export interface SynchronizationSecretCredential {
    /**
    * Name for this key-value pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#key SynchronizationSecret#key}
    */
    readonly key: string;
    /**
    * Value for this key-value pair.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#value SynchronizationSecret#value}
    */
    readonly value: string;
}
export declare function synchronizationSecretCredentialToTerraform(struct?: SynchronizationSecretCredential | cdktn.IResolvable): any;
export declare function synchronizationSecretCredentialToHclTerraform(struct?: SynchronizationSecretCredential | cdktn.IResolvable): any;
export declare class SynchronizationSecretCredentialOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): SynchronizationSecretCredential | cdktn.IResolvable | undefined;
    set internalValue(value: SynchronizationSecretCredential | cdktn.IResolvable | undefined);
    private _key?;
    get key(): string;
    set key(value: string);
    get keyInput(): string | undefined;
    private _value?;
    get value(): string;
    set value(value: string);
    get valueInput(): string | undefined;
}
export declare class SynchronizationSecretCredentialList extends cdktn.ComplexList {
    internalValue?: SynchronizationSecretCredential[] | cdktn.IResolvable;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): SynchronizationSecretCredentialOutputReference;
}
export interface SynchronizationSecretTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#create SynchronizationSecret#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#delete SynchronizationSecret#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#read SynchronizationSecret#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#update SynchronizationSecret#update}
    */
    readonly update?: string;
}
export declare function synchronizationSecretTimeoutsToTerraform(struct?: SynchronizationSecretTimeouts | cdktn.IResolvable): any;
export declare function synchronizationSecretTimeoutsToHclTerraform(struct?: SynchronizationSecretTimeouts | cdktn.IResolvable): any;
export declare class SynchronizationSecretTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): SynchronizationSecretTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: SynchronizationSecretTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret azuread_synchronization_secret}
*/
export declare class SynchronizationSecret extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_synchronization_secret";
    /**
    * Generates CDKTN code for importing a SynchronizationSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the SynchronizationSecret to import
    * @param importFromId The id of the existing SynchronizationSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the SynchronizationSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/synchronization_secret azuread_synchronization_secret} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options SynchronizationSecretConfig
    */
    constructor(scope: Construct, id: string, config: SynchronizationSecretConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _servicePrincipalId?;
    get servicePrincipalId(): string;
    set servicePrincipalId(value: string);
    get servicePrincipalIdInput(): string | undefined;
    private _credential;
    get credential(): SynchronizationSecretCredentialList;
    putCredential(value: SynchronizationSecretCredential[] | cdktn.IResolvable): void;
    resetCredential(): void;
    get credentialInput(): cdktn.IResolvable | SynchronizationSecretCredential[] | undefined;
    private _timeouts;
    get timeouts(): SynchronizationSecretTimeoutsOutputReference;
    putTimeouts(value: SynchronizationSecretTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | SynchronizationSecretTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
