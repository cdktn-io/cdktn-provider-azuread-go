/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadApplicationPublishedAppIdsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/application_published_app_ids#id DataAzureadApplicationPublishedAppIds#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/application_published_app_ids#timeouts DataAzureadApplicationPublishedAppIds#timeouts}
    */
    readonly timeouts?: DataAzureadApplicationPublishedAppIdsTimeouts;
}
export interface DataAzureadApplicationPublishedAppIdsTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/application_published_app_ids#read DataAzureadApplicationPublishedAppIds#read}
    */
    readonly read?: string;
}
export declare function dataAzureadApplicationPublishedAppIdsTimeoutsToTerraform(struct?: DataAzureadApplicationPublishedAppIdsTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadApplicationPublishedAppIdsTimeoutsToHclTerraform(struct?: DataAzureadApplicationPublishedAppIdsTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadApplicationPublishedAppIdsTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadApplicationPublishedAppIdsTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadApplicationPublishedAppIdsTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/application_published_app_ids azuread_application_published_app_ids}
*/
export declare class DataAzureadApplicationPublishedAppIds extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_application_published_app_ids";
    /**
    * Generates CDKTN code for importing a DataAzureadApplicationPublishedAppIds resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadApplicationPublishedAppIds to import
    * @param importFromId The id of the existing DataAzureadApplicationPublishedAppIds that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/application_published_app_ids#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadApplicationPublishedAppIds to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/data-sources/application_published_app_ids azuread_application_published_app_ids} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadApplicationPublishedAppIdsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadApplicationPublishedAppIdsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _result;
    get result(): cdktn.StringMap;
    private _timeouts;
    get timeouts(): DataAzureadApplicationPublishedAppIdsTimeoutsOutputReference;
    putTimeouts(value: DataAzureadApplicationPublishedAppIdsTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadApplicationPublishedAppIdsTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
