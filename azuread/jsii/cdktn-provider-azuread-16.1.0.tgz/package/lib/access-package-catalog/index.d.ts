/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessPackageCatalogConfig extends cdktn.TerraformMetaArguments {
    /**
    * The description of the access package catalog
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#description AccessPackageCatalog#description}
    */
    readonly description: string;
    /**
    * The display name of the access package catalog
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#display_name AccessPackageCatalog#display_name}
    */
    readonly displayName: string;
    /**
    * Whether the access packages in this catalog can be requested by users outside the tenant
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#externally_visible AccessPackageCatalog#externally_visible}
    */
    readonly externallyVisible?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#id AccessPackageCatalog#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Whether the access packages in this catalog are available for management
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#published AccessPackageCatalog#published}
    */
    readonly published?: boolean | cdktn.IResolvable;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#timeouts AccessPackageCatalog#timeouts}
    */
    readonly timeouts?: AccessPackageCatalogTimeouts;
}
export interface AccessPackageCatalogTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#create AccessPackageCatalog#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#delete AccessPackageCatalog#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#read AccessPackageCatalog#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#update AccessPackageCatalog#update}
    */
    readonly update?: string;
}
export declare function accessPackageCatalogTimeoutsToTerraform(struct?: AccessPackageCatalogTimeouts | cdktn.IResolvable): any;
export declare function accessPackageCatalogTimeoutsToHclTerraform(struct?: AccessPackageCatalogTimeouts | cdktn.IResolvable): any;
export declare class AccessPackageCatalogTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageCatalogTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageCatalogTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog azuread_access_package_catalog}
*/
export declare class AccessPackageCatalog extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_access_package_catalog";
    /**
    * Generates CDKTN code for importing a AccessPackageCatalog resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPackageCatalog to import
    * @param importFromId The id of the existing AccessPackageCatalog that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPackageCatalog to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.9.0/docs/resources/access_package_catalog azuread_access_package_catalog} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPackageCatalogConfig
    */
    constructor(scope: Construct, id: string, config: AccessPackageCatalogConfig);
    private _description?;
    get description(): string;
    set description(value: string);
    get descriptionInput(): string | undefined;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    get displayNameInput(): string | undefined;
    private _externallyVisible?;
    get externallyVisible(): boolean | cdktn.IResolvable;
    set externallyVisible(value: boolean | cdktn.IResolvable);
    resetExternallyVisible(): void;
    get externallyVisibleInput(): boolean | cdktn.IResolvable | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _published?;
    get published(): boolean | cdktn.IResolvable;
    set published(value: boolean | cdktn.IResolvable);
    resetPublished(): void;
    get publishedInput(): boolean | cdktn.IResolvable | undefined;
    private _timeouts;
    get timeouts(): AccessPackageCatalogTimeoutsOutputReference;
    putTimeouts(value: AccessPackageCatalogTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessPackageCatalogTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
