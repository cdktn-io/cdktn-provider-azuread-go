/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessPackageCatalogRoleAssignmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique ID of the access package catalog.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#catalog_id AccessPackageCatalogRoleAssignment#catalog_id}
    */
    readonly catalogId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#id AccessPackageCatalogRoleAssignment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the member principal
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#principal_object_id AccessPackageCatalogRoleAssignment#principal_object_id}
    */
    readonly principalObjectId: string;
    /**
    * The object ID of the catalog role for this assignment
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#role_id AccessPackageCatalogRoleAssignment#role_id}
    */
    readonly roleId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#timeouts AccessPackageCatalogRoleAssignment#timeouts}
    */
    readonly timeouts?: AccessPackageCatalogRoleAssignmentTimeouts;
}
export interface AccessPackageCatalogRoleAssignmentTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#create AccessPackageCatalogRoleAssignment#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#delete AccessPackageCatalogRoleAssignment#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#read AccessPackageCatalogRoleAssignment#read}
    */
    readonly read?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#update AccessPackageCatalogRoleAssignment#update}
    */
    readonly update?: string;
}
export declare function accessPackageCatalogRoleAssignmentTimeoutsToTerraform(struct?: AccessPackageCatalogRoleAssignmentTimeouts | cdktn.IResolvable): any;
export declare function accessPackageCatalogRoleAssignmentTimeoutsToHclTerraform(struct?: AccessPackageCatalogRoleAssignmentTimeouts | cdktn.IResolvable): any;
export declare class AccessPackageCatalogRoleAssignmentTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageCatalogRoleAssignmentTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageCatalogRoleAssignmentTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
    private _update?;
    get update(): string;
    set update(value: string);
    resetUpdate(): void;
    get updateInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment azuread_access_package_catalog_role_assignment}
*/
export declare class AccessPackageCatalogRoleAssignment extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_access_package_catalog_role_assignment";
    /**
    * Generates CDKTN code for importing a AccessPackageCatalogRoleAssignment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPackageCatalogRoleAssignment to import
    * @param importFromId The id of the existing AccessPackageCatalogRoleAssignment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPackageCatalogRoleAssignment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_catalog_role_assignment azuread_access_package_catalog_role_assignment} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPackageCatalogRoleAssignmentConfig
    */
    constructor(scope: Construct, id: string, config: AccessPackageCatalogRoleAssignmentConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    get catalogIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _principalObjectId?;
    get principalObjectId(): string;
    set principalObjectId(value: string);
    get principalObjectIdInput(): string | undefined;
    private _roleId?;
    get roleId(): string;
    set roleId(value: string);
    get roleIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AccessPackageCatalogRoleAssignmentTimeoutsOutputReference;
    putTimeouts(value: AccessPackageCatalogRoleAssignmentTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessPackageCatalogRoleAssignmentTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
