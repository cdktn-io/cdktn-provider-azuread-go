/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataAzureadAuthenticationStrengthPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The display name for the authentication strength policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy#display_name DataAzureadAuthenticationStrengthPolicy#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy#id DataAzureadAuthenticationStrengthPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the authentication strength policy
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy#object_id DataAzureadAuthenticationStrengthPolicy#object_id}
    */
    readonly objectId?: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy#timeouts DataAzureadAuthenticationStrengthPolicy#timeouts}
    */
    readonly timeouts?: DataAzureadAuthenticationStrengthPolicyTimeouts;
}
export interface DataAzureadAuthenticationStrengthPolicyCombinationConfigurations {
}
export declare function dataAzureadAuthenticationStrengthPolicyCombinationConfigurationsToTerraform(struct?: DataAzureadAuthenticationStrengthPolicyCombinationConfigurations): any;
export declare function dataAzureadAuthenticationStrengthPolicyCombinationConfigurationsToHclTerraform(struct?: DataAzureadAuthenticationStrengthPolicyCombinationConfigurations): any;
export declare class DataAzureadAuthenticationStrengthPolicyCombinationConfigurationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataAzureadAuthenticationStrengthPolicyCombinationConfigurations | undefined;
    set internalValue(value: DataAzureadAuthenticationStrengthPolicyCombinationConfigurations | undefined);
    get allowedAaguids(): string[];
    get allowedIssuerSkis(): string[];
    get allowedPolicyOids(): string[];
    get appliesToCombinations(): string[];
    get objectId(): string;
    get type(): string;
}
export declare class DataAzureadAuthenticationStrengthPolicyCombinationConfigurationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataAzureadAuthenticationStrengthPolicyCombinationConfigurationsOutputReference;
}
export interface DataAzureadAuthenticationStrengthPolicyTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy#read DataAzureadAuthenticationStrengthPolicy#read}
    */
    readonly read?: string;
}
export declare function dataAzureadAuthenticationStrengthPolicyTimeoutsToTerraform(struct?: DataAzureadAuthenticationStrengthPolicyTimeouts | cdktn.IResolvable): any;
export declare function dataAzureadAuthenticationStrengthPolicyTimeoutsToHclTerraform(struct?: DataAzureadAuthenticationStrengthPolicyTimeouts | cdktn.IResolvable): any;
export declare class DataAzureadAuthenticationStrengthPolicyTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataAzureadAuthenticationStrengthPolicyTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataAzureadAuthenticationStrengthPolicyTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy azuread_authentication_strength_policy}
*/
export declare class DataAzureadAuthenticationStrengthPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "azuread_authentication_strength_policy";
    /**
    * Generates CDKTN code for importing a DataAzureadAuthenticationStrengthPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataAzureadAuthenticationStrengthPolicy to import
    * @param importFromId The id of the existing DataAzureadAuthenticationStrengthPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataAzureadAuthenticationStrengthPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.10.0/docs/data-sources/authentication_strength_policy azuread_authentication_strength_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataAzureadAuthenticationStrengthPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataAzureadAuthenticationStrengthPolicyConfig);
    get allowedCombinations(): string[];
    private _combinationConfigurations;
    get combinationConfigurations(): DataAzureadAuthenticationStrengthPolicyCombinationConfigurationsList;
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _objectId?;
    get objectId(): string;
    set objectId(value: string);
    resetObjectId(): void;
    get objectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataAzureadAuthenticationStrengthPolicyTimeoutsOutputReference;
    putTimeouts(value: DataAzureadAuthenticationStrengthPolicyTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataAzureadAuthenticationStrengthPolicyTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
