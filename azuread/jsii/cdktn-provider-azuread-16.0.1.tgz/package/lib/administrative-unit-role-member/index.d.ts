/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AdministrativeUnitRoleMemberConfig extends cdktn.TerraformMetaArguments {
    /**
    * The object ID of the administrative unit
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#administrative_unit_object_id AdministrativeUnitRoleMember#administrative_unit_object_id}
    */
    readonly administrativeUnitObjectId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#id AdministrativeUnitRoleMember#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The object ID of the member
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#member_object_id AdministrativeUnitRoleMember#member_object_id}
    */
    readonly memberObjectId: string;
    /**
    * The object ID of the directory role
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#role_object_id AdministrativeUnitRoleMember#role_object_id}
    */
    readonly roleObjectId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#timeouts AdministrativeUnitRoleMember#timeouts}
    */
    readonly timeouts?: AdministrativeUnitRoleMemberTimeouts;
}
export interface AdministrativeUnitRoleMemberTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#create AdministrativeUnitRoleMember#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#delete AdministrativeUnitRoleMember#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#read AdministrativeUnitRoleMember#read}
    */
    readonly read?: string;
}
export declare function administrativeUnitRoleMemberTimeoutsToTerraform(struct?: AdministrativeUnitRoleMemberTimeouts | cdktn.IResolvable): any;
export declare function administrativeUnitRoleMemberTimeoutsToHclTerraform(struct?: AdministrativeUnitRoleMemberTimeouts | cdktn.IResolvable): any;
export declare class AdministrativeUnitRoleMemberTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AdministrativeUnitRoleMemberTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AdministrativeUnitRoleMemberTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member azuread_administrative_unit_role_member}
*/
export declare class AdministrativeUnitRoleMember extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_administrative_unit_role_member";
    /**
    * Generates CDKTN code for importing a AdministrativeUnitRoleMember resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AdministrativeUnitRoleMember to import
    * @param importFromId The id of the existing AdministrativeUnitRoleMember that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AdministrativeUnitRoleMember to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/administrative_unit_role_member azuread_administrative_unit_role_member} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AdministrativeUnitRoleMemberConfig
    */
    constructor(scope: Construct, id: string, config: AdministrativeUnitRoleMemberConfig);
    private _administrativeUnitObjectId?;
    get administrativeUnitObjectId(): string;
    set administrativeUnitObjectId(value: string);
    get administrativeUnitObjectIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberObjectId?;
    get memberObjectId(): string;
    set memberObjectId(value: string);
    get memberObjectIdInput(): string | undefined;
    private _roleObjectId?;
    get roleObjectId(): string;
    set roleObjectId(value: string);
    get roleObjectIdInput(): string | undefined;
    private _timeouts;
    get timeouts(): AdministrativeUnitRoleMemberTimeoutsOutputReference;
    putTimeouts(value: AdministrativeUnitRoleMemberTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AdministrativeUnitRoleMemberTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
