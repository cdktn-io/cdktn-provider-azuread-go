/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface AccessPackageResourceCatalogAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique ID of the access package catalog
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#catalog_id AccessPackageResourceCatalogAssociation#catalog_id}
    */
    readonly catalogId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#id AccessPackageResourceCatalogAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The unique identifier of the resource in the origin system. In the case of an Azure AD group, this is the identifier of the group
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#resource_origin_id AccessPackageResourceCatalogAssociation#resource_origin_id}
    */
    readonly resourceOriginId: string;
    /**
    * The type of the resource in the origin system, such as SharePointOnline, AadApplication or AadGroup
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#resource_origin_system AccessPackageResourceCatalogAssociation#resource_origin_system}
    */
    readonly resourceOriginSystem: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#timeouts AccessPackageResourceCatalogAssociation#timeouts}
    */
    readonly timeouts?: AccessPackageResourceCatalogAssociationTimeouts;
}
export interface AccessPackageResourceCatalogAssociationTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#create AccessPackageResourceCatalogAssociation#create}
    */
    readonly create?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#delete AccessPackageResourceCatalogAssociation#delete}
    */
    readonly delete?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#read AccessPackageResourceCatalogAssociation#read}
    */
    readonly read?: string;
}
export declare function accessPackageResourceCatalogAssociationTimeoutsToTerraform(struct?: AccessPackageResourceCatalogAssociationTimeouts | cdktn.IResolvable): any;
export declare function accessPackageResourceCatalogAssociationTimeoutsToHclTerraform(struct?: AccessPackageResourceCatalogAssociationTimeouts | cdktn.IResolvable): any;
export declare class AccessPackageResourceCatalogAssociationTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): AccessPackageResourceCatalogAssociationTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: AccessPackageResourceCatalogAssociationTimeouts | cdktn.IResolvable | undefined);
    private _create?;
    get create(): string;
    set create(value: string);
    resetCreate(): void;
    get createInput(): string | undefined;
    private _delete?;
    get delete(): string;
    set delete(value: string);
    resetDelete(): void;
    get deleteInput(): string | undefined;
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association azuread_access_package_resource_catalog_association}
*/
export declare class AccessPackageResourceCatalogAssociation extends cdktn.TerraformResource {
    static readonly tfResourceType = "azuread_access_package_resource_catalog_association";
    /**
    * Generates CDKTN code for importing a AccessPackageResourceCatalogAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the AccessPackageResourceCatalogAssociation to import
    * @param importFromId The id of the existing AccessPackageResourceCatalogAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the AccessPackageResourceCatalogAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/azuread/3.8.0/docs/resources/access_package_resource_catalog_association azuread_access_package_resource_catalog_association} Resource
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options AccessPackageResourceCatalogAssociationConfig
    */
    constructor(scope: Construct, id: string, config: AccessPackageResourceCatalogAssociationConfig);
    private _catalogId?;
    get catalogId(): string;
    set catalogId(value: string);
    get catalogIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _resourceOriginId?;
    get resourceOriginId(): string;
    set resourceOriginId(value: string);
    get resourceOriginIdInput(): string | undefined;
    private _resourceOriginSystem?;
    get resourceOriginSystem(): string;
    set resourceOriginSystem(value: string);
    get resourceOriginSystemInput(): string | undefined;
    private _timeouts;
    get timeouts(): AccessPackageResourceCatalogAssociationTimeoutsOutputReference;
    putTimeouts(value: AccessPackageResourceCatalogAssociationTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | AccessPackageResourceCatalogAssociationTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
